/**
 * Myth & Margin: Zelda-Style DOS Options RPG
 * Main Application Component
 */

import React, { useState, useEffect, useMemo, useCallback } from 'react';
import {
  DOSTheme,
  GameView,
  PlayerStats,
  OptionContract,
  AssetQuote,
  CombatState,
  QuestNode,
  StoryChoice,
  EnemyStats,
  UndervaluedAsset,
  ScamEncounter
} from './types';
import { REALM_MAPS, BOSS_ENEMIES, STORY_QUESTS } from './lib/questData';
import { ZELDA_MAPS, ZeldaEntity } from './lib/zeldaWorldData';
import { UNDERVALUED_ASSETS } from './lib/undervaluedAssetsData';
import { SCAM_ENCOUNTERS } from './lib/scamsData';
import { calculateBlackScholes } from './lib/blackScholes';
import { sound } from './lib/audioEngine';
import {
  calculatePortfolioRisk,
  getScaledEnemyStats,
  resolveCombatAction
} from './lib/combatEngine';

import { DOSHeader } from './components/DOSHeader';
import { ZeldaHeartsHUD } from './components/ZeldaHeartsHUD';
import { ZeldaOverworldCanvas } from './components/ZeldaOverworldCanvas';
import { ZeldaCombatModal } from './components/ZeldaCombatModal';
import { UndervaluedAssetModal } from './components/UndervaluedAssetModal';
import { RugPullLessonModal } from './components/RugPullLessonModal';
import { IntelligentInvestorSanctuaryModal } from './components/IntelligentInvestorSanctuaryModal';
import { TradeDeskModal } from './components/TradeDeskModal';
import { PortfolioLedgerModal } from './components/PortfolioLedgerModal';
import { GrimoireModal } from './components/GrimoireModal';
import { StoryDialogModal } from './components/StoryDialogModal';
import { TerminalCommandLine } from './components/TerminalCommandLine';
import { AvatarCustomizerModal } from './components/AvatarCustomizerModal';
import { SaveGameModal } from './components/SaveGameModal';
import { SaveSlotData, AvatarConfig } from './types';
import { Play, RotateCcw, Award, Skull, MessageSquare, Save, User, Sparkles } from 'lucide-react';

export default function App() {
  // Theme & Sound
  const [theme, setTheme] = useState<DOSTheme>('green');
  const [isMuted, setIsMuted] = useState(false);
  const [isBgmOn, setIsBgmOn] = useState(false);

  // View state
  const [currentView, setCurrentView] = useState<GameView>('INTRO');
  const [activeModal, setActiveModal] = useState<'TRADE' | 'PORTFOLIO' | 'GRIMOIRE' | 'QUEST' | null>(null);

  // Save & Customizer Modal State
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [saveModalMode, setSaveModalMode] = useState<'SAVE' | 'LOAD'>('SAVE');
  const [isAtSaveShrine, setIsAtSaveShrine] = useState(false);
  const [showCustomizeModal, setShowCustomizeModal] = useState(false);

  // Zelda Specialized State
  const [activeUndervaluedAsset, setActiveUndervaluedAsset] = useState<UndervaluedAsset | null>(null);
  const [activeScamEncounter, setActiveScamEncounter] = useState<ScamEncounter | null>(null);
  const [showSanctuary, setShowSanctuary] = useState(false);
  const [npcDialogue, setNpcDialogue] = useState<{ name: string; lines: string[] } | null>(null);

  // Player Stats with Zelda Hearts & Investor Tier
  const [player, setPlayer] = useState<PlayerStats>({
    name: 'Link',
    title: 'Hero of Valuaria',
    avatar: {
      tunicColor: 'green',
      hairColor: 'blonde',
      shieldStyle: 'hylian',
      avatarTitle: 'Hero of Valuaria'
    },
    // Zelda Life Force Hearts
    hearts: 4.0,
    maxHearts: 4,
    successfulTradesCount: 0,
    investorTier: 1, // 1 = Novice, 2 = Enterprising, 3 = Master Oracle
    hp: 100,
    maxHp: 100,
    mana: 50,
    maxMana: 50,
    florins: 10000, // 10,000 Guild Florins / Rupees
    stockShares: 50,
    portfolioValue: 10000,
    marginUsed: 0,
    marginLimit: 16000,
    netDelta: 0,
    netGamma: 0,
    netTheta: 0,
    netVega: 0,
    riskScore: 10,
    chapter: 1,
    day: 1,
    mapX: 5,
    mapY: 4,
    facing: 'DOWN',
    potions: {
      healthElixir: 2,
      ivStabilizer: 1,
      timeHourglass: 1
    },
    relics: ['Black-Scholes Slate', 'Wooden Value Shield'],
    undervaluedAssetsDiscovered: [],
    scamsFallen: [],
    scamsAvoided: [],
    intelligentInvestorRevivals: 0
  });

  // Open Options Contracts
  const [positions, setPositions] = useState<OptionContract[]>([]);

  // Underlying Realm Asset Quote ($AETH)
  const [assetQuote, setAssetQuote] = useState<AssetQuote>({
    symbol: '$AETH',
    name: 'Crown Index of Aethelgard',
    spotPrice: 100.0,
    previousClose: 99.5,
    iv: 0.28,
    trend: 'BULLISH',
    lore: 'The sovereign underlying asset powering the economic currents of Valuaria.'
  });

  // Combat State
  const [combatState, setCombatState] = useState<CombatState>({
    inCombat: false,
    enemy: null,
    turn: 1,
    combatLog: [],
    lastAction: null,
    playerShieldActive: false,
    enemyChargingSpecial: false,
    marketEventThisTurn: null
  });

  // Story Quest Dialog
  const [activeQuest, setActiveQuest] = useState<QuestNode | null>(null);

  // Terminal Output Buffer
  const [terminalLog, setTerminalLog] = useState<string[]>([
    'Aethelgard OS v6.22 initialized. Memory: 640K conventional OK.',
    'Zelda RPG Engine active. [WASD/Arrows] to move, [SPACE/E] to interact & swing sword.',
    'Sound options trading is your LIFE FORCE (HEARTS). Beware Ponzi and Crypto scams!',
    'Find Undervalued Assets with Margin of Safety to gain Heart Containers.'
  ]);

  // Calculate live portfolio values and Greeks
  const portfolioAnalysis = useMemo(() => {
    let totalOptionsValue = 0;
    let netDelta = player.stockShares / 100.0;
    let netGamma = 0;
    let netTheta = 0;
    let netVega = 0;

    const spot = assetQuote.spotPrice;
    const iv = assetQuote.iv;

    positions.forEach(pos => {
      const isCall = pos.type === 'CALL';
      const bs = calculateBlackScholes(spot, pos.strike, pos.dte, iv, 0.05, isCall);
      const markValue = bs.price * 100 * pos.quantity;
      totalOptionsValue += markValue;

      netDelta += bs.delta * pos.quantity;
      netGamma += bs.gamma * pos.quantity;
      netTheta += bs.theta * pos.quantity;
      netVega += bs.vega * pos.quantity;
    });

    const stockValue = player.stockShares * spot;
    const totalEquity = player.florins + totalOptionsValue + stockValue;

    return {
      totalEquity,
      netDelta: Number(netDelta.toFixed(2)),
      netGamma: Number(netGamma.toFixed(3)),
      netTheta: Number(netTheta.toFixed(2)),
      netVega: Number(netVega.toFixed(2))
    };
  }, [positions, player.florins, player.stockShares, assetQuote.spotPrice, assetQuote.iv]);

  // Dynamic Portfolio Risk
  const riskInfo = useMemo(() => {
    return calculatePortfolioRisk(
      {
        ...player,
        portfolioValue: portfolioAnalysis.totalEquity,
        netDelta: portfolioAnalysis.netDelta,
        netTheta: portfolioAnalysis.netTheta
      },
      positions
    );
  }, [player, portfolioAnalysis, positions]);

  // Keep player sync with computed portfolio equity and Greeks
  useEffect(() => {
    setPlayer(prev => ({
      ...prev,
      portfolioValue: portfolioAnalysis.totalEquity,
      netDelta: portfolioAnalysis.netDelta,
      netGamma: portfolioAnalysis.netGamma,
      netTheta: portfolioAnalysis.netTheta,
      netVega: portfolioAnalysis.netVega,
      riskScore: riskInfo.riskScore,
      hp: Math.round(prev.hearts * 25)
    }));
  }, [portfolioAnalysis, riskInfo.riskScore]);

  // Trigger Intelligent Investor Sanctuary if hearts run out
  useEffect(() => {
    if (player.hearts <= 0 && !showSanctuary && currentView !== 'INTRO') {
      sound.playAlarmSound();
      setShowSanctuary(true);
    }
  }, [player.hearts, showSanctuary, currentView]);

  // Advance 1 Market Day (Triggers Theta Decay, Settles Contracts)
  const handleAdvanceDay = useCallback(() => {
    sound.playCommandBeep();

    const updatedPositions: OptionContract[] = [];
    let expiredSettlementFlorins = 0;
    const logs: string[] = [];

    const spot = assetQuote.spotPrice;

    positions.forEach(pos => {
      const newDte = pos.dte - 1;
      if (newDte <= 0) {
        let intrinsic = 0;
        if (pos.type === 'CALL') {
          intrinsic = Math.max(0, spot - pos.strike);
        } else {
          intrinsic = Math.max(0, pos.strike - spot);
        }
        const payout = intrinsic * 100 * pos.quantity;
        expiredSettlementFlorins += payout;
        if (payout > 0) {
          logs.push(`> Option ${pos.strategy} (Strike ${pos.strike}) EXPIRED IN-THE-MONEY! Settled +${Math.round(payout)} Florins.`);
        } else {
          logs.push(`> Option ${pos.strategy} (Strike ${pos.strike}) EXPIRED OUT-OF-THE-MONEY (Worthless).`);
        }
      } else {
        updatedPositions.push({ ...pos, dte: newDte });
      }
    });

    setPositions(updatedPositions);

    // Organic Spot Price & IV Shift
    const randomDrift = (Math.random() - 0.48) * 0.035;
    const newSpot = Math.max(10, Number((spot * (1 + randomDrift)).toFixed(2)));
    const randomIvDrift = (Math.random() - 0.5) * 0.02;
    const newIv = Math.max(0.12, Math.min(0.95, Number((assetQuote.iv + randomIvDrift).toFixed(3))));

    setAssetQuote(prev => ({
      ...prev,
      spotPrice: newSpot,
      previousClose: spot,
      iv: newIv,
      trend: newSpot >= spot ? 'BULLISH' : 'BEARISH'
    }));

    // Update player stats
    setPlayer(prev => {
      // Rest restores some life force hearts
      const restoredHearts = Math.min(prev.maxHearts, prev.hearts + 0.5);
      const restoredMana = Math.min(prev.maxMana, prev.mana + 15);
      const newFlorins = prev.florins + expiredSettlementFlorins;

      // Margin call check
      const marginUtil = prev.marginLimit > 0 ? prev.marginUsed / prev.marginLimit : 0;
      let heartPenalty = 0;
      if (marginUtil > 0.90 || newFlorins < 0) {
        heartPenalty = 1.0;
        sound.playAlarmSound();
        logs.push(`> *** MARGIN CALL DETECTED! Overleveraged collateral breached! Lost 1.0 Heart! ***`);
      }

      const finalHearts = Math.max(0, restoredHearts - heartPenalty);

      return {
        ...prev,
        day: prev.day + 1,
        hearts: finalHearts,
        hp: Math.round(finalHearts * 25),
        mana: restoredMana,
        florins: newFlorins
      };
    });

    setTerminalLog(prev => [
      ...prev.slice(-12),
      `=== DAY #${player.day + 1} TRANSITION ===`,
      `Spot $AETH moved from ${spot.toFixed(2)} to ${newSpot.toFixed(2)} Florins (IV: ${(newIv * 100).toFixed(1)}%).`,
      ...logs
    ]);
  }, [assetQuote.spotPrice, assetQuote.iv, positions, player.day]);

  // Execute Options Trade (Your Life Force!)
  const handleExecuteTrade = (contract: OptionContract, netCost: number, marginReq: number) => {
    sound.playCoinSound();
    setPositions(prev => [...prev, contract]);

    setPlayer(prev => {
      const newTradeCount = prev.successfulTradesCount + 1;
      const tradesNeeded = 3;
      let newMaxHearts = prev.maxHearts;
      let earnedHeartContainer = false;

      // Every 3 trades earns a HEART CONTAINER!
      if (newTradeCount % tradesNeeded === 0) {
        newMaxHearts = prev.maxHearts + 1;
        earnedHeartContainer = true;
      }

      // Trading soundly replenishes your life force
      const restoredHearts = Math.min(newMaxHearts, prev.hearts + 0.5);

      // Scaling Tier based on heart containers
      let newTier = 1;
      if (newMaxHearts >= 7) newTier = 3;
      else if (newMaxHearts >= 5) newTier = 2;

      if (earnedHeartContainer) {
        sound.playHeartContainer();
        setTerminalLog(log => [
          ...log.slice(-10),
          `*** DISCIPLINED TRADING MILESTONE! Gained a HEART CONTAINER (${newMaxHearts} Max Hearts)! ***`,
          `*** Investor Tier ascended to Tier ${newTier}! Advanced market questions unlocked! ***`
        ]);
      }

      return {
        ...prev,
        florins: prev.florins - netCost,
        marginUsed: prev.marginUsed + marginReq,
        successfulTradesCount: newTradeCount,
        maxHearts: newMaxHearts,
        hearts: earnedHeartContainer ? newMaxHearts : restoredHearts,
        hp: Math.round((earnedHeartContainer ? newMaxHearts : restoredHearts) * 25),
        investorTier: newTier
      };
    });

    setActiveModal(null);
    setTerminalLog(prev => [
      ...prev.slice(-12),
      `[OPTIONS ORDER FORGED] ${contract.quantity}x ${contract.strategy} (Strike ${contract.strike}, ${contract.dte} DTE). Premium: ${contract.premium.toFixed(2)}ƒ. Life force replenished (+0.5 ♥)!`
    ]);
  };

  // Close Position
  const handleClosePosition = (positionId: string, currentMarketValue: number) => {
    const pos = positions.find(p => p.id === positionId);
    if (!pos) return;

    sound.playCoinSound();
    setPositions(prev => prev.filter(p => p.id !== positionId));
    setPlayer(prev => {
      // If big trade made (+50% profit or +500 florins gain), award extra heart container!
      const initialCost = pos.entryPrice * 100 * Math.abs(pos.quantity);
      const isBigWin = currentMarketValue >= initialCost * 1.5;
      let maxH = prev.maxHearts;
      if (isBigWin && maxH < 8) {
        maxH += 1;
        sound.playHeartContainer();
        setTerminalLog(log => [
          ...log.slice(-10),
          `*** LEGENDARY TRADE WIN (+50%+)! Gained a HEART CONTAINER (${maxH} Max Hearts)! ***`
        ]);
      }

      return {
        ...prev,
        florins: prev.florins + currentMarketValue,
        maxHearts: maxH,
        hearts: Math.min(maxH, prev.hearts + 0.5),
        marginUsed: Math.max(0, prev.marginUsed - (pos.strategy === 'CASH_SECURED_PUT' ? pos.strike * 100 * pos.quantity : 0))
      };
    });

    setTerminalLog(prev => [
      ...prev.slice(-12),
      `[POSITION CLOSED] ${pos.strategy} closed for +${Math.round(currentMarketValue)} Florins.`
    ]);
  };

  // Exercise Option
  const handleExercisePosition = (positionId: string) => {
    const pos = positions.find(p => p.id === positionId);
    if (!pos) return;

    const spot = assetQuote.spotPrice;
    let netGain = 0;

    if (pos.type === 'CALL') {
      netGain = Math.max(0, spot - pos.strike) * 100 * pos.quantity;
    } else {
      netGain = Math.max(0, pos.strike - spot) * 100 * pos.quantity;
    }

    sound.playCoinSound();
    setPositions(prev => prev.filter(p => p.id !== positionId));
    setPlayer(prev => ({
      ...prev,
      florins: prev.florins + netGain,
      hearts: Math.min(prev.maxHearts, prev.hearts + 0.5),
      marginUsed: Math.max(0, prev.marginUsed - (pos.strategy === 'CASH_SECURED_PUT' ? pos.strike * 100 * pos.quantity : 0))
    }));

    setTerminalLog(prev => [
      ...prev.slice(-12),
      `[CONTRACT EXERCISED] Exercised ${pos.strategy} (Strike ${pos.strike}) for +${Math.round(netGain)} Florins! Healed +0.5 Hearts!`
    ]);
  };

  // Start Zelda Combat
  const initiateCombat = (chapterNum: number) => {
    const baseEnemy = BOSS_ENEMIES[chapterNum] || BOSS_ENEMIES[1];
    sound.startMusic('battle');

    const scaledEnemy = getScaledEnemyStats(baseEnemy, player, riskInfo.riskScore);

    setCombatState({
      inCombat: true,
      enemy: scaledEnemy,
      turn: 1,
      combatLog: [
        `*** ENCOUNTER: ${scaledEnemy.name} emerges! ***`,
        `Scaled to ${scaledEnemy.maxHp} HP based on your ${Math.round(player.portfolioValue).toLocaleString()} Florin portfolio!`,
        `Solve tactical options & market puzzles to unleash your sword strikes!`
      ],
      lastAction: null,
      playerShieldActive: false,
      enemyChargingSpecial: false,
      marketEventThisTurn: null
    });

    setCurrentView('COMBAT');
  };

  // Zelda Puzzle Attack Resolution
  const handlePuzzleAttack = (bonusDamage: number, isCorrect: boolean, explanation: string) => {
    if (!combatState.enemy) return;

    const baseDamage = isCorrect ? 40 + player.chapter * 15 : 5;
    const totalPlayerDamage = Math.max(0, baseDamage + bonusDamage);
    const updatedEnemyHp = Math.max(0, combatState.enemy.currentHp - totalPlayerDamage);

    // If correct, player heals hearts slightly! If wrong, enemy counter-attacks and damages hearts!
    let heartDelta = 0;
    let enemyDamageDealt = 0;

    if (isCorrect) {
      heartDelta = 0.5; // Restores life force on good options decision
    } else {
      enemyDamageDealt = combatState.enemy.attackPower;
      heartDelta = -1.0; // Loses a heart
      sound.playAlarmSound();
    }

    setPlayer(prev => {
      const newHearts = Math.max(0, Math.min(prev.maxHearts, prev.hearts + heartDelta));
      return {
        ...prev,
        hearts: newHearts,
        hp: Math.round(newHearts * 25)
      };
    });

    // Check Enemy Defeated
    if (updatedEnemyHp <= 0) {
      sound.playFanfare();
      sound.startMusic('dungeon');
      const lootGold = 1500 * player.chapter;

      setPlayer(prev => {
        const newMax = prev.maxHearts + 1; // Boss victory awards Heart Container!
        return {
          ...prev,
          florins: prev.florins + lootGold,
          maxHearts: newMax,
          hearts: newMax,
          hp: Math.round(newMax * 25)
        };
      });

      if (player.chapter >= 3) {
        setCurrentView('VICTORY');
        return;
      }

      setTerminalLog(prev => [
        ...prev.slice(-10),
        `*** GUARDIAN VANQUISHED! Act ${player.chapter} cleared! Loot: +${lootGold} Florins! Gained +1 HEART CONTAINER! ***`
      ]);

      setPlayer(prev => ({
        ...prev,
        chapter: prev.chapter + 1,
        mapX: 5,
        mapY: 4
      }));

      setCurrentView('MAP');
      return;
    }

    // Update combat turn log
    setCombatState(prev => ({
      ...prev,
      turn: prev.turn + 1,
      combatLog: [
        ...prev.combatLog.slice(-8),
        isCorrect
          ? `⚔️ CRITICAL STRIKE! Dealt ${totalPlayerDamage} damage! Restored +0.5 Hearts!`
          : `❌ FLAWED OPTIONS THESIS! Dealt only ${totalPlayerDamage} damage. ${prev.enemy?.name} retaliated for -1.0 Heart!`,
        `> ${explanation}`
      ],
      enemy: { ...prev.enemy!, currentHp: updatedEnemyHp }
    }));
  };

  // Zelda Shield Block in Combat
  const handleCombatShield = () => {
    sound.playShieldBlock();
    setCombatState(prev => ({
      ...prev,
      playerShieldActive: true,
      combatLog: [
        ...prev.combatLog.slice(-8),
        `🛡️ HELD DEFINED-RISK SHIELD! Absorbed 80% incoming volatility impact!`
      ]
    }));
  };

  // Combat item use
  const handleCombatItem = (itemType: 'healthElixir' | 'ivStabilizer' | 'timeHourglass') => {
    if (player.potions[itemType] <= 0) return;

    sound.playSecretChime();
    setPlayer(prev => {
      let h = prev.hearts;
      if (itemType === 'healthElixir') {
        h = Math.min(prev.maxHearts, prev.hearts + 2.0); // Restores 2 hearts!
      }
      return {
        ...prev,
        hearts: h,
        hp: Math.round(h * 25),
        potions: {
          ...prev.potions,
          [itemType]: prev.potions[itemType] - 1
        }
      };
    });

    setCombatState(prev => ({
      ...prev,
      combatLog: [
        ...prev.combatLog.slice(-8),
        `✨ Used ${itemType}! Restored life force hearts!`
      ]
    }));
  };

  // Zelda Overworld Movement & Direction
  const handleOverworldMove = (x: number, y: number, facing: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => {
    setPlayer(prev => ({
      ...prev,
      mapX: x,
      mapY: y,
      facing
    }));
  };

  // Entity Interaction in Overworld
  const handleInteractEntity = (entity: ZeldaEntity) => {
    if (entity.type === 'NPC_SAGE') {
      sound.playSecretChime();
      setNpcDialogue({
        name: entity.name,
        lines: entity.dialogue || ['"Remember the Margin of Safety, my apprentice."']
      });
    } else if (entity.type === 'NPC_BROKER') {
      sound.playCommandBeep();
      setActiveModal('TRADE');
    } else if (entity.type === 'NPC_SCAMMER') {
      sound.playAlarmSound();
      const scam = SCAM_ENCOUNTERS[entity.targetId || 'ponzi_farm'] || SCAM_ENCOUNTERS['ponzi_farm'];
      setActiveScamEncounter(scam);
    } else if (entity.type === 'NPC_ASSET') {
      sound.playSecretChime();
      const asset = UNDERVALUED_ASSETS[entity.targetId || 'silver_mine'] || UNDERVALUED_ASSETS['silver_mine'];
      setActiveUndervaluedAsset(asset);
    } else if (entity.type === 'CHEST') {
      sound.playCoinSound();
      const rewardFlorins = 400 + player.chapter * 150;
      setPlayer(prev => ({
        ...prev,
        florins: prev.florins + rewardFlorins,
        hearts: Math.min(prev.maxHearts, prev.hearts + 1.0),
        potions: {
          ...prev.potions,
          healthElixir: prev.potions.healthElixir + 1
        }
      }));
      setTerminalLog(prev => [
        ...prev.slice(-10),
        `> Opened ancient Treasury Chest! Found +${rewardFlorins} Florins, +1 Health Elixir, and healed +1 Heart!`
      ]);
    } else if (entity.type === 'SHRINE') {
      sound.playSaveGame();
      setIsAtSaveShrine(true);
      setSaveModalMode('SAVE');
      setShowSaveModal(true);
    } else if (entity.type === 'BOSS') {
      initiateCombat(player.chapter);
    }
  };

  // Restore Quest from Save Slot
  const handleLoadGame = (data: SaveSlotData) => {
    setPlayer(data.player);
    setPositions(data.positions || []);
    if (data.assetQuote) setAssetQuote(data.assetQuote);
    if (data.terminalLog) setTerminalLog(data.terminalLog);
    setCurrentView('MAP');
    setShowSaveModal(false);
    setTerminalLog(prev => [
      ...prev.slice(-10),
      `*** RESTORED ADVENTURE: ${data.saveName} loaded successfully! ***`
    ]);
  };

  // Update Hero Name & Avatar Configuration
  const handleSaveProfile = (name: string, title: string, avatar: AvatarConfig) => {
    setPlayer(prev => ({
      ...prev,
      name,
      title,
      avatar
    }));
    setTerminalLog(prev => [
      ...prev.slice(-10),
      `*** HERO PROFILE CONFIRMED: ${name}, ${title}! ***`
    ]);
  };

  // Handle Undervalued Asset Choice Selection
  const handleSelectUndervaluedChoice = (choiceIdx: number) => {
    if (!activeUndervaluedAsset) return;
    const choice = activeUndervaluedAsset.choices[choiceIdx];

    setPlayer(prev => {
      let newFlorins = prev.florins - choice.costFlorins + choice.florinsGain;
      let newMax = prev.maxHearts;
      if (choice.awardsHeartContainer) {
        newMax = prev.maxHearts + 1; // Unlocks a heart container!
      }
      const newHearts = Math.max(0, Math.min(newMax, prev.hearts + choice.heartsEffect));
      const newTier = newMax >= 7 ? 3 : newMax >= 5 ? 2 : 1;

      return {
        ...prev,
        florins: newFlorins,
        maxHearts: newMax,
        hearts: choice.awardsHeartContainer ? newMax : newHearts,
        hp: Math.round(newHearts * 25),
        investorTier: newTier,
        undervaluedAssetsDiscovered: [...prev.undervaluedAssetsDiscovered, activeUndervaluedAsset.id]
      };
    });

    if (choice.spotShiftPercent) {
      setAssetQuote(prev => ({
        ...prev,
        spotPrice: Number((prev.spotPrice * (1 + choice.spotShiftPercent)).toFixed(2))
      }));
    }

    setTerminalLog(prev => [
      ...prev.slice(-10),
      `[VALUE DISCOVERY EXECUTED] ${choice.title}. Result: ${choice.florinsGain >= 0 ? '+' : ''}${choice.florinsGain}ƒ.`
    ]);

    setActiveUndervaluedAsset(null);
  };

  // Handle Falling for Scam (Rug Pull Penalty)
  const handleFallForScam = () => {
    if (!activeScamEncounter) return;
    const scam = activeScamEncounter;

    setPlayer(prev => {
      const lostFlorins = scam.costFlorins;
      const lostHearts = scam.temptationOutcome.heartsLost;
      const finalHearts = Math.max(0, prev.hearts - lostHearts);

      return {
        ...prev,
        florins: Math.max(50, prev.florins - lostFlorins),
        hearts: finalHearts,
        hp: Math.round(finalHearts * 25),
        scamsFallen: [...prev.scamsFallen, scam.id]
      };
    });

    setTerminalLog(prev => [
      ...prev.slice(-10),
      `🚨 [RUG PULL EVENT] Fell for ${scam.title}! Lost ${scam.temptationOutcome.heartsLost} Hearts and ${scam.costFlorins} Florins!`
    ]);
  };

  // Handle Rejecting Scam (Disciplined Reward)
  const handleRejectScam = () => {
    if (!activeScamEncounter) return;
    const scam = activeScamEncounter;

    setPlayer(prev => ({
      ...prev,
      florins: prev.florins + scam.rejectionOutcome.rewardFlorins,
      scamsAvoided: [...prev.scamsAvoided, scam.id]
    }));

    setTerminalLog(prev => [
      ...prev.slice(-10),
      `✅ [DISCIPLINED INVESTOR] Exposed ${scam.title}! Earned +${scam.rejectionOutcome.rewardFlorins} Florins reward!`
    ]);
  };

  // Revive in Sanctuary of Intelligent Investor
  const handleReviveInSanctuary = () => {
    sound.playHeartContainer();
    setPlayer(prev => ({
      ...prev,
      hearts: prev.maxHearts, // Full hearts restored!
      hp: Math.round(prev.maxHearts * 25),
      florins: Math.max(1500, prev.florins), // Seed grant from Graham
      intelligentInvestorRevivals: prev.intelligentInvestorRevivals + 1
    }));

    setShowSanctuary(false);
    setCurrentView('MAP');

    setTerminalLog(prev => [
      ...prev.slice(-10),
      `*** BLESSED BY SAGE BENJAMIN GRAHAM! All ${player.maxHearts} hearts restored with Margin of Safety! ***`
    ]);
  };

  // Restart Quest from Beginning
  const handleRestart = () => {
    sound.playCommandBeep();
    setPlayer({
      name: 'Link Alex',
      title: 'Apprentice of Valuaria',
      hearts: 4.0,
      maxHearts: 4,
      successfulTradesCount: 0,
      investorTier: 1,
      hp: 100,
      maxHp: 100,
      mana: 50,
      maxMana: 50,
      florins: 10000,
      stockShares: 50,
      portfolioValue: 10000,
      marginUsed: 0,
      marginLimit: 16000,
      netDelta: 0,
      netGamma: 0,
      netTheta: 0,
      netVega: 0,
      riskScore: 10,
      chapter: 1,
      day: 1,
      mapX: 5,
      mapY: 4,
      facing: 'DOWN',
      potions: { healthElixir: 2, ivStabilizer: 1, timeHourglass: 1 },
      relics: ['Black-Scholes Slate', 'Wooden Value Shield'],
      undervaluedAssetsDiscovered: [],
      scamsFallen: [],
      scamsAvoided: [],
      intelligentInvestorRevivals: 0
    });
    setPositions([]);
    setAssetQuote({
      symbol: '$AETH',
      name: 'Crown Index of Aethelgard',
      spotPrice: 100.0,
      previousClose: 99.5,
      iv: 0.28,
      trend: 'BULLISH',
      lore: 'The sovereign underlying asset powering the economic currents of Valuaria.'
    });
    setCurrentView('MAP');
    setActiveModal(null);
    setShowSanctuary(false);
  };

  // Theme color styles
  const themeClassMap: { [key in DOSTheme]: string } = {
    green: 'text-[#33ff33] bg-[#070b07]',
    amber: 'text-[#ffb000] bg-[#0c0903]',
    vga: 'text-[#ffff55] bg-[#05051a]',
    cyber: 'text-[#00ffff] bg-[#050a0a]'
  };

  return (
    <div className={`min-h-screen ${themeClassMap[theme]} relative font-mono transition-colors duration-200`}>
      {/* Vintage CRT Scanlines Overlay */}
      <div className="fixed inset-0 crt-overlay z-40 pointer-events-none" />

      {/* Main Container */}
      <div className="max-w-6xl mx-auto p-2 sm:p-4 min-h-screen flex flex-col justify-between">
        {/* DOS Header / Navigation */}
        <DOSHeader
          theme={theme}
          setTheme={setTheme}
          player={player}
          currentView={currentView}
          setView={setCurrentView}
          isMuted={isMuted}
          setIsMuted={setIsMuted}
          isBgmOn={isBgmOn}
          toggleBgm={() => {
            const nowPlaying = sound.toggleMusic(combatState.inCombat ? 'battle' : 'overworld');
            setIsBgmOn(nowPlaying);
          }}
          onAdvanceDay={handleAdvanceDay}
          onOpenSaveModal={() => {
            setSaveModalMode('SAVE');
            setIsAtSaveShrine(false);
            setShowSaveModal(true);
          }}
          onOpenCustomizeModal={() => setShowCustomizeModal(true)}
        />

        {/* Zelda Hearts HUD (Life Force Bar) */}
        {currentView !== 'INTRO' && (
          <div className="mb-2">
            <ZeldaHeartsHUD
              player={player}
              asset={assetQuote}
              onOpenTrade={() => setActiveModal('TRADE')}
              onOpenPortfolio={() => setActiveModal('PORTFOLIO')}
              onOpenGrimoire={() => setActiveModal('GRIMOIRE')}
              onAdvanceDay={handleAdvanceDay}
            />
          </div>
        )}

        {/* Dynamic Views */}
        <main className="flex-1 my-1">
          {/* INTRO TITLE SCREEN - 16-BIT SNES STYLE */}
          {currentView === 'INTRO' && (
            <div className="zelda-panel p-6 sm:p-8 text-center flex flex-col items-center justify-center min-h-[65vh] rounded-md shadow-2xl relative overflow-hidden">
              {/* Mythical Crest */}
              <div className="flex items-center justify-center gap-2 mb-2">
                <div className="w-0 h-0 border-l-[16px] border-l-transparent border-r-[16px] border-r-transparent border-b-[28px] border-b-amber-400 drop-shadow-[0_0_8px_rgba(245,158,11,0.8)]" />
              </div>

              <div className="text-amber-300 font-pixel text-2xl sm:text-4xl tracking-wider uppercase mb-1 drop-shadow-md">
                THE LEGEND OF VALUARIA
              </div>
              <div className="text-amber-200/80 font-bold text-xs sm:text-sm tracking-widest uppercase mb-4">
                A 16-BIT MYTHICAL OPTIONS TRADING RPG
              </div>

              {/* Hero Customization Quick Card */}
              <div className="max-w-md w-full bg-slate-950/80 border-2 border-amber-500/60 p-3.5 rounded-sm my-3 flex items-center justify-between gap-3 shadow-inner">
                <div className="flex items-center gap-3">
                  {/* Hero Mini 16-Bit Icon */}
                  <div className="w-10 h-10 rounded-sm border-2 border-amber-400 bg-slate-900 flex flex-col items-center justify-center relative overflow-hidden shadow-sm">
                    <div 
                      className="w-6 h-6 rounded-xs" 
                      style={{ 
                        backgroundColor: player.avatar?.tunicColor === 'red' ? '#b91c1c' : 
                                         player.avatar?.tunicColor === 'blue' ? '#1d4ed8' : 
                                         player.avatar?.tunicColor === 'purple' ? '#7e22ce' : 
                                         player.avatar?.tunicColor === 'black' ? '#334155' : '#2e7d32' 
                      }} 
                    />
                    <div className="absolute top-1 w-4 h-2 bg-amber-200/90 rounded-xs" />
                  </div>
                  <div className="text-left">
                    <div className="text-[11px] text-amber-200/70 font-semibold uppercase">PROTAGONIST AVATAR</div>
                    <div className="font-pixel text-base text-amber-300 font-bold">{player.name}</div>
                    <div className="text-[10px] text-slate-400">{player.avatar?.avatarTitle || player.title}</div>
                  </div>
                </div>

                <button
                  onClick={() => setShowCustomizeModal(true)}
                  className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/40 border border-amber-400 text-amber-300 font-bold text-xs rounded-xs cursor-pointer flex items-center gap-1.5 transition-colors"
                >
                  <User className="w-3.5 h-3.5" />
                  <span>CUSTOMIZE</span>
                </button>
              </div>

              {/* Pillars of the Game */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-3xl w-full my-3 text-left text-xs">
                <div className="p-3 bg-slate-900/90 border border-red-500/50 rounded-xs">
                  <strong className="text-red-400 flex items-center gap-1 font-bold">
                    <span>❤️</span> OPTIONS AS LIFE FORCE
                  </strong>
                  <p className="text-slate-300 mt-1 leading-relaxed">
                    Executing sound trades with disciplined margin restores your <strong>Hearts</strong>. Every 3 sound trades earns a <strong>Heart Container</strong>!
                  </p>
                </div>

                <div className="p-3 bg-slate-900/90 border border-amber-500/50 rounded-xs">
                  <strong className="text-amber-300 flex items-center gap-1 font-bold">
                    <span>⚔️</span> PUZZLE STRIKES
                  </strong>
                  <p className="text-slate-300 mt-1 leading-relaxed">
                    Overworld monsters scale based on your capital. Solve tactical finance puzzles to strike critical damage with your Master Sword!
                  </p>
                </div>

                <div className="p-3 bg-slate-900/90 border border-sky-500/50 rounded-xs">
                  <strong className="text-sky-300 flex items-center gap-1 font-bold">
                    <span>🧚</span> BENJAMIN GRAHAM SANCTUARY
                  </strong>
                  <p className="text-slate-300 mt-1 leading-relaxed">
                    Fall for crypto scams, Ponzi schemes, or run out of hearts? Seek sanctuary with Benjamin Graham to learn timeless value investing lessons.
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap gap-3 justify-center mt-3">
                <button
                  onClick={() => {
                    sound.playFanfare();
                    sound.startMusic('overworld');
                    setIsBgmOn(true);
                    setCurrentView('MAP');
                  }}
                  className="px-6 py-3.5 bg-gradient-to-b from-amber-400 to-amber-600 hover:from-amber-300 hover:to-amber-500 text-slate-950 font-extrabold text-sm sm:text-base cursor-pointer rounded-xs shadow-lg flex items-center gap-2 transform active:scale-95 transition-all"
                >
                  <Play className="w-5 h-5 fill-current" />
                  <span>START QUEST [ENTER OVERWORLD]</span>
                </button>

                <button
                  onClick={() => {
                    sound.playKeyClick();
                    setSaveModalMode('LOAD');
                    setIsAtSaveShrine(false);
                    setShowSaveModal(true);
                  }}
                  className="px-5 py-3.5 bg-slate-900 hover:bg-slate-800 border-2 border-amber-500/70 text-amber-200 font-bold text-sm cursor-pointer rounded-xs flex items-center gap-2 shadow-md transition-colors"
                >
                  <Save className="w-4 h-4 text-amber-400" />
                  <span>RESTORE SAVED CHRONICLES</span>
                </button>

                <button
                  onClick={() => setActiveModal('GRIMOIRE')}
                  className="px-5 py-3.5 bg-slate-900 hover:bg-slate-800 border border-amber-500/40 text-amber-300 font-bold text-sm cursor-pointer rounded-xs transition-colors"
                >
                  READ OPTIONS CODEX
                </button>
              </div>
            </div>
          )}

          {/* TOP-DOWN ZELDA OVERWORLD MAP VIEW */}
          {currentView === 'MAP' && (
            <ZeldaOverworldCanvas
              act={player.chapter}
              player={player}
              asset={assetQuote}
              onMove={handleOverworldMove}
              onInteractEntity={handleInteractEntity}
              onSwordSlash={() => {
                // Slash effects handled inside canvas
              }}
              onOpenSave={() => {
                setSaveModalMode('SAVE');
                setIsAtSaveShrine(false);
                setShowSaveModal(true);
              }}
              onOpenCustomize={() => setShowCustomizeModal(true)}
            />
          )}

          {/* ZELDA COMBAT SCREEN */}
          {currentView === 'COMBAT' && (
            <ZeldaCombatModal
              combat={combatState}
              player={player}
              onExecutePuzzleAttack={handlePuzzleAttack}
              onShieldBlock={handleCombatShield}
              onUseItem={handleCombatItem}
              onFlee={() => {
                sound.playAlarmSound();
                sound.startMusic('dungeon');
                setPlayer(prev => ({
                  ...prev,
                  florins: Math.max(100, prev.florins - 200)
                }));
                setCurrentView('MAP');
              }}
            />
          )}

          {/* VICTORY SCREEN */}
          {currentView === 'VICTORY' && (
            <div className="dos-box p-8 bg-black/95 text-center flex flex-col items-center justify-center min-h-[50vh] border-yellow-400 text-yellow-300">
              <Award className="w-16 h-16 text-yellow-400 mb-2 animate-pulse" />
              <h2 className="text-2xl font-bold uppercase tracking-widest text-yellow-300">
                TRIUMPH OF THE SOVEREIGN VALUE MASTER!
              </h2>
              <p className="text-sm max-w-lg my-4 opacity-90 leading-relaxed text-current">
                You have completed the quest through Valuaria! You avoided ruinous rug pulls, discovered deep value assets with an iron Margin of Safety, and mastered options finance with {player.maxHearts} Heart Containers!
              </p>
              <button
                onClick={handleRestart}
                className="px-6 py-2.5 border-2 border-current bg-current text-black font-extrabold text-sm cursor-pointer hover:opacity-90 flex items-center gap-2"
              >
                <Play className="w-4 h-4" />
                <span>PLAY NEW GAME+ (NEW SEED)</span>
              </button>
            </div>
          )}
        </main>

        {/* Bottom DOS Interactive Terminal */}
        <footer className="mt-2">
          <TerminalCommandLine
            onCommand={(cmd) => {
              const command = cmd.trim().toUpperCase();
              if (command === 'HELP') {
                setTerminalLog(prev => [
                  ...prev.slice(-10),
                  'COMMANDS: TRADE, PORTFOLIO, GRIMOIRE, MAP, REST, STATUS'
                ]);
              } else if (command === 'TRADE') {
                setActiveModal('TRADE');
              } else if (command === 'PORTFOLIO') {
                setActiveModal('PORTFOLIO');
              } else if (command === 'GRIMOIRE') {
                setActiveModal('GRIMOIRE');
              } else if (command === 'REST') {
                handleAdvanceDay();
              } else {
                setTerminalLog(prev => [...prev.slice(-10), `> Command "${cmd}" processed.`]);
              }
            }}
            outputLog={terminalLog}
          />
        </footer>

        {/* MODALS */}
        {/* Undervalued Asset Discovery Modal */}
        {activeUndervaluedAsset && (
          <UndervaluedAssetModal
            asset={activeUndervaluedAsset}
            player={player}
            onSelectChoice={handleSelectUndervaluedChoice}
            onClose={() => setActiveUndervaluedAsset(null)}
          />
        )}

        {/* Rug Pull / Ponzi Lesson Modal */}
        {activeScamEncounter && (
          <RugPullLessonModal
            scam={activeScamEncounter}
            player={player}
            onFallForScam={handleFallForScam}
            onRejectScam={handleRejectScam}
            onClose={() => setActiveScamEncounter(null)}
          />
        )}

        {/* Sanctuary of the Intelligent Investor (When Hearts = 0) */}
        {showSanctuary && (
          <IntelligentInvestorSanctuaryModal
            player={player}
            onRevive={handleReviveInSanctuary}
          />
        )}

        {/* NPC Dialogue Box */}
        {npcDialogue && (
          <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4 font-mono">
            <div className="dos-box w-full max-w-xl bg-black border-2 border-yellow-400 p-4 select-none space-y-3 shadow-2xl">
              <div className="flex items-center justify-between border-b border-yellow-400/50 pb-1">
                <span className="font-bold text-yellow-300 text-sm">{npcDialogue.name}</span>
                <button
                  onClick={() => setNpcDialogue(null)}
                  className="px-2 py-0.5 border border-current hover:bg-current hover:text-black text-xs font-bold cursor-pointer"
                >
                  [ESC] CLOSE
                </button>
              </div>
              <div className="space-y-2 text-xs leading-relaxed text-yellow-100">
                {npcDialogue.lines.map((line, idx) => (
                  <p key={idx} className="italic">{line}</p>
                ))}
              </div>
              <button
                onClick={() => setNpcDialogue(null)}
                className="w-full py-1.5 bg-yellow-400 text-black font-bold text-xs uppercase cursor-pointer hover:bg-yellow-300 text-center"
              >
                CONTINUE [SPACE]
              </button>
            </div>
          </div>
        )}

        {/* Trade Desk Modal */}
        {activeModal === 'TRADE' && (
          <TradeDeskModal
            player={player}
            asset={assetQuote}
            onExecuteTrade={handleExecuteTrade}
            onClose={() => setActiveModal(null)}
          />
        )}

        {/* Portfolio Ledger Modal */}
        {activeModal === 'PORTFOLIO' && (
          <PortfolioLedgerModal
            player={player}
            positions={positions}
            asset={assetQuote}
            onClosePosition={handleClosePosition}
            onExercisePosition={handleExercisePosition}
            onClose={() => setActiveModal(null)}
            riskCategory={riskInfo.riskCategory}
            riskScore={riskInfo.riskScore}
          />
        )}

        {/* Grimoire Modal */}
        {activeModal === 'GRIMOIRE' && (
          <GrimoireModal
            onAwardFlorins={(amount) => {
              sound.playCoinSound();
              setPlayer(prev => ({ ...prev, florins: prev.florins + amount }));
              setTerminalLog(prev => [
                ...prev.slice(-10),
                `[TRIAL SOLVED] Mastered an options finance rune! Awarded +${amount} Guild Florins!`
              ]);
            }}
            onClose={() => setActiveModal(null)}
          />
        )}

        {/* Story Dialog Modal */}
        {activeModal === 'QUEST' && activeQuest && (
          <StoryDialogModal
            quest={activeQuest}
            playerFlorins={player.florins}
            onChoiceSelect={(choice) => {
              if (choice.action) {
                setPlayer(prev => {
                  const copy = { ...prev };
                  choice.action!(copy);
                  return copy;
                });
              }
              setActiveModal(null);
              setActiveQuest(null);
            }}
            onClose={() => {
              setActiveModal(null);
              setActiveQuest(null);
            }}
          />
        )}

        {/* Sacred Chronicles: Save & Load Game Modal */}
        {showSaveModal && (
          <SaveGameModal
            player={player}
            positions={positions}
            assetQuote={assetQuote}
            terminalLog={terminalLog}
            initialMode={saveModalMode}
            isAtShrine={isAtSaveShrine}
            onLoadGame={handleLoadGame}
            onClose={() => setShowSaveModal(false)}
          />
        )}

        {/* Hero Customization & Avatar Naming Modal */}
        {showCustomizeModal && (
          <AvatarCustomizerModal
            currentName={player.name}
            currentTitle={player.avatar?.avatarTitle || player.title}
            currentAvatar={player.avatar}
            onSave={handleSaveProfile}
            onClose={() => setShowCustomizeModal(false)}
          />
        )}
      </div>
    </div>
  );
}
