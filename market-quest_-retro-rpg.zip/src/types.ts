export type DOSTheme = 'green' | 'amber' | 'vga' | 'cyber';

export type TunicColor = 'green' | 'blue' | 'red' | 'purple' | 'black';
export type HairColor = 'blonde' | 'brown' | 'black' | 'white';

export interface AvatarConfig {
  tunicColor: TunicColor;
  hairColor: HairColor;
  shieldStyle: 'wooden' | 'hylian' | 'mirror';
  avatarTitle: string;
}

export interface SaveSlotData {
  id: string;
  slotNumber: number;
  saveName: string;
  savedAt: string;
  locationName: string;
  player: PlayerStats;
  positions: OptionContract[];
  assetQuote: AssetQuote;
  terminalLog: string[];
}

export type ContractType = 'CALL' | 'PUT';

export type StrategyType = 
  | 'LONG_CALL'
  | 'LONG_PUT'
  | 'BULL_CALL_SPREAD'
  | 'BEAR_PUT_SPREAD'
  | 'CASH_SECURED_PUT'
  | 'COVERED_CALL'
  | 'IRON_CONDOR'
  | 'LONG_STRADDLE';

export interface OptionContract {
  id: string;
  symbol: string;
  type: ContractType;
  strike: number;
  dte: number; // Days to expiration
  premium: number; // Current mark price per share
  entryPrice: number;
  quantity: number; // positive = long, negative = short
  strategy: StrategyType;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
}

export interface AssetQuote {
  symbol: string;
  name: string;
  spotPrice: number;
  previousClose: number;
  iv: number; // 0.20 to 0.90 (20% to 90%)
  trend: 'BULLISH' | 'BEARISH' | 'NEUTRAL' | 'VOLATILE';
  lore: string;
}

export interface PlayerStats {
  name: string;
  title: string;
  avatar: AvatarConfig;
  // Zelda Hearts Mechanics
  hearts: number; // Current life force hearts (e.g. 4.0)
  maxHearts: number; // Maximum heart containers (starts at 4, can grow to 8+)
  successfulTradesCount: number; // Tracks good trades; every 3 trades awards +1 Heart Container
  investorTier: number; // 1 = Apprentice, 2 = Enterprising Investor, 3 = Master Oracle
  hp: number; // Legacy numeric gauge (scaled to hearts * 25)
  maxHp: number;
  mana: number;
  maxMana: number;
  florins: number; // Cash gold / rupees
  stockShares: number; // Underlying shares held
  portfolioValue: number;
  marginUsed: number;
  marginLimit: number;
  netDelta: number;
  netGamma: number;
  netTheta: number;
  netVega: number;
  riskScore: number; // 0 (safely hedged) to 100 (catastrophic leverage)
  chapter: number;
  day: number;
  mapX: number;
  mapY: number;
  facing: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
  potions: {
    healthElixir: number;
    ivStabilizer: number;
    timeHourglass: number;
  };
  relics: string[];
  undervaluedAssetsDiscovered: string[];
  scamsFallen: string[];
  scamsAvoided: string[];
  intelligentInvestorRevivals: number;
}

export interface EnemyStats {
  id: string;
  name: string;
  title: string;
  type: 'BEAR' | 'BULL' | 'CRAB' | 'HYDRA' | 'REAPER';
  baseHp: number;
  maxHp: number;
  currentHp: number;
  attackPower: number;
  defense: number;
  riskSensitivity: number; // Scales enemy aggression to player portfolio risk
  marketAffinity: 'CRASH' | 'SURGE' | 'STAGNATION' | 'CHAOS';
  specialMove: string;
  lore: string;
  dialogue: string[];
}

export interface CombatState {
  inCombat: boolean;
  enemy: EnemyStats | null;
  turn: number;
  combatLog: string[];
  lastAction: string | null;
  playerShieldActive: boolean;
  enemyChargingSpecial: boolean;
  marketEventThisTurn: string | null;
  currentPuzzle?: CombatAttackPuzzle | null;
}

export interface CombatAttackPuzzle {
  id: string;
  difficultyTier: number; // 1 = Basic/Apprentice, 2 = Enterprising, 3 = Master
  prompt: string;
  context: string;
  options: {
    label: string;
    text: string;
    isCorrect: boolean;
    explanation: string;
    damageBonus: number;
  }[];
}

export interface UndervaluedAsset {
  id: string;
  name: string;
  symbol: string;
  category: string;
  locationName: string;
  description: string;
  marketSpot: number;
  intrinsicValue: number;
  bookValuePerShare: number;
  cashPerShare: number;
  peRatio: number;
  marginOfSafetyPercent: number;
  currentIv: number;
  catalyst: string;
  choices: {
    title: string;
    description: string;
    actionType: 'VALUE_BUY_COVERED_CALL' | 'DEEP_ITM_LEAPS' | 'QUICK_SPECULATE_FLIP' | 'SHORT_THE_ASSET';
    costFlorins: number;
    heartsEffect: number;
    awardsHeartContainer?: boolean;
    consequenceText: string;
    florinsGain: number;
    spotShiftPercent: number;
  }[];
}

export interface ScamEncounter {
  id: string;
  scamType: 'PONZI_YIELD' | 'PUMP_AND_DUMP' | 'RUG_PULL_TOKEN' | 'UNREGISTERED_TURBO_LEVERAGE';
  title: string;
  shillerName: string;
  shillerTitle: string;
  pitch: string;
  promiseText: string;
  costFlorins: number;
  temptationOutcome: {
    rugPullHeadline: string;
    storyExplanation: string;
    heartsLost: number; // Drops hearts to teach harsh lesson!
    intelligentInvestorLesson: string;
    chapterReference: string;
  };
  rejectionOutcome: {
    response: string;
    rewardFlorins: number;
    rewardWisdom: string;
  };
}

export interface IntelligentInvestorLesson {
  id: string;
  title: string;
  chapter: string;
  quote: string;
  corePhilosophy: string;
  whyYouFailed: string;
  reflectionQuestion: {
    prompt: string;
    choices: string[];
    correctIndex: number;
    explanation: string;
  };
}

export interface StoryChoice {
  text: string;
  costFlorins?: number;
  requiredRelic?: string;
  lessonKey?: string;
  outcomeText: string;
  action?: (state: any) => void;
  marketImpact?: {
    spotChangePercent?: number;
    ivChangePercent?: number;
  };
  combatTrigger?: string;
}

export interface QuestNode {
  id: string;
  title: string;
  locationName: string;
  description: string;
  speaker?: string;
  optionsLesson: string;
  choices: StoryChoice[];
}

export type GameView = 
  | 'INTRO'
  | 'MAP'
  | 'QUEST'
  | 'COMBAT'
  | 'TRADE_DESK'
  | 'PORTFOLIO'
  | 'GRIMOIRE'
  | 'UNDERVALUED_ASSET'
  | 'SCAM_ENCOUNTER'
  | 'INTELLIGENT_INVESTOR'
  | 'VICTORY'
  | 'GAME_OVER';
