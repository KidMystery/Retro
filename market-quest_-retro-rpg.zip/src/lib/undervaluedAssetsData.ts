import { UndervaluedAsset } from '../types';

export const UNDERVALUED_ASSETS: { [key: string]: UndervaluedAsset } = {
  'silver_mine': {
    id: 'silver_mine',
    name: 'The Sunken Silver Mine of Deep Value',
    symbol: '$SLVR',
    category: 'Hard Commodities & Mining',
    locationName: 'The Forgotten Quarry of Act 1',
    description: 'Hidden beneath moss and broken cart tracks, you discover the deeds and assay reports of a forgotten silver mine. Panic in town drove the market quote to $42 Florins, yet the underground vaults hold verified physical bullion and liquid cash worth $78 Florins per share, with zero outstanding debt!',
    marketSpot: 42,
    intrinsicValue: 78,
    bookValuePerShare: 78,
    cashPerShare: 32,
    peRatio: 4.1,
    marginOfSafetyPercent: 46.1, // (78 - 42) / 78
    currentIv: 0.18, // 18% IV - dirt cheap options!
    catalyst: 'Next quarter sovereign audit will publicly verify the vault holdings.',
    choices: [
      {
        title: 'Deep Value Buy & Sell Covered Call (Strike $50, 45 DTE)',
        description: 'Acquire 100 shares at $42, then sell an out-of-the-money Call option to harvest immediate premium income while retaining upside to $50.',
        actionType: 'VALUE_BUY_COVERED_CALL',
        costFlorins: 3800, // 4200 - 400 premium received
        heartsEffect: 1.5,
        awardsHeartContainer: true,
        consequenceText: 'Exemplary discipline! You acquired physical assets for 54 cents on the dollar and collected 400ƒ upfront option premium. When the audit publishes, the stock re-rates to $55. Your covered call caps profit at a glorious +36% return, and your sound investment discipline earns you a HEART CONTAINER!',
        florinsGain: 1200,
        spotShiftPercent: 0.28
      },
      {
        title: 'Acquire Deep In-The-Money LEAPS (Strike $30 Call, 180 DTE)',
        description: 'Purchase high-delta, low-extrinsic-decay long-term options to gain massive leverage on the fundamental rerating with strictly defined downside.',
        actionType: 'DEEP_ITM_LEAPS',
        costFlorins: 1500,
        heartsEffect: 1.0,
        awardsHeartContainer: true,
        consequenceText: 'Masterful derivatives application! Because IV was depressed at 18%, the LEAPS had minimal extrinsic premium. As the market wakes up to the silver reserves, your call option gains +190% in value! You earn a HEART CONTAINER for patient value capture!',
        florinsGain: 2850,
        spotShiftPercent: 0.35
      },
      {
        title: 'Quick Flip to Shady Speculator for Immediate 300ƒ Profit',
        description: 'Sell the deeds instantly to a passing pawn merchant for a meager instant markup.',
        actionType: 'QUICK_SPECULATE_FLIP',
        costFlorins: 0,
        heartsEffect: 0,
        consequenceText: 'You grabbed a quick 300ƒ profit, but within days the pawn merchant sold the mine for quadruple that to the Royal Guild. You made a penny while leaving the dollars on the table.',
        florinsGain: 300,
        spotShiftPercent: 0.05
      },
      {
        title: 'Short the Asset (Buy OTM Put) Betting the Decline Continues',
        description: 'Follow the crowd momentum and buy Put options betting the stock will fall even further.',
        actionType: 'SHORT_THE_ASSET',
        costFlorins: 400,
        heartsEffect: -1.5,
        consequenceText: 'Catastrophic error! You shorted an asset trading below its liquid net cash value. As Benjamin Graham warned, shorting deep value assets exposes you to violent upward re-ratings. The stock doubles, your puts expire worthless, and you lose 1.5 Hearts from stress & losses!',
        florinsGain: -400,
        spotShiftPercent: 0.40
      }
    ]
  },
  'grain_silo': {
    id: 'grain_silo',
    name: 'The Royal Grain Mill & Granary',
    symbol: '$WHEAT',
    category: 'Essential Agriculture & Food Infrastructure',
    locationName: 'The Stagnant Fields of Act 2',
    description: 'A temporary drought scare caused irrational panic. Market traders dumped $WHEAT shares down to $28 Florins. Yet the company has modernized automated silos, 5 years of steady grain contracts, and a replacement cost of $65 Florins per share.',
    marketSpot: 28,
    intrinsicValue: 65,
    bookValuePerShare: 65,
    cashPerShare: 18,
    peRatio: 5.2,
    marginOfSafetyPercent: 56.9,
    currentIv: 0.22,
    catalyst: 'Bumper harvest contracts arriving next month.',
    choices: [
      {
        title: 'Deploy Cash-Secured Put (Strike $25, Collect 250ƒ Premium)',
        description: 'Agree to buy shares at an even deeper bargain of $25 if assigned, collecting upfront premium in the meantime.',
        actionType: 'VALUE_BUY_COVERED_CALL',
        costFlorins: 0,
        heartsEffect: 1.0,
        awardsHeartContainer: true,
        consequenceText: 'Brilliant Buffet-style move! You offered to buy a wonderful business at an absurd bargain while pocketing 250ƒ cash. The stock stayed well above $25, so the options expired worthless and you kept 100% of the premium! You gain a HEART CONTAINER!',
        florinsGain: 250,
        spotShiftPercent: 0.20
      },
      {
        title: 'Buy 50 Shares & Hold for Fair Value Convergence',
        description: 'Invest directly into the equity with an iron Margin of Safety.',
        actionType: 'VALUE_BUY_COVERED_CALL',
        costFlorins: 1400,
        heartsEffect: 1.0,
        consequenceText: 'Patience rewarded! Over the coming weeks, fears subsided and $WHEAT rallied to $52 Florins. You sell at fair value for +1,200 Florins profit and restore your life force!',
        florinsGain: 1200,
        spotShiftPercent: 0.45
      },
      {
        title: 'Gamble on 0-DTE Out-of-the-Money Calls (Strike $45)',
        description: 'Bet that the stock will miraculously jump 60% by tomorrow afternoon.',
        actionType: 'SHORT_THE_ASSET',
        costFlorins: 350,
        heartsEffect: -1.0,
        consequenceText: 'Folly! The business is great, but 0-DTE calls give no time for value to be recognized. Theta decay crushed your option to zero before the harvest news arrived. You lose 1 Heart!',
        florinsGain: -350,
        spotShiftPercent: 0.05
      }
    ]
  },
  'toll_bridge': {
    id: 'toll_bridge',
    name: 'The Iron River Bridge & Aqueduct',
    symbol: '$TOLL',
    category: 'Monopolistic Infrastructure Utility',
    locationName: 'The High Fortress Gates of Act 3',
    description: 'Every wagon travelling between Northern and Southern Aethelgard must cross this stone bridge. It yields a predictable 11% dividend yield. Due to a minor repair delay, jittery paper-hands pushed the stock to $50 Florins against discounted cash flow value of $95.',
    marketSpot: 50,
    intrinsicValue: 95,
    bookValuePerShare: 95,
    cashPerShare: 20,
    peRatio: 6.8,
    marginOfSafetyPercent: 47.3,
    currentIv: 0.15,
    catalyst: 'Repairs finish 2 weeks ahead of schedule; toll revenue spikes.',
    choices: [
      {
        title: 'Construct a Bull Call Spread (Buy 50 Call / Sell 70 Call)',
        description: 'Define your risk, finance your long strike with a short strike, and target the re-pricing to $70.',
        actionType: 'VALUE_BUY_COVERED_CALL',
        costFlorins: 600,
        heartsEffect: 2.0,
        awardsHeartContainer: true,
        consequenceText: 'Textbook institutional spread! When repairs concluded, the stock rocketed to $72. Your spread captured the maximum $2,000 payoff for a net gain of +1,400ƒ! Your life force swells with a HEART CONTAINER!',
        florinsGain: 1400,
        spotShiftPercent: 0.42
      },
      {
        title: 'Pass By and Ignore the Opportunity',
        description: 'Walk away without inspecting the toll records.',
        actionType: 'QUICK_SPECULATE_FLIP',
        costFlorins: 0,
        heartsEffect: 0,
        consequenceText: 'You let a rare moat utility slip past your fingers. As Warren Buffett teaches, opportunities to buy wonderful monopolies with deep margin of safety are rare gifts.',
        florinsGain: 0,
        spotShiftPercent: 0.10
      }
    ]
  }
};
