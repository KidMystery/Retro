export interface ZeldaEntity {
  id: string;
  name: string;
  type: 'NPC_SAGE' | 'NPC_BROKER' | 'NPC_SCAMMER' | 'NPC_ASSET' | 'BOSS' | 'CHEST' | 'SHRINE' | 'PORTAL';
  x: number;
  y: number;
  sprite: string;
  dialogue?: string[];
  interactPrompt: string;
  targetId?: string; // Links to scamId or assetId
}

export interface ZeldaMap {
  act: number;
  name: string;
  regionTitle: string;
  width: number;
  height: number;
  tiles: string[]; // ASCII layout of tiles
  entities: ZeldaEntity[];
  playerSpawn: { x: number; y: number };
}

// Tile Legend:
// . = Grass
// T = Tree (solid)
// ~ = Water (solid)
// = = Wooden Bridge (walkable over water)
// P = Stone Path (walkable)
// # = Dungeon Wall / Rock (solid)
// D = Cave / Door entrance
// F = Flower / Flora

export const ZELDA_MAPS: { [act: number]: ZeldaMap } = {
  1: {
    act: 1,
    name: 'The Fair Value Forest & Grove of Strikes',
    regionTitle: 'Overworld Sector A-1: The Valley of Capital',
    width: 20,
    height: 14,
    tiles: [
      'TTTTTTTTTTTTTTTTTTTT',
      'T....P....TT...TT..T',
      'T.F..P..F.TT.D.TT..T',
      'T....P....TT...TT..T',
      'TPPPPPPPPPPPPPPPPPPT',
      'T....P~~~~~~~.....PT',
      'T....P~====~P.....PT',
      'TT.T.P~~~~~~~P....PT',
      'T....PPPPPPPPP....PT',
      'T.F......T........PT',
      'T........T..F.....PT',
      'T..D.....T........PT',
      'T........T....D...PT',
      'TTTTTTTTTTTTTTTTTTTT'
    ],
    playerSpawn: { x: 5, y: 4 },
    entities: [
      {
        id: 'sage_graham',
        name: 'Sage Benjamin Graham',
        type: 'NPC_SAGE',
        x: 3,
        y: 2,
        sprite: 'SAGE',
        interactPrompt: 'Speak to Sage Graham [Margin of Safety]',
        dialogue: [
          '"Greetings, young apprentice. Welcome to Valuaria!"',
          '"In this world, your HEARTS are your financial life force. Every sound options trade replenishes your spirit."',
          '"Beware: shady charlatans roam these woods promising 10,000% APY and meme coin rockets. Fall for a rug pull, and your hearts will shatter!"',
          '"Seek out true Undervalued Assets in the forgotten caves. When price is far below intrinsic value, you hold the shield of Margin of Safety!"'
        ]
      },
      {
        id: 'broker_lyra',
        name: 'Options Guildmaster Lyra',
        type: 'NPC_BROKER',
        x: 8,
        y: 2,
        sprite: 'BROKER',
        interactPrompt: 'Open Derivatives Exchange [Trade Options]',
        dialogue: [
          '"The Crown Index ($AETH) trades at $100 Florins today."',
          '"Do you wish to forge Call Options to ride bullish winds, or Protective Puts to hedge against sudden drawdowns?"'
        ]
      },
      {
        id: 'scam_shiller',
        name: 'Shady Ponzi Alchemist',
        type: 'NPC_SCAMMER',
        x: 14,
        y: 6,
        sprite: 'SCAMMER',
        interactPrompt: 'Approach Hooded Alchemist [High Yield Offer]',
        targetId: 'ponzi_farm'
      },
      {
        id: 'scam_goblin',
        name: 'Telegram Meme Shiller',
        type: 'NPC_SCAMMER',
        x: 10,
        y: 10,
        sprite: 'SCAMMER',
        interactPrompt: 'Talk to Whispering Goblin [$DogeTulip Rocket]',
        targetId: 'crypto_meme_pump'
      },
      {
        id: 'undervalued_mine',
        name: 'Deed to Sunken Silver Mine',
        type: 'NPC_ASSET',
        x: 3,
        y: 11,
        sprite: 'ASSET',
        interactPrompt: 'Inspect Abandoned Mine Works [Deep Value Asset]',
        targetId: 'silver_mine'
      },
      {
        id: 'shrine_save_act1',
        name: 'Sacred Save Shrine of Valuaria',
        type: 'SHRINE',
        x: 2,
        y: 6,
        sprite: 'SHRINE',
        interactPrompt: 'Pray at Sacred Save Shrine [Preserve Quest]'
      },
      {
        id: 'chest_heart',
        name: 'Ancient Treasury Chest',
        type: 'CHEST',
        x: 16,
        y: 2,
        sprite: 'CHEST',
        interactPrompt: 'Open Guild Treasury Chest'
      },
      {
        id: 'boss_bear',
        name: 'Grizzly Bear of Drawdowns',
        type: 'BOSS',
        x: 14,
        y: 12,
        sprite: 'BOSS',
        interactPrompt: 'Engage Guardian Beast [Dungeon Boss Combat]'
      }
    ]
  },
  2: {
    act: 2,
    name: 'The Theta Steppes & Oasis of Stagnation',
    regionTitle: 'Overworld Sector B-2: The Desert of Time',
    width: 20,
    height: 14,
    tiles: [
      '####################',
      '#....P....##...##..#',
      '#....P....##.D.##..#',
      '#....P....##...##..#',
      '#PPPPPPPPPPPPPPPPPP#',
      '#....P~~~~~~~.....P#',
      '#....P~====~P.....P#',
      '##.#.P~~~~~~~P....P#',
      '#....PPPPPPPPP....P#',
      '#........#........P#',
      '#........#........P#',
      '#..D.....#........P#',
      '#........#....D...P#',
      '####################'
    ],
    playerSpawn: { x: 5, y: 4 },
    entities: [
      {
        id: 'sage_graham_2',
        name: 'Sage Graham\'s Echo',
        type: 'NPC_SAGE',
        x: 3,
        y: 2,
        sprite: 'SAGE',
        interactPrompt: 'Consult Graham\'s Wisdom [Time & Speculation]',
        dialogue: [
          '"Here in the Desert of Time, Theta decay accelerates!"',
          '"Buying short-dated lottery calls here is slow suicide. The intelligent investor sells premium or establishes defined calendar spreads."'
        ]
      },
      {
        id: 'broker_act2',
        name: 'Desert Oasis Exchange',
        type: 'NPC_BROKER',
        x: 8,
        y: 2,
        sprite: 'BROKER',
        interactPrompt: 'Enter Oasis Derivatives Exchange',
        dialogue: [
          '"Spot $AETH is steady at $112 Florins. Time decay is eating option buyers alive!"'
        ]
      },
      {
        id: 'scam_leverage',
        name: 'Shadow Margin Lord',
        type: 'NPC_SCAMMER',
        x: 14,
        y: 6,
        sprite: 'SCAMMER',
        interactPrompt: 'Listen to Shadow Broker [100x Turbo Leverage]',
        targetId: 'turbo_leverage_vault'
      },
      {
        id: 'undervalued_grain',
        name: 'The Royal Granary & Grain Mill',
        type: 'NPC_ASSET',
        x: 3,
        y: 11,
        sprite: 'ASSET',
        interactPrompt: 'Inspect Granary Balance Sheet [Undervalued Asset]',
        targetId: 'grain_silo'
      },
      {
        id: 'shrine_save_act2',
        name: 'Oasis Save Shrine',
        type: 'SHRINE',
        x: 2,
        y: 6,
        sprite: 'SHRINE',
        interactPrompt: 'Pray at Oasis Save Shrine [Preserve Quest]'
      },
      {
        id: 'chest_act2',
        name: 'Hourglass Relic Chest',
        type: 'CHEST',
        x: 16,
        y: 2,
        sprite: 'CHEST',
        interactPrompt: 'Open Ancient Chest'
      },
      {
        id: 'boss_sphinx',
        name: 'The Chrono-Sphinx',
        type: 'BOSS',
        x: 14,
        y: 12,
        sprite: 'BOSS',
        interactPrompt: 'Challenge Chrono-Sphinx [Combat Trial]'
      }
    ]
  },
  3: {
    act: 3,
    name: 'The Iron Fortress of Rangebound Bastions',
    regionTitle: 'Sector C-3: The Citadel of Iron Condors',
    width: 20,
    height: 14,
    tiles: [
      '####################',
      '#....P....##...##..#',
      '#....P....##.D.##..#',
      '#....P....##...##..#',
      '#PPPPPPPPPPPPPPPPPP#',
      '#....P~~~~~~~.....P#',
      '#....P~====~P.....P#',
      '##.#.P~~~~~~~P....P#',
      '#....PPPPPPPPP....P#',
      '#........#........P#',
      '#........#........P#',
      '#..D.....#........P#',
      '#........#....D...P#',
      '####################'
    ],
    playerSpawn: { x: 5, y: 4 },
    entities: [
      {
        id: 'shrine_save_act3',
        name: 'Citadel Save Shrine',
        type: 'SHRINE',
        x: 2,
        y: 6,
        sprite: 'SHRINE',
        interactPrompt: 'Pray at Citadel Save Shrine [Preserve Quest]'
      },
      {
        id: 'broker_act3',
        name: 'Fortress Vault Exchange',
        type: 'NPC_BROKER',
        x: 8,
        y: 2,
        sprite: 'BROKER',
        interactPrompt: 'Trade Iron Condor Spreads',
        dialogue: [
          '"Market is locked tightly in range ($118 - $124). Iron Condors reign supreme here!"'
        ]
      },
      {
        id: 'undervalued_bridge',
        name: 'The Toll Bridge Utility Deeds',
        type: 'NPC_ASSET',
        x: 3,
        y: 11,
        sprite: 'ASSET',
        interactPrompt: 'Inspect Toll Bridge Cashflow [Undervalued Moat]',
        targetId: 'toll_bridge'
      },
      {
        id: 'boss_crab',
        name: 'Crab Golem of Sideways Range',
        type: 'BOSS',
        x: 14,
        y: 12,
        sprite: 'BOSS',
        interactPrompt: 'Confront Crab Golem'
      }
    ]
  }
};
