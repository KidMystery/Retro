import { ScamEncounter } from '../types';

export const SCAM_ENCOUNTERS: { [key: string]: ScamEncounter } = {
  'ponzi_farm': {
    id: 'ponzi_farm',
    scamType: 'PONZI_YIELD',
    title: 'The Alchemist\'s "Guaranteed 10,000% APY" Liquidity Pool',
    shillerName: 'Alchemist Sam "SBF" of Babylon',
    shillerTitle: 'Chief High-Priest of Algorithmic Yield',
    pitch: '"Greetings, traveler! Why toil for 8% annual returns when my mystical Black Box Pool guarantees 25% DAILY compounded returns? Deposit your Florins into our algorithmic stake-vault. We use advanced quantum rebasing to generate wealth out of thin air!"',
    promiseText: 'Guaranteed 25% Daily APY. Zero risk promised. "Mathematically impossible to lose!"',
    costFlorins: 1500,
    temptationOutcome: {
      rugPullHeadline: '🚨 DISASTER! ALGORITHMIC VAULT RUG PULL & INSOLVENCY COLLAPSE! 🚨',
      storyExplanation: 'Three days after depositing your hard-earned 1,500 Florins, the withdrawal portal locks up! The Alchemist posted on the town board: "Assets are temporarily halted for system upgrade," before fleeing on a midnight pegasus to the Caribbean archipelago. The pool was empty—early depositors were simply paid with your money!',
      heartsLost: 2.0, // Loses 2 full hearts!
      intelligentInvestorLesson: 'BENJAMIN GRAHAM LAW: "The most dangerous illusion is the promise of extraordinary, risk-free returns. In any enterprise where returns are paid not from economic production or tangible earnings, but from incoming deposits, the structure is inevitably a Ponzi scheme. When you do not understand where the yield comes from, YOU are the yield."',
      chapterReference: 'The Intelligent Investor — Chapter 1: Investment vs. Speculation'
    },
    rejectionOutcome: {
      response: '"Where do the returns originate? What tangible goods or services does this pool produce?" The Alchemist stammers incoherently and tries to change the subject.',
      rewardFlorins: 350,
      rewardWisdom: 'You exposed the Ponzi scheme! The Town Constable overhears and arrests the charlatan, awarding you 350 Florins for protecting the citizens!'
    }
  },
  'crypto_meme_pump': {
    id: 'crypto_meme_pump',
    scamType: 'PUMP_AND_DUMP',
    title: 'The Telegram Shill Goblin\'s $DogeTulip Rocket',
    shillerName: 'Shill Goblin Jax',
    shillerTitle: 'VIP Alpha Insider Group Admin',
    pitch: '"Psst! Hey kid, come close! Our private secret cabal is pumping $DogeTulip Coin tonight at midnight! Look at these rocket emojis 🚀🚀🚀! The devs locked liquidity for 10 minutes (trust me bro). Put in 1,000 Florins right now and you\'ll 100x by breakfast!"',
    promiseText: '100x Instant Gains. "Backed by viral community vibes and hype!"',
    costFlorins: 1000,
    temptationOutcome: {
      rugPullHeadline: '🚨 BRUTAL RUG PULL! DEVELOPER DUMPED 99.8% OF TOKEN SUPPLY! 🚨',
      storyExplanation: 'You handed over 1,000 Florins. The price briefly spiked for 60 seconds on the tavern board. Suddenly, a single gigantic sell order wiped out the entire order book! The creator dumped their pre-mined tokens, took all the guild Florins, and deleted the message channel. Your tokens are now worth $0.000001.',
      heartsLost: 2.0, // Loses 2 full hearts!
      intelligentInvestorLesson: 'BENJAMIN GRAHAM LAW: "The speculative public is inveterately attracted to price momentum without regard for intrinsic worth. Buying an unbacked token in hopes of selling to a greater fool is pure gambling. Price is what you pay; value is what you get. When you chase hype without financial statements or audited assets, you will inevitably hold the bag."',
      chapterReference: 'The Intelligent Investor — Chapter 8: The Investor and Market Fluctuations'
    },
    rejectionOutcome: {
      response: '"Show me the audited smart contract, token distribution schedule, and real-world cash flows." The goblin screeches in terror and scurries into the bushes!',
      rewardFlorins: 200,
      rewardWisdom: 'You avoided the greater-fool trap! Your discipline preserves your capital and strengthens your analytical foresight.'
    }
  },
  'turbo_leverage_vault': {
    id: 'turbo_leverage_vault',
    scamType: 'UNREGISTERED_TURBO_LEVERAGE',
    title: 'The Shadow Broker\'s 100x Naked Leverage Casino',
    shillerName: 'Lord Marginatus',
    shillerTitle: 'Merchant of Uncapped Downside',
    pitch: '"Why waste your time with defined-risk spreads? Real warriors take 100x unhedged margin! Sign this blood contract: if the market goes up 1%, you double your net worth! (If it dips 0.5%, your entire family estate is liquidated, but don\'t worry about that)."',
    promiseText: '100x Turbo Leverage. Uncapped upside, catastrophic hidden downside.',
    costFlorins: 2000,
    temptationOutcome: {
      rugPullHeadline: '🚨 INSTANT LIQUIDATION! A 0.4% VOLATILITY WICK WIPED YOU OUT! 🚨',
      storyExplanation: 'You signed the contract and took 100x leverage. A random 10-second market jitter blipped spot price down by a fraction of a percent. The broker\'s automated liquidation bots seized all 2,000 Florins and issued an immediate Margin Call notice!',
      heartsLost: 2.5, // Severe damage!
      intelligentInvestorLesson: 'BENJAMIN GRAHAM LAW: "Unregulated leverage turns investing into a suicide race against volatility noise. Even if your long-term thesis is correct, extreme leverage guarantees that normal short-term market fluctuations will liquidate you before the thesis plays out. Always maintain an iron Margin of Safety."',
      chapterReference: 'The Intelligent Investor — Chapter 20: Margin of Safety as the Central Concept'
    },
    rejectionOutcome: {
      response: '"I trade only with defined risk and prudent margin limits. Uncapped negative asymmetry is financial madness."',
      rewardFlorins: 250,
      rewardWisdom: 'You rejected ruinous leverage! Your risk score stays pristine and your capital lives to fight another day.'
    }
  }
};
