import { IntelligentInvestorLesson } from '../types';

export const INTELLIGENT_INVESTOR_LESSONS: IntelligentInvestorLesson[] = [
  {
    id: 'margin_of_safety',
    title: 'The Central Concept: Margin of Safety',
    chapter: 'Chapter 20 — "Margin of Safety" as the Central Concept of Investment',
    quote: '"Confronted with the challenge to distill the secret of sound investment into three words, we venture the motto, MARGIN OF SAFETY."',
    corePhilosophy: 'The margin of safety is the gap between the intrinsic value of an asset and the price you pay for it. If a bridge can hold a 10,000-pound truck, you do not build it to carry only 10,000 pounds—you build it to carry 30,000 pounds to withstand storms, sudden shocks, and structural flaws. In investing and options trading, the margin of safety prevents unavoidable miscalculations and bad luck from destroying your capital.',
    whyYouFailed: 'You allowed your margin of safety to shrink to zero through unhedged leverage, excessive option premium speculation, or paying inflated prices for assets without tangible underlying book value.',
    reflectionQuestion: {
      prompt: 'Which of the following actions best embodies the "Margin of Safety" principle in options trading?',
      choices: [
        'Buying deep out-of-the-money 0-DTE call options with all available cash.',
        'Purchasing an undervalued company at a 40% discount to tangible book value and selling out-of-the-money covered calls to hedge downside.',
        'Borrowing the maximum available margin to take 100x unhedged long futures bets.',
        'Staking your entire net worth into an unaudited 10,000% APY crypto yield pool.'
      ],
      correctIndex: 1,
      explanation: 'Buying at a steep discount to net asset value provides a cushion against adverse events, while covered call premium further cushions downside risk. This is the essence of Benjamin Graham\'s Margin of Safety.'
    }
  },
  {
    id: 'mr_market',
    title: 'The Parable of Mr. Market & Emotional Discipline',
    chapter: 'Chapter 8 — The Investor and Market Fluctuations',
    quote: '"The investor\'s chief problem—and even his worst enemy—is likely to be himself."',
    corePhilosophy: 'Imagine you own a business share with an eccentric partner named Mr. Market. Every single day, he knocks on your door and quotes a price at which he will buy your share or sell you his. When he is manic and exuberant, he quotes ridiculously high prices. When he is depressed and panic-stricken, he quotes ridiculously low prices. You are not obliged to do business with him unless his price suits your reasoned calculation. The true investor uses Mr. Market\'s wild mood swings to their advantage, never as a master of their emotional state.',
    whyYouFailed: 'You allowed Mr. Market\'s frenzy or panic to dictate your trades. You FOMOed into inflated highs and panicked out at temporary bottoms instead of exploiting market dislocations with defined-risk hedges.',
    reflectionQuestion: {
      prompt: 'How should an intelligent investor treat Mr. Market\'s daily price quotes?',
      choices: [
        'Assume Mr. Market is omniscient and always reflects fair value.',
        'Treat Mr. Market as an emotional servant: sell to him when he is manically overpaying, and buy from him when he is unreasonably depressed.',
        'Panic and sell all holdings whenever Mr. Market drops prices during short-term market corrections.',
        'Copy whatever trade trending influencers on social media are broadcasting.'
      ],
      correctIndex: 1,
      explanation: 'Mr. Market exists to serve you with trading opportunities, not to guide your opinions. You must form your own independent valuation.'
    }
  },
  {
    id: 'investment_vs_speculation',
    title: 'Investment versus Speculation',
    chapter: 'Chapter 1 — Investment versus Speculation: Results to Be Expected',
    quote: '"An investment operation is one which, upon thorough analysis promises safety of principal and an adequate return. Operations not meeting these requirements are speculative."',
    corePhilosophy: 'Speculators gamble on whether the next person will pay more for a scrap of paper tomorrow (the Greater Fool Theory). Investors purchase productive assets where audited earnings, assets, and dividends justify the price paid. When trading options, speculative traders treat options like lottery scratch-offs, whereas intelligent investors use options as defined-risk insurance policies and cashflow tools.',
    whyYouFailed: 'You mistook pure speculation for investing. You chased shiny promises of overnight 100x riches instead of conducting rigorous valuation of principal safety.',
    reflectionQuestion: {
      prompt: 'According to Benjamin Graham, what are the three indispensable pillars of an authentic investment operation?',
      choices: [
        'Hype, social media momentum, and high leverage.',
        'Thorough analysis, safety of principal, and an adequate (not miraculous) return.',
        'Secret insider telegram signals, fast algorithmic execution, and zero research.',
        'Holding indefinitely without ever checking balance sheets or earnings reports.'
      ],
      correctIndex: 1,
      explanation: 'Graham defined an investment as an operation that guarantees thorough analysis, protection of your principal, and an adequate return.'
    }
  }
];
