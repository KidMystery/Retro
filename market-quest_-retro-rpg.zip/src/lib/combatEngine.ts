import { EnemyStats, PlayerStats, OptionContract } from '../types';

export interface CombatTurnResult {
  playerDamageDealt: number;
  enemyDamageDealt: number;
  playerHealed: number;
  manaSpent: number;
  logMessages: string[];
  enemyDefeated: boolean;
  playerDefeated: boolean;
  marketShift?: {
    spotChange: number;
    ivChange: number;
  };
}

/**
 * Calculates dynamic risk score (0 to 100) based on player's options portfolio
 */
export function calculatePortfolioRisk(
  player: PlayerStats,
  positions: OptionContract[]
): {
  riskScore: number;
  marginUtilization: number;
  riskCategory: 'SAFE' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  reasons: string[];
} {
  const reasons: string[] = [];
  let score = 10; // baseline

  // 1. Margin Utilization
  const marginUtil = player.marginLimit > 0 ? player.marginUsed / player.marginLimit : 0;
  if (marginUtil > 0.85) {
    score += 45;
    reasons.push('Extreme Margin Utilization (>85%) - Liquidation imminent!');
  } else if (marginUtil > 0.60) {
    score += 25;
    reasons.push('Elevated Margin Utilization (>60%)');
  } else if (marginUtil > 0.30) {
    score += 10;
  } else {
    reasons.push('Healthy Cash Reserve / Low Margin Usage');
  }

  // 2. Net Theta bleed
  if (player.netTheta < -40) {
    score += 20;
    reasons.push('Severe Daily Theta Bleed (< -40 Florins/day)');
  } else if (player.netTheta < -15) {
    score += 10;
    reasons.push('Moderate Theta Bleed');
  } else if (player.netTheta > 10) {
    score -= 15;
    reasons.push('Positive Theta Flow (Earning Daily Premium)');
  }

  // 3. Unhedged Delta Directional Exposure
  const absDelta = Math.abs(player.netDelta);
  if (absDelta > 2.5) {
    score += 20;
    reasons.push('Extreme Unhedged Directional Exposure (Delta > 2.5)');
  } else if (absDelta > 1.2) {
    score += 10;
    reasons.push('Moderate Directional Bias');
  } else if (absDelta < 0.4 && positions.length > 0) {
    score -= 10;
    reasons.push('Near Delta-Neutral Balance');
  }

  // 4. Check for defined risk strategies (Spreads, Condors)
  const hasDefinedRisk = positions.some(p => 
    p.strategy === 'BULL_CALL_SPREAD' || 
    p.strategy === 'BEAR_PUT_SPREAD' || 
    p.strategy === 'IRON_CONDOR'
  );
  if (hasDefinedRisk) {
    score -= 15;
    reasons.push('Defined-Risk Spread Armor Active');
  }

  const clampedScore = Math.max(0, Math.min(100, Math.round(score)));
  let category: 'SAFE' | 'MODERATE' | 'HIGH' | 'CRITICAL' = 'SAFE';
  if (clampedScore >= 75) category = 'CRITICAL';
  else if (clampedScore >= 50) category = 'HIGH';
  else if (clampedScore >= 25) category = 'MODERATE';

  return {
    riskScore: clampedScore,
    marginUtilization: Number(marginUtil.toFixed(2)),
    riskCategory: category,
    reasons
  };
}

/**
 * Scales enemy stats based on player capital and portfolio risk
 */
export function getScaledEnemyStats(
  baseEnemy: EnemyStats,
  player: PlayerStats,
  riskScore: number
): EnemyStats {
  // Capital Scaling: Richer players face tougher enemies
  const capitalRatio = Math.max(1, player.portfolioValue / 10000);
  const scaledMaxHp = Math.round(baseEnemy.baseHp * (1 + (capitalRatio - 1) * 0.45));
  
  // Risk Scaling: Higher risk amplifies attack power and crit rate
  const riskMultiplier = 1.0 + (riskScore / 100) * (baseEnemy.riskSensitivity || 1.5);
  const scaledAttack = Math.round(baseEnemy.attackPower * riskMultiplier);

  return {
    ...baseEnemy,
    maxHp: scaledMaxHp,
    currentHp: scaledMaxHp,
    attackPower: scaledAttack
  };
}

/**
 * Resolves a player combat action
 */
export function resolveCombatAction(
  action: 'STRIKE' | 'HEDGE_SHIELD' | 'STRADDLE_SHOCK' | 'THETA_SIPHON' | 'USE_ELIXIR' | 'USE_HOURGLASS',
  player: PlayerStats,
  enemy: EnemyStats,
  riskScore: number,
  shieldActive: boolean
): CombatTurnResult {
  const log: string[] = [];
  let playerDmg = 0;
  let enemyDmg = 0;
  let playerHealed = 0;
  let manaCost = 0;
  let spotDelta = 0;
  let ivDelta = 0;

  // 1. Execute Player Action
  if (action === 'STRIKE') {
    manaCost = 0;
    // Delta-boosted physical strike
    const baseDamage = 22 + Math.floor(Math.random() * 12);
    const deltaBonus = Math.round(player.netDelta * 15);
    playerDmg = Math.max(10, baseDamage + deltaBonus);
    log.push(`> You execute a Rune Strike for ${playerDmg} physical damage (Delta mod: ${deltaBonus >= 0 ? '+' : ''}${deltaBonus}).`);
  } 
  else if (action === 'HEDGE_SHIELD') {
    manaCost = 15;
    log.push(`> You invoke the [Protective Put Hedge]! A shimmering spectral ward envelopes you.`);
    log.push(`> Incoming enemy damage will be slashed by 60% for the next turn.`);
  }
  else if (action === 'STRADDLE_SHOCK') {
    manaCost = 25;
    // Explodes based on volatility and gamma
    const volFactor = Math.round(Math.abs(player.netVega) * 4 + 35);
    playerDmg = volFactor + Math.floor(Math.random() * 20);
    ivDelta = 0.05; // Spikes market IV
    log.push(`> You summon a [Long Straddle Chaos Vortex]! Volatility erupts!`);
    log.push(`> Dealt ${playerDmg} arcane shock damage to ${enemy.name}! (+5% realm IV)`);
  }
  else if (action === 'THETA_SIPHON') {
    manaCost = 10;
    if (player.netTheta > 0) {
      playerHealed = Math.min(45, Math.round(player.netTheta * 1.8 + 15));
      playerDmg = Math.round(player.netTheta * 1.2);
      log.push(`> You channel [Theta Siphon]! Positive time decay turns into restorative vitality.`);
      log.push(`> Healed +${playerHealed} HP and drained ${playerDmg} life force from ${enemy.name}!`);
    } else {
      playerHealed = 12;
      playerDmg = 10;
      log.push(`> You attempt [Theta Siphon], but your portfolio carries negative theta bleed.`);
      log.push(`> Harvested a meager +12 HP.`);
    }
  }
  else if (action === 'USE_ELIXIR') {
    playerHealed = 60;
    log.push(`> You quaff a Health Elixir! Restored +60 HP.`);
  }
  else if (action === 'USE_HOURGLASS') {
    playerHealed = 25;
    manaCost = -30; // restores mana
    log.push(`> You turn the Time Hourglass! Temporal flow recalibrates (+25 HP, +30 Mana).`);
  }

  // Check if enemy is defeated by player's strike
  const enemyRemainingHp = Math.max(0, enemy.currentHp - playerDmg);
  if (enemyRemainingHp <= 0) {
    log.push(`> *** CRITICAL TRIUMPH! ${enemy.name} collapses into a storm of golden guild florins! ***`);
    return {
      playerDamageDealt: playerDmg,
      enemyDamageDealt: 0,
      playerHealed,
      manaSpent: manaCost,
      logMessages: log,
      enemyDefeated: true,
      playerDefeated: false,
      marketShift: { spotChange: spotDelta, ivChange: ivDelta }
    };
  }

  // 2. Enemy Counter-Attack
  // Enemy scales violently if riskScore is high
  const isEnraged = riskScore >= 65;
  const isSpecial = Math.random() < 0.35;

  let rawEnemyDmg = enemy.attackPower + Math.floor(Math.random() * 8) - 3;
  if (isEnraged) {
    rawEnemyDmg = Math.round(rawEnemyDmg * 1.5);
    log.push(`> [ALERT] Enemy senses your vulnerable portfolio leverage and ENRAGES!`);
  }

  if (isSpecial) {
    rawEnemyDmg = Math.round(rawEnemyDmg * 1.4);
    log.push(`> ${enemy.name} channels special move: "${enemy.specialMove}"!`);
    if (enemy.marketAffinity === 'CRASH') {
      spotDelta -= 3;
    } else if (enemy.marketAffinity === 'SURGE') {
      spotDelta += 4;
    } else if (enemy.marketAffinity === 'CHAOS') {
      ivDelta += 0.08;
    }
  } else {
    log.push(`> ${enemy.name} strikes with ${enemy.title}!`);
  }

  // Apply player shield / hedging mitigation
  if (shieldActive || action === 'HEDGE_SHIELD') {
    enemyDmg = Math.max(4, Math.round(rawEnemyDmg * 0.4));
    log.push(`> Your Protective Put Ward absorbs 60% of the blow! (Damage: ${enemyDmg})`);
  } else if (riskScore < 25) {
    // Delta-neutral bonus
    enemyDmg = Math.max(6, Math.round(rawEnemyDmg * 0.75));
    log.push(`> Delta-neutral balance deflects 25% of the strike. (Damage: ${enemyDmg})`);
  } else {
    enemyDmg = rawEnemyDmg;
    log.push(`> You take ${enemyDmg} direct damage to your life total!`);
  }

  const playerRemainingHp = player.hp + playerHealed - enemyDmg;
  const playerDefeated = playerRemainingHp <= 0;
  if (playerDefeated) {
    log.push(`> *** MARGIN LIQUIDATION! Your life force has been depleted! ***`);
  }

  return {
    playerDamageDealt: playerDmg,
    enemyDamageDealt: enemyDmg,
    playerHealed,
    manaSpent: manaCost,
    logMessages: log,
    enemyDefeated: false,
    playerDefeated,
    marketShift: { spotChange: spotDelta, ivChange: ivDelta }
  };
}
