import { QuestNode, EnemyStats } from '../types';

export interface MapData {
  act: number;
  name: string;
  theme: string;
  underlyingSymbol: string;
  baseSpot: number;
  baseIv: number;
  grid: string[];
  legend: { [key: string]: { name: string; type: string; desc: string } };
}

export const REALM_MAPS: MapData[] = [
  {
    act: 1,
    name: 'The Whispering Grove of Strikes',
    theme: 'Forest of directional winds and nascent trends',
    underlyingSymbol: '$AETH',
    baseSpot: 100,
    baseIv: 0.28,
    grid: [
      '############',
      '#.@..S...E.#',
      '#.####.###.#',
      '#...M..#...#',
      '###.####.###',
      '#...C..#...#',
      '#.####.###.#',
      '#....E...B.#',
      '############'
    ],
    legend: {
      '@': { name: 'Oracle Hero', type: 'PLAYER', desc: 'Your current location' },
      'S': { name: 'Shrine of the Pythia', type: 'SHRINE', desc: 'Ancient oracle teaching the rites of Calls and Puts' },
      'M': { name: 'Terminal Exchange', type: 'EXCHANGE', desc: 'The realm\'s market trading portal' },
      'E': { name: 'Encounter', type: 'EVENT', desc: 'Mythical traveler or market anomaly' },
      'C': { name: 'Cache of Florins', type: 'CHEST', desc: 'Hidden chest of ancient guild currency' },
      'B': { name: 'Grizzly Bear Phantom', type: 'BOSS', desc: 'Guardian of the Whispering Grove' }
    }
  },
  {
    act: 2,
    name: 'The Theta Steppes of Decay',
    theme: 'Arid desert where the river of time burns extrinsic value',
    underlyingSymbol: '$AETH',
    baseSpot: 112,
    baseIv: 0.35,
    grid: [
      '############',
      '#.@..#..S..#',
      '#.##.##.##.#',
      '#..E.M...C.#',
      '#.########.#',
      '#...#....#.#',
      '###.#.##.#.#',
      '#.E...#..B.#',
      '############'
    ],
    legend: {
      '@': { name: 'Oracle Hero', type: 'PLAYER', desc: 'Your current location' },
      'S': { name: 'Chrono-Obelisk', type: 'SHRINE', desc: 'Altar explaining Theta decay and Calendar Spreads' },
      'M': { name: 'Oasis Exchange', type: 'EXCHANGE', desc: 'Derivatives trading post' },
      'E': { name: 'Wandering Chronomancer', type: 'EVENT', desc: 'Offers temporal prophecies and spreads' },
      'C': { name: 'Hourglass Relic', type: 'CHEST', desc: 'Ancient relic granting time manipulation' },
      'B': { name: 'The Chrono-Sphinx', type: 'BOSS', desc: 'Ancient riddlemaster who punishes unhedged theta decay' }
    }
  },
  {
    act: 3,
    name: 'The Iron Sanctuary of Neutrality',
    theme: 'Fortress canyon locked in an immovable rangebound channel',
    underlyingSymbol: '$AETH',
    baseSpot: 120,
    baseIv: 0.42,
    grid: [
      '############',
      '#.@.M..#...#',
      '###.##.#.S.#',
      '#...#..#.###',
      '#.E.#.C#...#',
      '#.###.####.#',
      '#...#..M.#.#',
      '#.E...#..B.#',
      '############'
    ],
    legend: {
      '@': { name: 'Oracle Hero', type: 'PLAYER', desc: 'Your current location' },
      'S': { name: 'Bastion Altar', type: 'SHRINE', desc: 'Secret scrolls of the Iron Condor strategy' },
      'M': { name: 'Sanctuary Vault', type: 'EXCHANGE', desc: 'High-leverage options trading desk' },
      'E': { name: 'Arbitrage Merchant', type: 'EVENT', desc: 'Offers market-neutral spread opportunities' },
      'C': { name: 'Gold Bullion', type: 'CHEST', desc: 'Valuable guild florins for liquidity reserve' },
      'B': { name: 'Crab Golem of Sideways Range', type: 'BOSS', desc: 'Enormous stone crab that destroys directional bets' }
    }
  },
  {
    act: 4,
    name: 'The Volatility Caldera',
    theme: 'Lava crags radiating violent implied volatility eruptions',
    underlyingSymbol: '$AETH',
    baseSpot: 135,
    baseIv: 0.65,
    grid: [
      '############',
      '#.@...#..S.#',
      '#.###.#.##.#',
      '#..M#..C.#.#',
      '##.#######.#',
      '#..E#....#.#',
      '#.###.##.#.#',
      '#...E.#..B.#',
      '############'
    ],
    legend: {
      '@': { name: 'Oracle Hero', type: 'PLAYER', desc: 'Your current location' },
      'S': { name: 'Volcanic Rune Shrine', type: 'SHRINE', desc: 'The secrets of Vega and IV Crush' },
      'M': { name: 'Magma Exchange', type: 'EXCHANGE', desc: 'Options terminal amid extreme volatility' },
      'E': { name: 'Seismic Prophet', type: 'EVENT', desc: 'Forewarns of great explosions and earnings events' },
      'C': { name: 'Fire Pearl of Delta', type: 'CHEST', desc: 'Empowers directional strikes' },
      'B': { name: 'Hydra of Implied Vega', type: 'BOSS', desc: 'Multi-headed dragon thriving in violent market shocks' }
    }
  },
  {
    act: 5,
    name: 'The Citadel of Citadel Prime',
    theme: 'Tower of High Finance where the Liquidation Reaper reigns',
    underlyingSymbol: '$AETH',
    baseSpot: 150,
    baseIv: 0.50,
    grid: [
      '############',
      '#.@.M..#..S#',
      '#.####.###.#',
      '#..C#....#.#',
      '###.#.##.###',
      '#...#.#..#.#',
      '#.###.##.#.#',
      '#..E.....B.#',
      '############'
    ],
    legend: {
      '@': { name: 'Oracle Hero', type: 'PLAYER', desc: 'Your current location' },
      'S': { name: 'Apex Sanctuary', type: 'SHRINE', desc: 'Mastery of capital preservation and the Kelly Criterion' },
      'M': { name: 'Grand Sovereign Exchange', type: 'EXCHANGE', desc: 'The supreme market desk of Aethelgard' },
      'E': { name: 'Spectral Inquisitor', type: 'EVENT', desc: 'Audits your portfolio margin cushion' },
      'C': { name: 'Emperor\'s Treasury', type: 'CHEST', desc: 'Vast capital reserves' },
      'B': { name: 'The Liquidation Lord', type: 'BOSS', desc: 'Ultimate manifestation of unhedged greed and margin ruin' }
    }
  }
];

export const BOSS_ENEMIES: { [key: number]: EnemyStats } = {
  1: {
    id: 'boss_bear_phantom',
    name: 'Grizzly Bear Phantom',
    title: 'Harbinger of the 20% Drawdown',
    type: 'BEAR',
    baseHp: 160,
    maxHp: 160,
    currentHp: 160,
    attackPower: 18,
    defense: 4,
    riskSensitivity: 1.4,
    marketAffinity: 'CRASH',
    specialMove: 'Cascading Flash Crash (drives spot down by $8!)',
    lore: 'A ghostly ursine beast summoned from the ruins of historical market crashes. It relentlessly preys on greedy long call holders who neglect protective puts.',
    dialogue: [
      '"You hold no Put protection, mortal? Prepare to watch your unhedged calls dissolve into dust!"',
      '"Every green candle is merely an illusion before my winter descends!"',
      '"Feel the icy chill of a gap-down open!"'
    ]
  },
  2: {
    id: 'boss_chrono_sphinx',
    name: 'The Chrono-Sphinx',
    title: 'Devourer of Extrinsic Value',
    type: 'CRAB',
    baseHp: 240,
    maxHp: 240,
    currentHp: 240,
    attackPower: 22,
    defense: 8,
    riskSensitivity: 1.6,
    marketAffinity: 'STAGNATION',
    specialMove: 'Temporal Acceleration (forces 5 Days to Expiration to vanish instantly!)',
    lore: 'An immortal Sphinx whose gaze ages derivatives in seconds. Long option buyers with out-of-the-money lotto tickets perish before even rolling their strikes.',
    dialogue: [
      '"Tick... tock... the sand drains through my paws. What has your out-of-the-money call earned you today?"',
      '"Stagnation is my blade! The river of Theta flows only in my favor!"',
      '"Only those who sell premium or define their spreads may pass my sands unscathed."'
    ]
  },
  3: {
    id: 'boss_crab_golem',
    name: 'Crab Golem of Sideways Range',
    title: 'Titan of the Consolidation Channel',
    type: 'CRAB',
    baseHp: 320,
    maxHp: 320,
    currentHp: 320,
    attackPower: 26,
    defense: 12,
    riskSensitivity: 1.8,
    marketAffinity: 'STAGNATION',
    specialMove: 'Iron Clamp (locks spot price strictly at $120 for 3 turns, suffocating directional bets)',
    lore: 'Forged from granite and Bollinger Band barriers. Directional bulls and bears break their swords upon its carapace, while Iron Condor practitioners siphon its life force.',
    dialogue: [
      '"You bet on a breakout? Ha! I shall sit precisely on the 50-day moving average forever!"',
      '"Your calls decay. Your puts decay. Only the Iron Condor masters can harm my shell!"',
      '"Neither heaven nor hell shall claim the market today—only flatline stillness!"'
    ]
  },
  4: {
    id: 'boss_hydra_vega',
    name: 'Hydra of Implied Vega',
    title: 'The Cataclysmic Earnings Beast',
    type: 'HYDRA',
    baseHp: 420,
    maxHp: 420,
    currentHp: 420,
    attackPower: 34,
    defense: 10,
    riskSensitivity: 2.2,
    marketAffinity: 'CHAOS',
    specialMove: 'Post-Earnings Volatility Crush (slashes realm IV from 80% to 25% in a single roar!)',
    lore: 'A monstrous dragon with heads of Uncertainty, Speculation, and Greed. It inflates option prices before releasing an earnings exhale that vaporizes extrinsic premium.',
    dialogue: [
      '"Buy my overpriced 90% IV options, fool! When I exhale tomorrow morning, your premium will be ash!"',
      '"My volatility shifts like thunder! A 5% move will not save your bloated contract!"',
      '"Have you hedged your Vega, or will my shockwave consume your soul?"'
    ]
  },
  5: {
    id: 'boss_liquidation_lord',
    name: 'The Liquidation Lord',
    title: 'Sovereign of the Spectral Margin Call',
    type: 'REAPER',
    baseHp: 650,
    maxHp: 650,
    currentHp: 650,
    attackPower: 48,
    defense: 15,
    riskSensitivity: 2.8,
    marketAffinity: 'CRASH',
    specialMove: 'Forced Portfolio Liquidation (inflicts damage equal to 40% of player\'s margin utilization!)',
    lore: 'The supreme arbiter of capital destruction. Those who trade with excessive leverage, borrow reckless margin, and abandon risk discipline face his scythe of total liquidation.',
    dialogue: [
      '"MARGIN CALL! Your collateral is forfeit! Your accounts are seized!"',
      '"You dared to enter my sanctum with 80% margin utilization? Your greed is your executioner!"',
      '"Only a trader with iron cash reserves, defined risk spreads, and delta neutrality can hope to survive my reckoning!"'
    ]
  }
};

export const STORY_QUESTS: { [key: string]: QuestNode } = {
  'act1_intro': {
    id: 'act1_intro',
    title: 'The Prophecy of Aethelgard',
    locationName: 'The Gates of the Whispering Grove',
    description: 'You stand at the boundary of the Mythical Realm of Aethelgard. In your satchel lies 10,000 Guild Florins—your seed capital. The realm\'s lifeblood flows through the mystical rune asset $AETH (trading at 100 Florins). The High Oracle warns of turbulent market forces brewing ahead.',
    optionsLesson: 'Lesson 1: The Foundations of Calls & Puts. Before journeying into danger, an investor must decide whether to seek directional growth (Calls) or armor against collapse (Puts), all while minding the price of extrinsic premium.',
    choices: [
      {
        text: 'Consult the Pythia of Delta regarding directional strikes (+100 Florins blessing)',
        outcomeText: 'The Pythia bestows her wisdom: "A Call option gives you the right to buy $AETH at a fixed strike without risking more than the premium paid. Respect the strike price!"',
        action: (state) => {
          state.florins += 100;
          state.relics.push('Pythia\'s Compass');
        }
      },
      {
        text: 'Purchase 2 Long Calls (Strike 100, 30 DTE) to ride bullish winds',
        costFlorins: 800,
        outcomeText: 'You cast 2 Long Call contracts on $AETH. If the underlying surges past 104 Florins, your profits will compound exponentially!',
        action: (state) => {
          state.florins -= 800;
        },
        marketImpact: { spotChangePercent: 0.02 }
      },
      {
        text: 'Keep 100% liquid cash and advance cautiously through the trees',
        outcomeText: 'You preserve full capital discipline. No margin is utilized, and your portfolio is 100% liquid Florins.',
        action: (state) => {
          state.mana = Math.min(state.maxMana, state.mana + 10);
        }
      }
    ]
  },
  'act1_event': {
    id: 'act1_event',
    title: 'The Wandering Blacksmith\'s Dilemma',
    locationName: 'The Mossy Crossroads',
    description: 'A dwarven blacksmith offers to forge a magical weapon, but whispers of an impending supply shortage in iron runes. "If the price of $AETH leaps upward, raw materials will cost double! How should I hedge my forge?"',
    optionsLesson: 'Hedging with Derivatives. When exposed to commodity price spikes, businesses buy Calls to lock in a maximum purchase price, transforming unbounded risk into a predictable cost.',
    choices: [
      {
        text: 'Advise him to buy Call Options to lock in his maximum iron purchase price',
        outcomeText: 'The dwarven smith beams in gratitude! "Genius! My downside is capped at the premium paid, and my maximum iron cost is locked!" He gifts you 300 Florins and an Elixir.',
        action: (state) => {
          state.florins += 300;
          state.potions.healthElixir += 1;
        }
      },
      {
        text: 'Advise him to take high-interest margin loans to hoard physical iron',
        outcomeText: 'The blacksmith looks horrified: "Overleveraged physical debt? If iron prices drop, storage fees and interest will bankrupt my clan!" He shakes his head and walks away.',
        action: (state) => {
          state.hp -= 10;
        }
      }
    ]
  },
  'act2_event': {
    id: 'act2_event',
    title: 'The Chronomancer\'s Riddle of Time',
    locationName: 'The Dune of Vanishing Days',
    description: 'An ethereal sorcerer levitates above the sands. "Look upon this contract! With 60 days remaining, it was worth 10 Florins. Now, with 5 days remaining, the underlying has barely moved, yet the contract is worth a mere 1 Florin! Where did the gold vanish?"',
    optionsLesson: 'Theta decay is non-linear. In the final 30 to 7 days, extrinsic time value evaporates at hyper-speed. Buying short-dated OTM options is mathematically rigged in favor of the option seller.',
    choices: [
      {
        text: 'Answer: "Theta decay consumed the extrinsic value as time ran out!"',
        outcomeText: '"Correct, wise traveler!" The Chronomancer smiles. "Time is an enemy to the reckless buyer, but a faithful servant to the spread trader!" He bestows a Time Hourglass.',
        action: (state) => {
          state.potions.timeHourglass += 1;
          state.mana = Math.min(state.maxMana, state.mana + 20);
        }
      },
      {
        text: 'Answer: "The market maker stole the gold in the dark!"',
        outcomeText: 'The Chronomancer sighs: "Blaming invisible cabals for fundamental math? Extrinsic value has always been a decaying asset." A sandstorm buffets you for 15 damage.',
        action: (state) => {
          state.hp -= 15;
        }
      }
    ]
  },
  'act3_event': {
    id: 'act3_event',
    title: 'The Council of the Stagnant Valley',
    locationName: 'The Iron Gates of Consolidation',
    description: 'The merchants here are despairing. $AETH has remained trapped between 118 and 124 Florins for weeks. Directional traders are losing money to commission and theta. "Is there no spell to profit when nothing moves?" they cry.',
    optionsLesson: 'Non-Directional Income: The Iron Condor. By selling an OTM Call spread and an OTM Put spread simultaneously, you profit from sideways consolidation and time decay.',
    choices: [
      {
        text: 'Teach them the ritual of the Iron Condor (Sell 126 Call / Buy 130 Call & Sell 116 Put / Buy 112 Put)',
        outcomeText: 'The merchants rejoice! "A bounded cage of four strikes! We collect upfront credit and win as long as the market sleeps in range!" They reward you with 500 Florins.',
        action: (state) => {
          state.florins += 500;
          state.relics.push('Condor Crest');
        }
      },
      {
        text: 'Advise them to buy high-leverage 0-DTE Out-of-the-Money Calls hoping for a miracle',
        outcomeText: 'The merchants follow the bad advice and lose their savings within hours. Their resentment manifests as a cursed miasma (-20 HP).',
        action: (state) => {
          state.hp -= 20;
        }
      }
    ]
  },
  'act4_event': {
    id: 'act4_event',
    title: 'The Eve of the Dragon\'s Earnings Report',
    locationName: 'The Rim of the Smoldering Caldera',
    description: 'Tomorrow morning, the High Guild will release the Quarterly Realm Earnings! Implied Volatility has skyrocketed to 85%. Novice sorcerers are rushing to buy 150-strike Calls at exorbitant prices.',
    optionsLesson: 'Implied Volatility Crush. Buying options when IV is at historic highs is hazardous. Once the earnings report is announced, IV plummets back to normal, crushing option prices regardless of direction.',
    choices: [
      {
        text: 'Warn the sorcerers about IV Crush and recommend selling credit spreads or staying hedged',
        outcomeText: 'The wise heed your warning. When the report lands, the stock rises 2%, but naked calls drop 40% due to IV collapse! Grateful acolytes gift you an IV Stabilizer potion.',
        action: (state) => {
          state.potions.ivStabilizer += 1;
          state.florins += 250;
        }
      },
      {
        text: 'FOMO with the crowd and buy overpriced naked Calls into 85% IV',
        outcomeText: 'You buy the inflated contracts. The next day, the news is good, but IV crashes to 35%—your contracts lose half their value instantly! (-400 Florins)',
        action: (state) => {
          state.florins = Math.max(100, state.florins - 400);
        },
        marketImpact: { ivChangePercent: -0.40 }
      }
    ]
  }
};
