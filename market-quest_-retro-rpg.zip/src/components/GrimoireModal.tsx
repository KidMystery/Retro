import React, { useState } from 'react';
import { OPTIONS_LESSONS, LessonEntry } from '../lib/lessonsData';
import { sound } from '../lib/audioEngine';
import { BookOpen, CheckCircle, X, Award, HelpCircle } from 'lucide-react';

interface GrimoireModalProps {
  onAwardFlorins: (amount: number) => void;
  onClose: () => void;
}

export const GrimoireModal: React.FC<GrimoireModalProps> = ({
  onAwardFlorins,
  onClose
}) => {
  const [selectedLessonId, setSelectedLessonId] = useState<string>(OPTIONS_LESSONS[0].id);
  const [quizAnswers, setQuizAnswers] = useState<{ [lessonId: string]: number }>({});
  const [solvedQuizzes, setSolvedQuizzes] = useState<{ [lessonId: string]: boolean }>({});

  const activeLesson = OPTIONS_LESSONS.find(l => l.id === selectedLessonId) || OPTIONS_LESSONS[0];

  const handleSelectAnswer = (optionIdx: number) => {
    sound.playKeyClick();
    setQuizAnswers(prev => ({ ...prev, [activeLesson.id]: optionIdx }));

    if (optionIdx === activeLesson.quizQuestion.correctIndex && !solvedQuizzes[activeLesson.id]) {
      sound.playFanfare();
      setSolvedQuizzes(prev => ({ ...prev, [activeLesson.id]: true }));
      onAwardFlorins(150); // Reward for learning
    } else if (optionIdx !== activeLesson.quizQuestion.correctIndex) {
      sound.playAlarmSound();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 overflow-y-auto font-mono text-xs sm:text-sm">
      <div className="dos-box p-4 bg-[#070b07] text-current w-full max-w-4xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-current pb-2 mb-3">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-cyan-400" />
            <h2 className="font-bold text-base uppercase tracking-wider">
              THE GRIMOIRE OF DERIVATIVES // SACRED OPTIONS HANDBOOK
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 border border-current hover:bg-current hover:text-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Two-Column Layout: Index on Left, Content on Right */}
        <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-3 overflow-y-auto pr-1">
          {/* Left Table of Contents */}
          <div className="md:col-span-4 border border-current p-2 bg-black/60 space-y-1.5 overflow-y-auto max-h-[70vh]">
            <div className="font-bold border-b border-current/60 pb-1 mb-2 text-xs opacity-75">
              RUNIC CODEX OF LESSONS
            </div>
            {OPTIONS_LESSONS.map((lesson, idx) => {
              const isSelected = lesson.id === activeLesson.id;
              const isSolved = solvedQuizzes[lesson.id];
              return (
                <button
                  key={lesson.id}
                  onClick={() => {
                    sound.playKeyClick();
                    setSelectedLessonId(lesson.id);
                  }}
                  className={`w-full text-left p-2 border cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-current text-black font-bold border-current'
                      : 'border-current/30 hover:bg-current/15'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold truncate">
                      {idx + 1}. {lesson.concept}
                    </span>
                    {isSolved && <CheckCircle className="w-3.5 h-3.5 text-yellow-300 shrink-0 ml-1" />}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Right Lesson Detail */}
          <div className="md:col-span-8 border border-current p-3 sm:p-4 bg-black/70 space-y-3 overflow-y-auto max-h-[70vh]">
            <div>
              <h3 className="font-bold text-base text-yellow-300 mb-0.5">
                {activeLesson.runeTitle}
              </h3>
              <p className="text-xs italic text-cyan-300 border-l-2 border-cyan-400 pl-2 my-2">
                {activeLesson.quote}
              </p>
            </div>

            {/* Core Explanation */}
            <div>
              <div className="font-bold opacity-80 text-xs mb-1 uppercase tracking-wide">
                [EXPLANATION OF THE PHENOMENON]
              </div>
              <p className="leading-relaxed opacity-90 text-xs sm:text-sm">
                {activeLesson.explanation}
              </p>
            </div>

            {/* Practical Rule & RPG mechanic */}
            <div className="p-2 border border-dashed border-current bg-black/40 space-y-1 text-xs">
              <div>
                <strong className="text-green-400">PRACTICAL DISCIPLINE RULE:</strong>{' '}
                <span>{activeLesson.practicalRule}</span>
              </div>
              <div>
                <strong className="text-purple-300">REALM & COMBAT MECHANIC:</strong>{' '}
                <span>{activeLesson.gameApplication}</span>
              </div>
            </div>

            {/* Interactive Mastery Quiz */}
            <div className="p-3 border border-current bg-black/90 space-y-2 mt-4">
              <div className="flex items-center justify-between border-b border-current/40 pb-1">
                <span className="font-bold flex items-center gap-1 text-yellow-300">
                  <HelpCircle className="w-3.5 h-3.5" /> MASTER'S TRIAL QUESTION
                </span>
                {solvedQuizzes[activeLesson.id] ? (
                  <span className="text-yellow-300 font-bold flex items-center gap-1 text-xs">
                    <Award className="w-3.5 h-3.5" /> TRIAL MASTERED (+150 ƒ EARNED)
                  </span>
                ) : (
                  <span className="opacity-70 text-[11px]">Reward: 150 Florins</span>
                )}
              </div>

              <p className="font-bold text-xs">{activeLesson.quizQuestion.prompt}</p>

              <div className="space-y-1.5">
                {activeLesson.quizQuestion.options.map((opt, oIdx) => {
                  const isChosen = quizAnswers[activeLesson.id] === oIdx;
                  const isCorrect = oIdx === activeLesson.quizQuestion.correctIndex;
                  let btnStyle = 'border-current/50 hover:bg-current/15';

                  if (isChosen) {
                    btnStyle = isCorrect
                      ? 'border-green-400 bg-green-950/80 text-green-300 font-bold'
                      : 'border-red-500 bg-red-950/80 text-red-300 font-bold';
                  }

                  return (
                    <button
                      key={oIdx}
                      onClick={() => handleSelectAnswer(oIdx)}
                      className={`w-full text-left p-2 border cursor-pointer text-xs ${btnStyle}`}
                    >
                      <span className="mr-1.5 font-mono opacity-70">[{String.fromCharCode(65 + oIdx)}]</span>
                      {opt}
                    </button>
                  );
                })}
              </div>

              {quizAnswers[activeLesson.id] !== undefined && (
                <div
                  className={`p-2 border text-xs leading-relaxed ${
                    quizAnswers[activeLesson.id] === activeLesson.quizQuestion.correctIndex
                      ? 'border-green-400 text-green-300 bg-green-950/30'
                      : 'border-red-500 text-red-300 bg-red-950/30'
                  }`}
                >
                  <strong>
                    {quizAnswers[activeLesson.id] === activeLesson.quizQuestion.correctIndex
                      ? 'CORRECT! '
                      : 'INCORRECT. '}
                  </strong>
                  {activeLesson.quizQuestion.explanation}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-current pt-3 mt-3 flex justify-between items-center text-xs">
          <span className="opacity-75">
            Answer quiz trials correctly to earn guild florins for your seed capital!
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 border border-current hover:bg-current hover:text-black cursor-pointer font-bold"
          >
            CLOSE GRIMOIRE
          </button>
        </div>
      </div>
    </div>
  );
};
