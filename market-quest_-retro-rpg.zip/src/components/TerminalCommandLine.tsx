import React, { useState, useRef, useEffect } from 'react';
import { sound } from '../lib/audioEngine';
import { DOSTheme, GameView } from '../types';

interface TerminalCommandLineProps {
  onCommand: (command: string) => void;
  outputLog: string[];
}

export const TerminalCommandLine: React.FC<TerminalCommandLineProps> = ({
  onCommand,
  outputLog
}) => {
  const [input, setInput] = useState('');
  const logEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [outputLog]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    sound.playKeyClick();
    onCommand(input.trim());
    setInput('');
  };

  return (
    <div className="dos-box p-2 sm:p-3 bg-black/95 font-mono text-xs flex flex-col gap-2">
      {/* Scrollable Command Line History */}
      <div className="max-h-24 overflow-y-auto space-y-1 p-1">
        {outputLog.map((line, idx) => (
          <div key={idx} className="leading-snug opacity-90 whitespace-pre-wrap">
            {line}
          </div>
        ))}
        <div ref={logEndRef} />
      </div>

      {/* Input Prompt */}
      <form onSubmit={handleSubmit} className="flex items-center gap-1.5 border-t border-current/40 pt-1.5">
        <span className="font-bold text-yellow-300">C:\AETHELGARD&gt;</span>
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Type DOS command (e.g. HELP, TRADE, MAP, PORTFOLIO, REST, DIR)..."
          className="flex-1 bg-transparent border-none outline-none text-current font-mono text-xs focus:ring-0 placeholder:opacity-30"
          autoComplete="off"
          spellCheck="false"
        />
        <span className="animate-dos-blink font-bold text-current">█</span>
      </form>
    </div>
  );
};
