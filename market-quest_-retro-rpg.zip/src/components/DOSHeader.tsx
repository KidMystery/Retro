import React, { useState } from 'react';
import { DOSTheme, PlayerStats, GameView, TunicColor } from '../types';
import { sound, MYTHICAL_TRACKS, MythicalTrack } from '../lib/audioEngine';
import { 
  Volume2, 
  VolumeX, 
  Music, 
  BookOpen, 
  BarChart3, 
  ShieldAlert, 
  Compass, 
  Save, 
  User, 
  Sparkles, 
  Heart, 
  ChevronDown,
  Sun
} from 'lucide-react';

interface DOSHeaderProps {
  theme: DOSTheme;
  setTheme: (theme: DOSTheme) => void;
  player: PlayerStats;
  currentView: GameView;
  setView: (view: GameView) => void;
  isMuted: boolean;
  setIsMuted: (muted: boolean) => void;
  isBgmOn: boolean;
  toggleBgm: () => void;
  onAdvanceDay: () => void;
  onOpenSaveModal?: () => void;
  onOpenCustomizeModal?: () => void;
}

const TUNIC_PREVIEWS: Record<TunicColor, string> = {
  green: '#2e7d32',
  blue: '#1d4ed8',
  red: '#b91c1c',
  purple: '#7e22ce',
  black: '#334155'
};

export const DOSHeader: React.FC<DOSHeaderProps> = ({
  theme,
  setTheme,
  player,
  currentView,
  setView,
  isMuted,
  setIsMuted,
  isBgmOn,
  toggleBgm,
  onAdvanceDay,
  onOpenSaveModal,
  onOpenCustomizeModal
}) => {
  const [activeTrack, setActiveTrack] = useState<MythicalTrack>('overworld');
  const [showMusicMenu, setShowMusicMenu] = useState(false);
  const [volume, setVolume] = useState(25);

  const handleNav = (targetView: GameView) => {
    sound.playKeyClick();
    setView(targetView);
  };

  const handleTrackChange = (track: MythicalTrack) => {
    setActiveTrack(track);
    setShowMusicMenu(false);
    sound.startMusic(track);
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    sound.setVolume(newVol / 100);
  };

  const tunicColorHex = TUNIC_PREVIEWS[player.avatar?.tunicColor || 'green'];

  return (
    <header className="zelda-panel p-3 mb-4 select-none text-xs md:text-sm font-mono tracking-wide rounded-sm shadow-xl">
      {/* Top Bar: Hero Profile, Audio Synth & Save Button */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-amber-500/30 pb-2 mb-3">
        {/* Left: Hero Portrait, Custom Name & Title */}
        <div className="flex items-center gap-3">
          <button
            onClick={onOpenCustomizeModal}
            className="flex items-center gap-2.5 p-1 px-2 bg-slate-950/80 hover:bg-slate-900 border border-amber-500/60 rounded-xs cursor-pointer group transition-colors shadow-xs"
            title="Click to rename hero and customize armor"
          >
            {/* 16-Bit Avatar Mini-Head */}
            <div className="w-7 h-7 rounded-xs border border-amber-400 relative overflow-hidden bg-slate-900 flex items-center justify-center flex-shrink-0">
              <div 
                className="w-5 h-5 rounded-xs" 
                style={{ backgroundColor: tunicColorHex }} 
              />
              <div className="absolute top-0.5 w-3 h-1.5 bg-amber-200/90 rounded-xs" />
            </div>

            <div className="text-left">
              <div className="flex items-center gap-1.5">
                <span className="font-pixel text-[11px] sm:text-xs text-amber-300 font-bold group-hover:text-amber-200">
                  {player.name}
                </span>
                <User className="w-3 h-3 text-amber-400 opacity-60 group-hover:opacity-100" />
              </div>
              <div className="text-[10px] text-amber-200/70 truncate max-w-[140px] sm:max-w-[180px]">
                {player.avatar?.avatarTitle || player.title}
              </div>
            </div>
          </button>

          {/* Save / Load Game Action Button */}
          {onOpenSaveModal && (
            <button
              onClick={onOpenSaveModal}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-b from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold text-xs uppercase cursor-pointer rounded-xs shadow-md active:scale-95 transition-all"
              title="Open Sacred Chronicles to Save or Load Quest"
            >
              <Save className="w-3.5 h-3.5" />
              <span className="font-bold">SAVE / LOAD</span>
            </button>
          )}
        </div>

        {/* Right: Epic Mythical Music & Audio Controls */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          {/* Sound Effects Toggle */}
          <button
            onClick={() => {
              const nextMuted = !isMuted;
              setIsMuted(nextMuted);
              sound.setMuted(nextMuted);
            }}
            className="flex items-center gap-1 cursor-pointer px-2 py-1 bg-slate-900 border border-amber-500/50 hover:bg-slate-800 text-amber-300 rounded-xs text-xs"
            title="Toggle Sound Effects"
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5 text-red-400" /> : <Volume2 className="w-3.5 h-3.5 text-amber-400" />}
            <span className="text-[11px] font-bold">{isMuted ? 'SFX:OFF' : 'SFX:ON'}</span>
          </button>

          {/* Epic Mythical BGM Toggle */}
          <div className="relative">
            <div className="flex items-center border border-amber-500/50 rounded-xs overflow-hidden bg-slate-900">
              <button
                onClick={toggleBgm}
                className={`flex items-center gap-1.5 px-2.5 py-1 cursor-pointer transition-colors text-xs font-bold ${
                  isBgmOn 
                    ? 'bg-amber-500 text-slate-950 font-extrabold' 
                    : 'text-amber-300 hover:bg-slate-800'
                }`}
                title="Toggle Epic 16-bit Mythical Music"
              >
                <Music className={`w-3.5 h-3.5 ${isBgmOn ? 'animate-pulse' : ''}`} />
                <span>{isBgmOn ? 'BGM: PLAYING' : 'BGM: OFF'}</span>
              </button>

              <button
                onClick={() => setShowMusicMenu(!showMusicMenu)}
                className="px-1.5 py-1 border-l border-amber-500/40 text-amber-300 hover:bg-slate-800 cursor-pointer"
                title="Select Mythical Theme Track"
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Music Track Selector Dropdown */}
            {showMusicMenu && (
              <div className="absolute right-0 top-full mt-1 w-64 bg-slate-950 border-2 border-amber-500 rounded-xs p-2 shadow-2xl z-50 text-xs">
                <div className="font-bold text-amber-400 border-b border-amber-500/30 pb-1 mb-1.5 flex items-center justify-between">
                  <span>MYTHICAL THEMES</span>
                  <span className="text-[10px] text-slate-400">16-BIT SNES</span>
                </div>

                <div className="space-y-1 mb-2">
                  {MYTHICAL_TRACKS.map(track => (
                    <button
                      key={track.id}
                      onClick={() => handleTrackChange(track.id)}
                      className={`w-full text-left p-1.5 rounded-xs transition-colors cursor-pointer flex flex-col ${
                        activeTrack === track.id
                          ? 'bg-amber-500/25 border border-amber-400 text-amber-200 font-bold'
                          : 'hover:bg-slate-900 text-slate-300 border border-transparent'
                      }`}
                    >
                      <span className="text-xs">{track.title}</span>
                      <span className="text-[10px] text-amber-200/60">{track.mood}</span>
                    </button>
                  ))}
                </div>

                {/* Master Volume Slider */}
                <div className="border-t border-amber-500/30 pt-2 flex items-center justify-between gap-2 text-[11px] text-slate-300">
                  <span>Volume:</span>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={volume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-28 accent-amber-500 cursor-pointer"
                  />
                  <span>{volume}%</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Navigation & Vital HUD */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Navigation Tabs */}
        <nav className="flex flex-wrap items-center gap-1.5 sm:gap-2">
          <button
            onClick={() => handleNav('MAP')}
            className={`px-3 py-1.5 border rounded-xs flex items-center gap-1.5 cursor-pointer font-bold transition-colors ${
              currentView === 'MAP' 
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold shadow-sm' 
                : 'bg-slate-900 border-amber-500/40 text-amber-200 hover:bg-slate-800'
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>REALM OVERWORLD</span>
          </button>

          <button
            onClick={() => handleNav('TRADE_DESK')}
            className={`px-3 py-1.5 border rounded-xs flex items-center gap-1.5 cursor-pointer font-bold transition-colors ${
              currentView === 'TRADE_DESK' 
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold shadow-sm' 
                : 'bg-slate-900 border-amber-500/40 text-amber-200 hover:bg-slate-800'
            }`}
          >
            <BarChart3 className="w-3.5 h-3.5" />
            <span>OPTIONS DESK</span>
          </button>

          <button
            onClick={() => handleNav('PORTFOLIO')}
            className={`px-3 py-1.5 border rounded-xs flex items-center gap-1.5 cursor-pointer font-bold transition-colors ${
              currentView === 'PORTFOLIO' 
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold shadow-sm' 
                : 'bg-slate-900 border-amber-500/40 text-amber-200 hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5" />
            <span>PORTFOLIO & GREEKS</span>
          </button>

          <button
            onClick={() => handleNav('GRIMOIRE')}
            className={`px-3 py-1.5 border rounded-xs flex items-center gap-1.5 cursor-pointer font-bold transition-colors ${
              currentView === 'GRIMOIRE' 
                ? 'bg-amber-500 text-slate-950 border-amber-400 font-extrabold shadow-sm' 
                : 'bg-slate-900 border-amber-500/40 text-amber-200 hover:bg-slate-800'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>GRAHAM'S CODEX</span>
          </button>

          <button
            onClick={() => {
              sound.playCommandBeep();
              onAdvanceDay();
            }}
            className="px-3 py-1.5 bg-gradient-to-r from-amber-600/30 to-amber-500/30 hover:from-amber-600/50 hover:to-amber-500/50 border border-amber-400 text-amber-300 font-bold rounded-xs cursor-pointer flex items-center gap-1 shadow-xs"
            title="Advance 1 Market Day (Triggers Daily Theta & Settlement)"
          >
            <Sun className="w-3.5 h-3.5 text-amber-400" />
            <span>REST & SETTLE (+1 DAY)</span>
          </button>
        </nav>

        {/* 16-Bit Link to the Past Vital Stats HUD */}
        <div className="flex flex-wrap items-center gap-3 bg-slate-950/80 p-1.5 px-3 border border-amber-500/40 rounded-xs shadow-inner">
          {/* Hearts Life Force */}
          <div className="flex items-center gap-1.5" title="Options Trading Life Force Hearts">
            <div className={`flex items-center gap-0.5 ${player.hearts <= 1 ? 'animate-heart-pulse' : ''}`}>
              {Array.from({ length: player.maxHearts || 4 }).map((_, idx) => {
                const rem = player.hearts - idx;
                const isFull = rem >= 1;
                const isHalf = rem >= 0.4 && rem < 1;
                return (
                  <div key={idx} className="relative inline-block">
                    <Heart
                      className={`w-4 h-4 ${
                        isFull 
                          ? 'fill-red-500 text-red-600 drop-shadow-[0_0_4px_rgba(239,68,68,0.7)]' 
                          : isHalf 
                          ? 'fill-red-400 text-red-500 opacity-90' 
                          : 'fill-slate-800 text-slate-700 opacity-40'
                      }`}
                    />
                  </div>
                );
              })}
            </div>
            <span className="font-pixel text-[10px] text-red-400 font-bold">
              {player.hearts.toFixed(1)}/{player.maxHearts}
            </span>
          </div>

          {/* Florins / Rupees Wallet */}
          <div className="flex items-center gap-1" title="Florins Gold / Rupee Wallet">
            {/* Green Rupee Icon */}
            <div className="w-3 h-4 bg-emerald-500 border border-emerald-300 rotate-45 transform scale-75 shadow-xs" />
            <span className="font-bold text-amber-300 text-xs ml-0.5">
              {player.florins.toLocaleString()} ƒ
            </span>
          </div>

          {/* Portfolio Net Worth */}
          <div className="hidden lg:flex items-center gap-1 text-slate-300 text-xs">
            <span className="text-amber-200/60">PORTFOLIO:</span>
            <span className="font-bold text-slate-200">{Math.round(player.portfolioValue).toLocaleString()} ƒ</span>
          </div>

          {/* Market Day Counter */}
          <div className="flex items-center gap-1 text-xs">
            <span className="text-amber-200/60">DAY:</span>
            <span className="font-pixel text-[10px] text-sky-400 font-bold">#{player.day}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
