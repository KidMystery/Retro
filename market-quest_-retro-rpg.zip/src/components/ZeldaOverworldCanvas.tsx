import React, { useRef, useEffect, useState, useCallback } from 'react';
import { ZeldaMap, ZeldaEntity, ZELDA_MAPS } from '../lib/zeldaWorldData';
import { PlayerStats, AssetQuote, TunicColor, HairColor } from '../types';
import { sound } from '../lib/audioEngine';
import { ArrowUp, ArrowDown, ArrowLeft, ArrowRight, Swords, Sparkles, MessageCircle, Save, User, Compass } from 'lucide-react';

interface ZeldaOverworldCanvasProps {
  act: number;
  player: PlayerStats;
  asset: AssetQuote;
  onMove: (x: number, y: number, facing: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => void;
  onInteractEntity: (entity: ZeldaEntity) => void;
  onSwordSlash: () => void;
  onOpenSaveModal?: () => void;
  onOpenCustomizeModal?: () => void;
}

const TUNIC_COLORS: Record<TunicColor, { main: string; shadow: string; highlight: string }> = {
  green: { main: '#2e7d32', shadow: '#1b5e20', highlight: '#4caf50' },
  blue: { main: '#1d4ed8', shadow: '#1e3a8a', highlight: '#60a5fa' },
  red: { main: '#b91c1c', shadow: '#7f1d1d', highlight: '#f87171' },
  purple: { main: '#7e22ce', shadow: '#581c87', highlight: '#c084fc' },
  black: { main: '#334155', shadow: '#0f172a', highlight: '#64748b' }
};

const HAIR_COLORS: Record<HairColor, string> = {
  blonde: '#facc15',
  brown: '#78350f',
  black: '#111827',
  white: '#f1f5f9'
};

export const ZeldaOverworldCanvas: React.FC<ZeldaOverworldCanvasProps> = ({
  act,
  player,
  asset,
  onMove,
  onInteractEntity,
  onSwordSlash,
  onOpenSaveModal,
  onOpenCustomizeModal
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mapData: ZeldaMap = ZELDA_MAPS[act] || ZELDA_MAPS[1];
  const [nearbyEntity, setNearbyEntity] = useState<ZeldaEntity | null>(null);
  const [isSlashing, setIsSlashing] = useState(false);
  const [walkFrame, setWalkFrame] = useState(0);
  const [animTick, setAnimTick] = useState(0);

  const TILE_SIZE = 38; // 38px per tile for crisp SNES scale
  const width = mapData.width * TILE_SIZE;
  const height = mapData.height * TILE_SIZE;

  // Continuous animation loop for water shimmer & sacred shrine particles
  useEffect(() => {
    let animId: number;
    const loop = () => {
      setAnimTick(t => (t + 1) % 1000);
      animId = requestAnimationFrame(loop);
    };
    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, []);

  // Collision check
  const isSolid = useCallback((x: number, y: number): boolean => {
    if (x < 0 || x >= mapData.width || y < 0 || y >= mapData.height) return true;
    const tile = mapData.tiles[y]?.[x];
    if (!tile) return true;
    // Solid tiles: Tree (T), Water (~ without bridge), Wall (#)
    if (tile === 'T' || tile === '#') return true;
    if (tile === '~') return true;
    return false;
  }, [mapData]);

  // Find nearby entity for interaction prompt
  useEffect(() => {
    const found = mapData.entities.find(e => {
      const dist = Math.abs(e.x - player.mapX) + Math.abs(e.y - player.mapY);
      return dist <= 1.2;
    });
    setNearbyEntity(found || null);
  }, [player.mapX, player.mapY, mapData.entities]);

  // Step movement
  const handleStep = useCallback((dx: number, dy: number, dir: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => {
    const targetX = player.mapX + dx;
    const targetY = player.mapY + dy;

    if (isSolid(targetX, targetY)) {
      sound.playAlarmSound();
      onMove(player.mapX, player.mapY, dir);
      return;
    }

    sound.playKeyClick();
    setWalkFrame(prev => (prev + 1) % 4);
    onMove(targetX, targetY, dir);
  }, [player.mapX, player.mapY, isSolid, onMove]);

  // Sword slash
  const triggerSlash = useCallback(() => {
    sound.playSwordSlash();
    setIsSlashing(true);
    onSwordSlash();
    setTimeout(() => setIsSlashing(false), 240);

    // If standing right next to boss or monster, slash triggers interaction
    if (nearbyEntity && (nearbyEntity.type === 'BOSS' || nearbyEntity.type === 'NPC_SCAMMER')) {
      onInteractEntity(nearbyEntity);
    }
  }, [nearbyEntity, onInteractEntity, onSwordSlash]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger if user is typing in an input
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes((e.target as HTMLElement)?.tagName)) {
        return;
      }

      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        handleStep(0, -1, 'UP');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        handleStep(0, 1, 'DOWN');
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        handleStep(-1, 0, 'LEFT');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        handleStep(1, 0, 'RIGHT');
      } else if (['Space', 'KeyE', 'Enter'].includes(e.code)) {
        e.preventDefault();
        if (nearbyEntity) {
          onInteractEntity(nearbyEntity);
        } else {
          triggerSlash();
        }
      } else if (e.code === 'KeyJ' || e.code === 'KeyZ') {
        e.preventDefault();
        triggerSlash();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleStep, nearbyEntity, onInteractEntity, triggerSlash]);

  // Render 16-Bit SNES "A Link to the Past" Overworld Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Rich Dark Void Background
    ctx.fillStyle = '#060a12';
    ctx.fillRect(0, 0, width, height);

    const waterOffset = Math.sin(animTick * 0.05) * 3;
    const fairySparkOffset = (animTick * 0.8) % 30;

    // --- DRAW MAP TILES ---
    for (let y = 0; y < mapData.height; y++) {
      for (let x = 0; x < mapData.width; x++) {
        const tile = mapData.tiles[y]?.[x] || '.';
        const px = x * TILE_SIZE;
        const py = y * TILE_SIZE;

        if (tile === '.') {
          // Lush ALttP Grass with texture
          ctx.fillStyle = (x + y) % 2 === 0 ? '#2d6a2f' : '#265928';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

          // Subtle grass blade tufts
          ctx.fillStyle = '#3c853f';
          ctx.fillRect(px + 6, py + 10, 2, 5);
          ctx.fillRect(px + 8, py + 12, 2, 3);
          ctx.fillRect(px + 24, py + 22, 2, 5);
          ctx.fillRect(px + 26, py + 24, 2, 3);

          // Dark shadow edge
          ctx.fillStyle = 'rgba(0,0,0,0.06)';
          ctx.fillRect(px, py + TILE_SIZE - 2, TILE_SIZE, 2);
        } else if (tile === 'F') {
          // Grass with colorful Hyrule Flora / Flowers
          ctx.fillStyle = '#2d6a2f';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

          // Flower stem & petals
          ctx.fillStyle = '#4ade80';
          ctx.fillRect(px + 17, py + 16, 4, 10);
          // Petals (alternating yellow and pink)
          const flowerColor = (x + y) % 2 === 0 ? '#fde047' : '#f43f5e';
          ctx.fillStyle = flowerColor;
          ctx.fillRect(px + 14, py + 12, 10, 10);
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(px + 17, py + 15, 4, 4);
        } else if (tile === 'P') {
          // Stone Cobblestone Path with flagstone borders
          ctx.fillStyle = '#3f4a3c';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = '#556350';
          ctx.fillRect(px + 3, py + 3, TILE_SIZE - 6, TILE_SIZE - 6);

          // Flagstone cracks and highlights
          ctx.fillStyle = '#6f8169';
          ctx.fillRect(px + 5, py + 5, 12, 10);
          ctx.fillRect(px + 20, py + 18, 12, 12);
          ctx.fillStyle = '#262d24';
          ctx.fillRect(px + 17, py + 5, 2, 26);
        } else if (tile === 'T') {
          // Lush ALttP Oak Tree
          // Grass base
          ctx.fillStyle = '#2d6a2f';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

          // Tree trunk & roots
          ctx.fillStyle = '#5c381c';
          ctx.fillRect(px + 14, py + 22, 10, 14);
          ctx.fillStyle = '#3d2311';
          ctx.fillRect(px + 14, py + 28, 3, 8);
          ctx.fillRect(px + 21, py + 28, 3, 8);

          // Dark underside canopy
          ctx.fillStyle = '#143818';
          ctx.beginPath();
          ctx.arc(px + 19, py + 18, 17, 0, Math.PI * 2);
          ctx.fill();

          // Main canopy
          ctx.fillStyle = '#1e5424';
          ctx.beginPath();
          ctx.arc(px + 19, py + 16, 15, 0, Math.PI * 2);
          ctx.fill();

          // Highlight canopy layer (ALttP leaf puffs)
          ctx.fillStyle = '#2d7a36';
          ctx.beginPath();
          ctx.arc(px + 14, py + 13, 8, 0, Math.PI * 2);
          ctx.arc(px + 23, py + 13, 8, 0, Math.PI * 2);
          ctx.arc(px + 19, py + 9, 8, 0, Math.PI * 2);
          ctx.fill();

          ctx.fillStyle = '#4ade80';
          ctx.fillRect(px + 17, py + 7, 3, 3);
        } else if (tile === '~') {
          // Sparkling Translucent River Water with crests
          ctx.fillStyle = '#0284c7';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = '#0369a1';
          ctx.fillRect(px, py + 14, TILE_SIZE, TILE_SIZE - 14);

          // Dynamic wave ripples
          ctx.fillStyle = '#bae6fd';
          const waveY = (py + 8 + waterOffset) % TILE_SIZE;
          ctx.fillRect(px + 4, waveY + py, 14, 2);
          ctx.fillRect(px + 22, ((waveY + 12) % TILE_SIZE) + py, 12, 2);
        } else if (tile === '=') {
          // Wooden Bridge over water
          ctx.fillStyle = '#0369a1';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);

          // Wood planks
          ctx.fillStyle = '#854d0e';
          ctx.fillRect(px, py + 4, TILE_SIZE, TILE_SIZE - 8);

          // Plank separation
          ctx.fillStyle = '#451a03';
          ctx.fillRect(px + 8, py + 4, 2, TILE_SIZE - 8);
          ctx.fillRect(px + 18, py + 4, 2, TILE_SIZE - 8);
          ctx.fillRect(px + 28, py + 4, 2, TILE_SIZE - 8);

          // Side rope railings
          ctx.fillStyle = '#ca8a04';
          ctx.fillRect(px, py + 2, TILE_SIZE, 3);
          ctx.fillRect(px, py + TILE_SIZE - 5, TILE_SIZE, 3);
        } else if (tile === '#') {
          // Stone Dungeon Wall
          ctx.fillStyle = '#1e293b';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = '#334155';
          ctx.fillRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 2;
          ctx.strokeRect(px + 2, py + 2, TILE_SIZE - 4, TILE_SIZE - 4);

          // Mossy stone highlights
          ctx.fillStyle = '#475569';
          ctx.fillRect(px + 6, py + 6, 12, 10);
        } else if (tile === 'D') {
          // Mysterious Archway / Cave Entrance
          ctx.fillStyle = '#2d6a2f';
          ctx.fillRect(px, py, TILE_SIZE, TILE_SIZE);
          ctx.fillStyle = '#0f172a';
          ctx.beginPath();
          ctx.arc(px + 19, py + 24, 14, Math.PI, 0, false);
          ctx.fill();
          ctx.strokeStyle = '#d97706';
          ctx.lineWidth = 2;
          ctx.stroke();

          // Torches on sides
          ctx.fillStyle = '#f59e0b';
          ctx.fillRect(px + 4, py + 14, 3, 3);
          ctx.fillRect(px + 31, py + 14, 3, 3);
        }
      }
    }

    // --- DRAW ENTITIES ---
    mapData.entities.forEach(entity => {
      const ex = entity.x * TILE_SIZE;
      const ey = entity.y * TILE_SIZE;

      if (entity.type === 'SHRINE') {
        // SACRED SAVE SHRINE: Ornate Goddess / Owl Statue with glowing aura & sparkles
        // Radiant ground aura
        ctx.fillStyle = 'rgba(245, 158, 11, 0.25)';
        ctx.beginPath();
        ctx.arc(ex + 19, ey + 24, 20, 0, Math.PI * 2);
        ctx.fill();

        // Marble Plinth Base
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(ex + 7, ey + 24, 24, 10);
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(ex + 9, ey + 22, 20, 4);

        // Goddess Statue Body
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(ex + 13, ey + 10, 12, 14);
        // Wings / Wings of Wisdom
        ctx.fillStyle = '#cbd5e1';
        ctx.beginPath();
        ctx.moveTo(ex + 13, ey + 14);
        ctx.lineTo(ex + 4, ey + 8);
        ctx.lineTo(ex + 13, ey + 22);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(ex + 25, ey + 14);
        ctx.lineTo(ex + 34, ey + 8);
        ctx.lineTo(ex + 25, ey + 22);
        ctx.fill();

        // Glowing Sacred Orb
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.arc(ex + 19, ey + 8, 6, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(ex + 19, ey + 8, 3, 0, Math.PI * 2);
        ctx.fill();

        // Ascending fairy motes
        ctx.fillStyle = 'rgba(254, 240, 138, 0.8)';
        ctx.fillRect(ex + 14, ey + 20 - fairySparkOffset, 3, 3);
        ctx.fillRect(ex + 22, ey + 15 - ((fairySparkOffset + 12) % 30), 2, 2);
      } else if (entity.type === 'NPC_SAGE') {
        // Sage Benjamin Graham: Wise elder in royal robes with silver beard & intrinsic value scroll
        ctx.fillStyle = '#1e3a8a';
        ctx.fillRect(ex + 10, ey + 14, 18, 20);
        ctx.fillStyle = '#ffedd5';
        ctx.fillRect(ex + 13, ey + 8, 12, 8);
        // Silver Beard
        ctx.fillStyle = '#e2e8f0';
        ctx.fillRect(ex + 12, ey + 14, 14, 12);
        // Wizard Hat
        ctx.fillStyle = '#1e3a8a';
        ctx.beginPath();
        ctx.moveTo(ex + 8, ey + 8);
        ctx.lineTo(ex + 19, ey - 2);
        ctx.lineTo(ex + 30, ey + 8);
        ctx.fill();
        // Golden Scroll of Value
        ctx.fillStyle = '#facc15';
        ctx.fillRect(ex + 26, ey + 16, 6, 12);
      } else if (entity.type === 'NPC_BROKER') {
        // Broker in Options Guild Exchange Booth
        ctx.fillStyle = '#7e22ce';
        ctx.fillRect(ex + 8, ey + 12, 22, 22);
        ctx.fillStyle = '#fbbf24';
        ctx.fillRect(ex + 10, ey + 8, 18, 6);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px monospace';
        ctx.fillText('PUT/CALL', ex + 8, ey + 26);
      } else if (entity.type === 'NPC_SCAMMER') {
        // Shady Alchemist / Scammer: Hooded dark cowl with glowing toxic potion
        ctx.fillStyle = '#18181b';
        ctx.fillRect(ex + 9, ey + 10, 20, 24);
        ctx.fillStyle = '#ef4444';
        ctx.fillRect(ex + 13, ey + 15, 3, 2);
        ctx.fillRect(ex + 22, ey + 15, 3, 2);
        // Glowing meme token
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(ex + 27, ey + 22, 5, 0, Math.PI * 2);
        ctx.fill();
      } else if (entity.type === 'NPC_ASSET') {
        // Deep Value Undervalued Asset: Glowing chest / silver ore cart
        ctx.fillStyle = '#ca8a04';
        ctx.fillRect(ex + 6, ey + 12, 26, 20);
        ctx.fillStyle = '#fef08a';
        ctx.font = 'bold 10px monospace';
        ctx.fillText('VALUE', ex + 8, ey + 25);
      } else if (entity.type === 'CHEST') {
        // Ancient Treasury Chest
        ctx.fillStyle = '#78350f';
        ctx.fillRect(ex + 8, ey + 14, 22, 18);
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(ex + 8, ey + 18, 22, 4);
        ctx.fillRect(ex + 17, ey + 20, 4, 5);
      } else if (entity.type === 'BOSS') {
        // Guardian Boss (Drawdown Bear / Chrono Sphinx / Crab Golem)
        ctx.fillStyle = '#991b1b';
        ctx.fillRect(ex + 4, ey + 6, 30, 28);
        ctx.fillStyle = '#fef2f2';
        ctx.font = 'bold 12px monospace';
        ctx.fillText('BOSS', ex + 6, ey + 24);
      }

      // Elegant floating entity badge
      ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
      ctx.fillRect(ex - 8, ey - 10, TILE_SIZE + 16, 14);
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 1;
      ctx.strokeRect(ex - 8, ey - 10, TILE_SIZE + 16, 14);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 9px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(entity.name.slice(0, 16), ex + TILE_SIZE / 2, ey);
      ctx.textAlign = 'start';
    });

    // --- DRAW 16-BIT LINK TO THE PAST AVATAR ---
    const px = player.mapX * TILE_SIZE;
    const py = player.mapY * TILE_SIZE;

    const tunic = TUNIC_COLORS[player.avatar?.tunicColor || 'green'];
    const hair = HAIR_COLORS[player.avatar?.hairColor || 'blonde'];

    // Soft hero shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    ctx.beginPath();
    ctx.ellipse(px + 19, py + 33, 11, 5, 0, 0, Math.PI * 2);
    ctx.fill();

    // Boots (walking step cycle)
    ctx.fillStyle = '#5c381c';
    const isOddStep = walkFrame % 2 === 1;
    if (isOddStep) {
      ctx.fillRect(px + 12, py + 29, 6, 6);
      ctx.fillRect(px + 21, py + 27, 6, 6);
    } else {
      ctx.fillRect(px + 12, py + 27, 6, 6);
      ctx.fillRect(px + 21, py + 29, 6, 6);
    }

    // Tunic Body with shading
    ctx.fillStyle = tunic.main;
    ctx.fillRect(px + 11, py + 15, 16, 14);
    ctx.fillStyle = tunic.shadow;
    ctx.fillRect(px + 11, py + 23, 16, 6);

    // Leather Belt & Golden Buckle
    ctx.fillStyle = '#78350f';
    ctx.fillRect(px + 11, py + 22, 16, 3);
    ctx.fillStyle = '#facc15';
    ctx.fillRect(px + 17, py + 22, 4, 3);

    // Face / Head
    ctx.fillStyle = '#ffedd5';
    ctx.fillRect(px + 13, py + 7, 12, 10);

    // Hair peeking from under cap
    ctx.fillStyle = hair;
    ctx.fillRect(px + 11, py + 9, 3, 5);
    ctx.fillRect(px + 24, py + 9, 3, 5);

    // Eyes
    if (player.facing === 'DOWN') {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(px + 15, py + 11, 2, 3);
      ctx.fillRect(px + 21, py + 11, 2, 3);
    } else if (player.facing === 'LEFT') {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(px + 13, py + 11, 2, 3);
    } else if (player.facing === 'RIGHT') {
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(px + 23, py + 11, 2, 3);
    }

    // 16-Bit Pointy Hero Cap
    ctx.fillStyle = tunic.main;
    if (player.facing === 'UP') {
      ctx.fillRect(px + 11, py + 3, 16, 7);
      ctx.fillStyle = tunic.highlight;
      ctx.fillRect(px + 15, py - 1, 8, 5);
    } else if (player.facing === 'DOWN') {
      ctx.fillRect(px + 11, py + 3, 16, 6);
      ctx.fillStyle = tunic.highlight;
      ctx.fillRect(px + 14, py + 1, 10, 3);
    } else if (player.facing === 'LEFT') {
      ctx.fillRect(px + 9, py + 3, 16, 6);
      ctx.fillRect(px + 6, py + 5, 5, 7);
    } else {
      ctx.fillRect(px + 13, py + 3, 16, 6);
      ctx.fillRect(px + 27, py + 5, 5, 7);
    }

    // Defined-Risk Shield on arm
    const shieldStyle = player.avatar?.shieldStyle || 'hylian';
    if (shieldStyle === 'wooden') {
      ctx.fillStyle = '#92400e';
      ctx.fillRect(px + 6, py + 15, 6, 12);
    } else if (shieldStyle === 'mirror') {
      ctx.fillStyle = '#e2e8f0';
      ctx.fillRect(px + 6, py + 15, 6, 12);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(px + 7, py + 18, 4, 6);
    } else {
      // Hylian Crest Shield
      ctx.fillStyle = '#1d4ed8';
      ctx.fillRect(px + 6, py + 15, 6, 12);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(px + 7, py + 19, 4, 4);
    }

    // Master Sword & Slashing Arc
    if (isSlashing) {
      // Glowing 180° Silver & Cyan Slash Trail
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 4;
      ctx.beginPath();
      if (player.facing === 'RIGHT') {
        ctx.arc(px + 26, py + 18, 20, -Math.PI / 3, Math.PI / 3);
      } else if (player.facing === 'LEFT') {
        ctx.arc(px + 12, py + 18, 20, (2 * Math.PI) / 3, (4 * Math.PI) / 3);
      } else if (player.facing === 'UP') {
        ctx.arc(px + 19, py + 10, 20, -Math.PI, 0);
      } else {
        ctx.arc(px + 19, py + 28, 20, 0, Math.PI);
      }
      ctx.stroke();

      // White inner gleam
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      // Sheathed Master Sword on back
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(px + 26, py + 14, 3, 11);
      ctx.fillStyle = '#f59e0b';
      ctx.fillRect(px + 25, py + 12, 5, 3);
    }

    // Floating Hero Name Badge
    ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
    ctx.fillRect(px - 6, py - 14, TILE_SIZE + 12, 13);
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 1;
    ctx.strokeRect(px - 6, py - 14, TILE_SIZE + 12, 13);
    ctx.fillStyle = '#fef08a';
    ctx.font = 'bold 9px monospace';
    ctx.textAlign = 'center';
    ctx.fillText(player.name, px + TILE_SIZE / 2, py - 4);
    ctx.textAlign = 'start';

  }, [act, mapData, player.mapX, player.mapY, player.facing, player.avatar, player.name, isSlashing, walkFrame, animTick, width, height]);

  return (
    <div className="flex flex-col lg:flex-row gap-4 items-center lg:items-start justify-center">
      {/* 2D Canvas Overworld Frame */}
      <div className="zelda-panel p-3 text-slate-100 rounded-sm relative max-w-full">
        {/* Overworld Title Header */}
        <div className="flex items-center justify-between border-b border-amber-500/40 pb-2 mb-2 text-xs">
          <div className="flex items-center gap-2">
            <Compass className="w-4 h-4 text-amber-400" />
            <span className="text-amber-300 font-bold font-pixel text-xs">
              ACT {mapData.act}: {mapData.name}
            </span>
          </div>

          <div className="flex items-center gap-3 text-slate-300">
            <span className="text-xs bg-slate-950 px-2 py-0.5 border border-amber-500/40 rounded-xs">
              X:{player.mapX} Y:{player.mapY}
            </span>
          </div>
        </div>

        {/* Canvas Screen */}
        <div className="overflow-x-auto select-none rounded-xs border-2 border-amber-500/80 shadow-2xl">
          <canvas
            ref={canvasRef}
            width={width}
            height={height}
            className="block max-w-full h-auto cursor-pointer"
            onClick={triggerSlash}
            title="Click to Swing Master Sword"
          />
        </div>

        {/* Proximity Interaction Prompt Banner */}
        {nearbyEntity && (
          <div className="absolute bottom-5 left-5 right-5 bg-slate-950/95 border-2 border-amber-400 p-2.5 text-amber-300 text-xs flex items-center justify-between shadow-2xl rounded-xs">
            <div className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-amber-400" />
              <span className="font-bold uppercase tracking-wide">
                {nearbyEntity.interactPrompt}
              </span>
            </div>
            <button
              onClick={() => onInteractEntity(nearbyEntity)}
              className="px-3.5 py-1.5 bg-amber-400 text-slate-950 font-extrabold cursor-pointer hover:bg-amber-300 text-xs uppercase rounded-xs shadow-md"
            >
              [E / SPACE TO ACT]
            </button>
          </div>
        )}
      </div>

      {/* SNES Controller & Quick Actions Sidebar */}
      <div className="zelda-panel p-4 flex flex-col items-center gap-4 w-full lg:w-72 text-xs">
        <div className="font-bold border-b border-amber-500/40 pb-1.5 w-full text-center text-amber-300 font-pixel text-[11px]">
          HYLIAN CONTROLS
        </div>

        {/* D-Pad Buttons */}
        <div className="grid grid-cols-3 gap-1.5 w-36 h-36">
          <div />
          <button
            onClick={() => handleStep(0, -1, 'UP')}
            className="bg-slate-900 border-2 border-amber-500/70 hover:bg-amber-500 hover:text-black flex items-center justify-center font-bold text-sm cursor-pointer p-2 rounded-xs active:scale-95 shadow-sm"
            title="Walk North [W / ArrowUp]"
          >
            <ArrowUp className="w-5 h-5 text-amber-300" />
          </button>
          <div />

          <button
            onClick={() => handleStep(-1, 0, 'LEFT')}
            className="bg-slate-900 border-2 border-amber-500/70 hover:bg-amber-500 hover:text-black flex items-center justify-center font-bold text-sm cursor-pointer p-2 rounded-xs active:scale-95 shadow-sm"
            title="Walk West [A / ArrowLeft]"
          >
            <ArrowLeft className="w-5 h-5 text-amber-300" />
          </button>

          <div className="border border-amber-500/20 bg-slate-950 flex items-center justify-center text-[10px] text-amber-400/60 font-bold rounded-xs">
            D-PAD
          </div>

          <button
            onClick={() => handleStep(1, 0, 'RIGHT')}
            className="bg-slate-900 border-2 border-amber-500/70 hover:bg-amber-500 hover:text-black flex items-center justify-center font-bold text-sm cursor-pointer p-2 rounded-xs active:scale-95 shadow-sm"
            title="Walk East [D / ArrowRight]"
          >
            <ArrowRight className="w-5 h-5 text-amber-300" />
          </button>

          <div />
          <button
            onClick={() => handleStep(0, 1, 'DOWN')}
            className="bg-slate-900 border-2 border-amber-500/70 hover:bg-amber-500 hover:text-black flex items-center justify-center font-bold text-sm cursor-pointer p-2 rounded-xs active:scale-95 shadow-sm"
            title="Walk South [S / ArrowDown]"
          >
            <ArrowDown className="w-5 h-5 text-amber-300" />
          </button>
          <div />
        </div>

        {/* Action Buttons */}
        <div className="w-full space-y-2 pt-1 border-t border-amber-500/30">
          <button
            onClick={triggerSlash}
            className="w-full py-2.5 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold uppercase rounded-xs cursor-pointer flex items-center justify-center gap-2 shadow-md"
          >
            <Swords className="w-4 h-4" />
            <span>[SPACE] Master Sword</span>
          </button>

          {nearbyEntity ? (
            <button
              onClick={() => onInteractEntity(nearbyEntity)}
              className="w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold uppercase rounded-xs cursor-pointer flex items-center justify-center gap-1.5 shadow-md"
            >
              <Sparkles className="w-4 h-4" />
              <span>[E] Interact With NPC</span>
            </button>
          ) : (
            <div className="text-[11px] text-slate-400 text-center py-1">
              Walk near NPCs or Shrines to interact.
            </div>
          )}
        </div>

        {/* Save Point & Hero Customizer Quick Links */}
        <div className="w-full grid grid-cols-2 gap-2 pt-2 border-t border-amber-500/30">
          {onOpenSaveModal && (
            <button
              onClick={onOpenSaveModal}
              className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 border border-amber-500/50 text-amber-300 font-bold text-xs rounded-xs flex items-center justify-center gap-1 cursor-pointer"
              title="Open Save Game Parchment"
            >
              <Save className="w-3.5 h-3.5 text-amber-400" />
              <span>Save Game</span>
            </button>
          )}

          {onOpenCustomizeModal && (
            <button
              onClick={onOpenCustomizeModal}
              className="py-1.5 px-2 bg-slate-900 hover:bg-slate-800 border border-amber-500/50 text-amber-300 font-bold text-xs rounded-xs flex items-center justify-center gap-1 cursor-pointer"
              title="Customize Hero Avatar & Name"
            >
              <User className="w-3.5 h-3.5 text-amber-400" />
              <span>Hero Name</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
