import React, { useState, useEffect } from 'react';
import { CombatState, PlayerStats, EnemyStats, CombatAttackPuzzle } from '../types';
import { getAttackPuzzleForTier } from '../lib/combatPuzzles';
import { sound } from '../lib/audioEngine';
import { Swords, Shield, Sparkles, Heart, AlertTriangle, BookOpen, CheckCircle2 } from 'lucide-react';

interface ZeldaCombatModalProps {
  combat: CombatState;
  player: PlayerStats;
  onExecutePuzzleAttack: (bonusDamage: number, isCorrect: boolean, explanation: string) => void;
  onShieldBlock: () => void;
  onUseItem: (itemType: 'healthElixir' | 'ivStabilizer' | 'timeHourglass') => void;
  onFlee: () => void;
}

export const ZeldaCombatModal: React.FC<ZeldaCombatModalProps> = ({
  combat,
  player,
  onExecutePuzzleAttack,
  onShieldBlock,
  onUseItem,
  onFlee
}) => {
  const enemy = combat.enemy;
  const [activePuzzle, setActivePuzzle] = useState<CombatAttackPuzzle | null>(null);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [puzzleOutcome, setPuzzleOutcome] = useState<{ isCorrect: boolean; explanation: string; bonus: number } | null>(null);
  const [isSlashing, setIsSlashing] = useState(false);

  // Load a puzzle scaled by player's Heart Container level / investorTier
  const openAttackPuzzle = () => {
    const tier = player.investorTier || 1;
    const p = getAttackPuzzleForTier(tier);
    setActivePuzzle(p);
    setSelectedOption(null);
    setPuzzleOutcome(null);
  };

  const handleSolvePuzzle = (idx: number) => {
    if (!activePuzzle) return;
    const opt = activePuzzle.options[idx];
    setSelectedOption(idx);
    setPuzzleOutcome({
      isCorrect: opt.isCorrect,
      explanation: opt.explanation,
      bonus: opt.damageBonus
    });

    if (opt.isCorrect) {
      sound.playSwordSlash();
      setIsSlashing(true);
      setTimeout(() => setIsSlashing(false), 300);
    } else {
      sound.playAlarmSound();
    }
  };

  const handleConfirmAttack = () => {
    if (!puzzleOutcome) return;
    onExecutePuzzleAttack(puzzleOutcome.bonus, puzzleOutcome.isCorrect, puzzleOutcome.explanation);
    setActivePuzzle(null);
    setSelectedOption(null);
    setPuzzleOutcome(null);
  };

  if (!enemy) return null;

  const enemyHpPercent = Math.max(0, Math.min(100, (enemy.currentHp / enemy.maxHp) * 100));

  // Render player hearts
  const renderHearts = () => {
    const hearts = [];
    const total = player.maxHearts || 4;
    for (let i = 0; i < total; i++) {
      const remaining = player.hearts - i;
      if (remaining >= 1) {
        hearts.push(<span key={i} className="text-red-500">❤️</span>);
      } else if (remaining >= 0.4) {
        hearts.push(<span key={i} className="text-red-400">💔</span>);
      } else {
        hearts.push(<span key={i} className="opacity-30 grayscale">🖤</span>);
      }
    }
    return hearts;
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-3 font-mono">
      <div className="dos-box w-full max-w-3xl bg-[#080d08] border-2 border-red-500 p-4 select-none max-h-[95vh] overflow-y-auto shadow-2xl text-xs">
        {/* Battle Header */}
        <div className="flex items-center justify-between border-b-2 border-red-500 pb-2 mb-3">
          <div className="flex items-center gap-2">
            <Swords className="w-5 h-5 text-red-500 animate-pulse" />
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-red-400">
                TACTICAL ZELDA COMBAT ARENA
              </h2>
              <p className="text-[10px] opacity-75">TURN #{combat.turn} • MARKET RISK FACTOR: {enemy.riskSensitivity}x</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center gap-0.5 text-sm sm:text-base">
              {renderHearts()}
            </div>
            <span className="font-bold text-red-400">
              {player.hearts.toFixed(1)}/{player.maxHearts}
            </span>
          </div>
        </div>

        {/* Combat Battlefield Arena */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
          {/* Enemy Card */}
          <div className="bg-black/70 border border-red-500/60 p-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-extrabold text-red-400 text-sm">{enemy.name}</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-red-950 border border-red-500 text-red-300">
                  {enemy.type}
                </span>
              </div>
              <p className="text-[11px] opacity-80 italic mb-2">"{enemy.title}"</p>

              {/* Enemy HP Bar */}
              <div className="mb-2">
                <div className="flex justify-between text-[10px] mb-0.5">
                  <span className="opacity-70">ENERGY / HP</span>
                  <span className="font-bold text-red-400">{enemy.currentHp} / {enemy.maxHp}</span>
                </div>
                <div className="w-full h-3 bg-red-950 border border-red-500 rounded-xs overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-red-600 to-yellow-500 transition-all duration-300"
                    style={{ width: `${enemyHpPercent}%` }}
                  />
                </div>
              </div>

              <div className="p-2 border border-red-500/40 bg-red-950/20 text-[11px] text-red-200">
                <span className="font-bold">SPECIAL MOVE:</span> {enemy.specialMove}
              </div>
            </div>

            {/* Pixel Monster Avatar placeholder */}
            <div className="h-20 flex items-center justify-center border border-red-500/30 bg-black/50 my-2 text-red-400 text-2xl font-bold tracking-widest">
              [ {enemy.type === 'BEAR' ? '🐻 GRIZZLY BEAR' : enemy.type === 'HYDRA' ? '🐉 VEGA HYDRA' : '🦀 CRAB GOLEM'} ]
            </div>
          </div>

          {/* Player Combat Status & Battle Log */}
          <div className="bg-black/70 border border-current/60 p-3 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-1">
                <span className="font-bold text-yellow-300">{player.name} ({player.title})</span>
                <span className="text-[10px] px-1.5 py-0.5 bg-yellow-950/60 border border-yellow-400 text-yellow-300">
                  TIER {player.investorTier}
                </span>
              </div>

              {/* Combat Log */}
              <div className="h-32 overflow-y-auto border border-current/40 p-2 bg-black/90 space-y-1 text-[11px]">
                <div className="text-yellow-300 font-bold border-b border-current/20 pb-0.5">
                  ACTION LOG:
                </div>
                {combat.combatLog.slice(-5).map((log, idx) => (
                  <div key={idx} className="opacity-90 leading-tight">
                    {log}
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Status Badges */}
            <div className="grid grid-cols-3 gap-1 pt-2 text-center text-[10px]">
              <div className="p-1 border border-current/30 bg-black/60">
                <span className="opacity-70">FLORINS:</span>{' '}
                <strong className="text-yellow-300">{player.florins}ƒ</strong>
              </div>
              <div className="p-1 border border-current/30 bg-black/60">
                <span className="opacity-70">PORTFOLIO Δ:</span>{' '}
                <strong className={player.netDelta >= 0 ? 'text-green-400' : 'text-red-400'}>
                  {player.netDelta.toFixed(2)}
                </strong>
              </div>
              <div className="p-1 border border-current/30 bg-black/60">
                <span className="opacity-70">ELIXIRS:</span>{' '}
                <strong className="text-cyan-300">{player.potions.healthElixir}</strong>
              </div>
            </div>
          </div>
        </div>

        {/* Tactical Attack Puzzle Modal / Section */}
        {activePuzzle ? (
          <div className="bg-black/95 border-2 border-yellow-400 p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-yellow-400/50 pb-2">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-yellow-300" />
                <span className="font-extrabold text-sm text-yellow-300 uppercase">
                  ATTACK PUZZLE (TIER {activePuzzle.difficultyTier})
                </span>
              </div>
              <span className="text-[10px] text-yellow-200">SOLVE TO STRIKE WITH SWORD</span>
            </div>

            <p className="text-xs font-semibold text-white leading-relaxed">
              {activePuzzle.prompt}
            </p>
            <p className="text-[11px] opacity-75 italic">
              Context: {activePuzzle.context}
            </p>

            {/* Puzzle Options */}
            <div className="space-y-2 pt-1">
              {activePuzzle.options.map((opt, idx) => {
                const isSelected = selectedOption === idx;
                let optStyle = 'border-current bg-black/60 hover:bg-yellow-400 hover:text-black';

                if (puzzleOutcome) {
                  if (opt.isCorrect) {
                    optStyle = 'border-green-400 bg-green-950/80 text-green-200 font-bold';
                  } else if (isSelected) {
                    optStyle = 'border-red-500 bg-red-950/80 text-red-200';
                  } else {
                    optStyle = 'opacity-30 border-gray-700 text-gray-500';
                  }
                }

                return (
                  <button
                    key={idx}
                    disabled={puzzleOutcome !== null}
                    onClick={() => handleSolvePuzzle(idx)}
                    className={`w-full text-left p-2.5 border transition-all text-xs cursor-pointer ${optStyle}`}
                  >
                    <span className="font-bold mr-2">[{opt.label}]</span>
                    {opt.text}
                  </button>
                );
              })}
            </div>

            {/* Feedback & Confirm */}
            {puzzleOutcome && (
              <div className={`p-2.5 border text-xs leading-relaxed space-y-2 ${
                puzzleOutcome.isCorrect
                  ? 'border-green-400 bg-green-950/40 text-green-200'
                  : 'border-red-400 bg-red-950/40 text-red-200'
              }`}>
                <div className="font-bold flex items-center gap-1.5">
                  {puzzleOutcome.isCorrect ? (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-green-400" />
                      <span>CRITICAL STRIKE! CORRECT OPTIONS THESIS! (+{puzzleOutcome.bonus} DMG)</span>
                    </>
                  ) : (
                    <>
                      <AlertTriangle className="w-4 h-4 text-red-400" />
                      <span>ATTACK BACKFIRED! FLAWED OPTIONS THESIS!</span>
                    </>
                  )}
                </div>
                <p>{puzzleOutcome.explanation}</p>

                <button
                  onClick={handleConfirmAttack}
                  className="w-full py-2 bg-yellow-400 text-black font-extrabold cursor-pointer hover:bg-yellow-300 uppercase text-center"
                >
                  EXECUTE STRIKE & RESOLVE COMBAT TURN ⚔️
                </button>
              </div>
            )}
          </div>
        ) : (
          /* Combat Command Center */
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t-2 border-red-500/60">
            {/* Attack Button (Triggers Puzzle) */}
            <button
              onClick={openAttackPuzzle}
              className="p-3 border-2 border-yellow-400 bg-yellow-500/20 hover:bg-yellow-400 hover:text-black font-extrabold flex flex-col items-center gap-1 cursor-pointer transition-colors"
            >
              <Swords className="w-5 h-5 text-yellow-300" />
              <span>[1] SWORD ATTACK</span>
              <span className="text-[9px] opacity-75 font-normal">Solve Puzzle to Strike</span>
            </button>

            {/* Shield Block */}
            <button
              onClick={onShieldBlock}
              className="p-3 border-2 border-cyan-400 bg-cyan-500/20 hover:bg-cyan-400 hover:text-black font-bold flex flex-col items-center gap-1 cursor-pointer transition-colors"
            >
              <Shield className="w-5 h-5 text-cyan-300" />
              <span>[2] SHIELD BLOCK</span>
              <span className="text-[9px] opacity-75 font-normal">Defined Risk Defense</span>
            </button>

            {/* Potion / Item */}
            <button
              disabled={player.potions.healthElixir <= 0}
              onClick={() => onUseItem('healthElixir')}
              className={`p-3 border-2 border-green-400 bg-green-500/20 font-bold flex flex-col items-center gap-1 transition-colors ${
                player.potions.healthElixir > 0
                  ? 'hover:bg-green-400 hover:text-black cursor-pointer'
                  : 'opacity-40 cursor-not-allowed'
              }`}
            >
              <Sparkles className="w-5 h-5 text-green-300" />
              <span>[3] USE ELIXIR</span>
              <span className="text-[9px] opacity-75 font-normal">
                Heal +2.0 Hearts ({player.potions.healthElixir})
              </span>
            </button>

            {/* Flee */}
            <button
              onClick={onFlee}
              className="p-3 border-2 border-gray-500 bg-gray-900/40 hover:bg-gray-700 hover:text-white font-bold flex flex-col items-center gap-1 cursor-pointer transition-colors"
            >
              <span>[4] FLEE / RETREAT</span>
              <span className="text-[9px] opacity-75 font-normal">Return to Overworld</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
