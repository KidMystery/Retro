import React, { useState, useMemo } from 'react';
import { StrategyType, PlayerStats, AssetQuote, OptionContract } from '../types';
import { calculateBlackScholes, generateAsciiPayoffChart } from '../lib/blackScholes';
import { sound } from '../lib/audioEngine';
import { BarChart2, DollarSign, ShieldAlert, ArrowRight, X } from 'lucide-react';

interface TradeDeskModalProps {
  player: PlayerStats;
  asset: AssetQuote;
  onExecuteTrade: (contract: OptionContract, netCost: number, marginReq: number) => void;
  onClose: () => void;
}

export const TradeDeskModal: React.FC<TradeDeskModalProps> = ({
  player,
  asset,
  onExecuteTrade,
  onClose
}) => {
  const [strategy, setStrategy] = useState<StrategyType>('LONG_CALL');
  const [strikeOffset, setStrikeOffset] = useState<number>(0); // 0 = ATM, -5 = ITM/OTM, +5 = OTM/ITM
  const [dte, setDte] = useState<number>(30);
  const [contractsCount, setContractsCount] = useState<number>(1);

  const spot = asset.spotPrice;
  const iv = asset.iv;

  // Selected Strike based on spot and offset
  const selectedStrike = Math.round(spot + strikeOffset);

  // Calculate Black Scholes values
  const bsCall = useMemo(() => calculateBlackScholes(spot, selectedStrike, dte, iv, 0.05, true), [spot, selectedStrike, dte, iv]);
  const bsPut = useMemo(() => calculateBlackScholes(spot, selectedStrike, dte, iv, 0.05, false), [spot, selectedStrike, dte, iv]);

  // Pricing & Greek values based on chosen strategy
  const tradeDetails = useMemo(() => {
    let type: 'CALL' | 'PUT' = 'CALL';
    let premium = bsCall.price;
    let delta = bsCall.delta;
    let gamma = bsCall.gamma;
    let theta = bsCall.theta;
    let vega = bsCall.vega;
    let maxLoss = premium * 100 * contractsCount;
    let maxProfit = Infinity;
    let breakEven = selectedStrike + premium;
    let marginRequired = 0;
    let netCost = premium * 100 * contractsCount;

    if (strategy === 'LONG_CALL') {
      type = 'CALL';
      premium = bsCall.price;
      delta = bsCall.delta;
      theta = bsCall.theta;
      maxLoss = premium * 100 * contractsCount;
      breakEven = selectedStrike + premium;
      marginRequired = 0;
      netCost = maxLoss;
    } else if (strategy === 'LONG_PUT') {
      type = 'PUT';
      premium = bsPut.price;
      delta = bsPut.delta;
      theta = bsPut.theta;
      maxLoss = premium * 100 * contractsCount;
      breakEven = selectedStrike - premium;
      marginRequired = 0;
      netCost = maxLoss;
    } else if (strategy === 'BULL_CALL_SPREAD') {
      // Buy strike K, Sell strike K+6
      const bsShortCall = calculateBlackScholes(spot, selectedStrike + 6, dte, iv, 0.05, true);
      const netPremium = Math.max(0.5, bsCall.price - bsShortCall.price);
      premium = Number(netPremium.toFixed(2));
      delta = Number((bsCall.delta - bsShortCall.delta).toFixed(3));
      theta = Number((bsCall.theta - bsShortCall.theta).toFixed(3));
      maxLoss = premium * 100 * contractsCount;
      maxProfit = (6 - premium) * 100 * contractsCount;
      breakEven = selectedStrike + premium;
      netCost = maxLoss;
      marginRequired = 0;
    } else if (strategy === 'BEAR_PUT_SPREAD') {
      // Buy strike K, Sell strike K-6
      const bsShortPut = calculateBlackScholes(spot, selectedStrike - 6, dte, iv, 0.05, false);
      const netPremium = Math.max(0.5, bsPut.price - bsShortPut.price);
      premium = Number(netPremium.toFixed(2));
      delta = Number((bsPut.delta - bsShortPut.delta).toFixed(3));
      theta = Number((bsPut.theta - bsShortPut.theta).toFixed(3));
      maxLoss = premium * 100 * contractsCount;
      maxProfit = (6 - premium) * 100 * contractsCount;
      breakEven = selectedStrike - premium;
      netCost = maxLoss;
      marginRequired = 0;
    } else if (strategy === 'CASH_SECURED_PUT') {
      type = 'PUT';
      premium = bsPut.price;
      delta = -bsPut.delta; // Positive delta when selling puts!
      theta = -bsPut.theta; // Positive daily theta flow!
      netCost = -premium * 100 * contractsCount; // Credit received upfront!
      marginRequired = selectedStrike * 100 * contractsCount; // Cash collateral
      maxLoss = (selectedStrike - premium) * 100 * contractsCount;
      maxProfit = premium * 100 * contractsCount;
      breakEven = selectedStrike - premium;
    } else if (strategy === 'IRON_CONDOR') {
      // Four legs around spot: Sell Put at spot-5, Buy Put at spot-10, Sell Call at spot+5, Buy Call at spot+10
      const shortPut = calculateBlackScholes(spot, spot - 5, dte, iv, 0.05, false);
      const longPut = calculateBlackScholes(spot, spot - 10, dte, iv, 0.05, false);
      const shortCall = calculateBlackScholes(spot, spot + 5, dte, iv, 0.05, true);
      const longCall = calculateBlackScholes(spot, spot + 10, dte, iv, 0.05, true);

      const creditPut = shortPut.price - longPut.price;
      const creditCall = shortCall.price - longCall.price;
      const totalCredit = Math.max(0.8, Number((creditPut + creditCall).toFixed(2)));

      premium = totalCredit;
      delta = 0.02; // Delta neutral
      theta = Number((-(shortPut.theta + shortCall.theta) + (longPut.theta + longCall.theta)).toFixed(3));
      netCost = -totalCredit * 100 * contractsCount; // Credit upfront
      marginRequired = (5 - totalCredit) * 100 * contractsCount; // Width minus credit
      maxProfit = totalCredit * 100 * contractsCount;
      maxLoss = (5 - totalCredit) * 100 * contractsCount;
      breakEven = spot - 5 - totalCredit;
    } else if (strategy === 'LONG_STRADDLE') {
      // Buy ATM Call + ATM Put
      const straddleCost = bsCall.price + bsPut.price;
      premium = Number(straddleCost.toFixed(2));
      delta = Number((bsCall.delta + bsPut.delta).toFixed(3));
      theta = Number((bsCall.theta + bsPut.theta).toFixed(3));
      vega = Number((bsCall.vega + bsPut.vega).toFixed(3));
      maxLoss = straddleCost * 100 * contractsCount;
      netCost = maxLoss;
      breakEven = selectedStrike + straddleCost;
      marginRequired = 0;
    }

    return {
      type,
      premium,
      delta: delta * contractsCount,
      gamma: gamma * contractsCount,
      theta: theta * contractsCount,
      vega: vega * contractsCount,
      netCost,
      marginRequired,
      maxLoss,
      maxProfit,
      breakEven
    };
  }, [strategy, selectedStrike, dte, spot, iv, contractsCount, bsCall, bsPut]);

  // Generate ASCII Payoff Diagram
  const asciiChart = useMemo(() => {
    const legs: Array<{ type: 'CALL' | 'PUT'; strike: number; premium: number; quantity: number }> = [];

    if (strategy === 'LONG_CALL') {
      legs.push({ type: 'CALL', strike: selectedStrike, premium: tradeDetails.premium, quantity: contractsCount });
    } else if (strategy === 'LONG_PUT') {
      legs.push({ type: 'PUT', strike: selectedStrike, premium: tradeDetails.premium, quantity: contractsCount });
    } else if (strategy === 'BULL_CALL_SPREAD') {
      legs.push({ type: 'CALL', strike: selectedStrike, premium: bsCall.price, quantity: contractsCount });
      legs.push({ type: 'CALL', strike: selectedStrike + 6, premium: bsCall.price - tradeDetails.premium, quantity: -contractsCount });
    } else if (strategy === 'BEAR_PUT_SPREAD') {
      legs.push({ type: 'PUT', strike: selectedStrike, premium: bsPut.price, quantity: contractsCount });
      legs.push({ type: 'PUT', strike: selectedStrike - 6, premium: bsPut.price - tradeDetails.premium, quantity: -contractsCount });
    } else if (strategy === 'IRON_CONDOR') {
      legs.push({ type: 'PUT', strike: Math.round(spot - 5), premium: 2.2, quantity: -contractsCount });
      legs.push({ type: 'PUT', strike: Math.round(spot - 10), premium: 0.8, quantity: contractsCount });
      legs.push({ type: 'CALL', strike: Math.round(spot + 5), premium: 2.2, quantity: -contractsCount });
      legs.push({ type: 'CALL', strike: Math.round(spot + 10), premium: 0.8, quantity: contractsCount });
    } else if (strategy === 'LONG_STRADDLE') {
      legs.push({ type: 'CALL', strike: selectedStrike, premium: bsCall.price, quantity: contractsCount });
      legs.push({ type: 'PUT', strike: selectedStrike, premium: bsPut.price, quantity: contractsCount });
    }

    return generateAsciiPayoffChart(legs, spot);
  }, [strategy, selectedStrike, tradeDetails, contractsCount, spot, bsCall, bsPut]);

  const canAfford = player.florins >= tradeDetails.netCost + tradeDetails.marginRequired;

  const handleExecute = () => {
    if (!canAfford) {
      sound.playAlarmSound();
      return;
    }

    sound.playCoinSound();
    const newContract: OptionContract = {
      id: `opt_${Date.now()}`,
      symbol: asset.symbol,
      type: tradeDetails.type,
      strike: selectedStrike,
      dte,
      premium: tradeDetails.premium,
      entryPrice: tradeDetails.premium,
      quantity: contractsCount,
      strategy,
      delta: tradeDetails.delta,
      gamma: tradeDetails.gamma,
      theta: tradeDetails.theta,
      vega: tradeDetails.vega
    };

    onExecuteTrade(newContract, tradeDetails.netCost, tradeDetails.marginRequired);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 overflow-y-auto">
      <div className="dos-box p-4 bg-[#070b07] text-current w-full max-w-4xl max-h-[92vh] flex flex-col font-mono text-xs sm:text-sm">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-current pb-2 mb-3">
          <div className="flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-cyan-400" />
            <h2 className="font-bold text-base uppercase tracking-wider">
              TERMINAL EXCHANGE // DERIVATIVES TRADING DESK
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 border border-current hover:bg-current hover:text-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Market Ticker Bar */}
          <div className="p-2 border border-dashed border-current flex flex-wrap justify-between items-center bg-black/60 text-xs">
            <div>
              <span className="opacity-75">UNDERLYING:</span>{' '}
              <span className="font-bold text-yellow-300">{asset.name} ({asset.symbol})</span>
            </div>
            <div>
              <span className="opacity-75">SPOT:</span>{' '}
              <span className="font-bold text-cyan-300">{spot.toFixed(2)} Florins</span>
            </div>
            <div>
              <span className="opacity-75">IMPLIED VOL (IV):</span>{' '}
              <span className="font-bold text-purple-300">{(iv * 100).toFixed(1)}%</span>
            </div>
            <div>
              <span className="opacity-75">YOUR CASH:</span>{' '}
              <span className="font-bold text-green-400">{player.florins.toLocaleString()} ƒ</span>
            </div>
          </div>

          {/* Strategy Selector Buttons */}
          <div>
            <div className="font-bold mb-1.5 opacity-80 text-xs">SELECT OPTIONS STRATEGY / SPELL:</div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-xs">
              {[
                { id: 'LONG_CALL', label: 'Long Call (Bull Strike)', desc: 'Leveraged upside, defined loss' },
                { id: 'LONG_PUT', label: 'Long Put (Bear Shield)', desc: 'Protective crash hedge' },
                { id: 'BULL_CALL_SPREAD', label: 'Bull Call Spread', desc: 'Defined risk, low theta decay' },
                { id: 'BEAR_PUT_SPREAD', label: 'Bear Put Spread', desc: 'Defined risk downside spread' },
                { id: 'CASH_SECURED_PUT', label: 'Cash-Secured Put', desc: 'Collect upfront premium credit' },
                { id: 'IRON_CONDOR', label: 'Iron Condor (Neutral)', desc: 'Rangebound high IV harvester' },
                { id: 'LONG_STRADDLE', label: 'Long Straddle', desc: 'Explosive volatility catalyst' }
              ].map(strat => (
                <button
                  key={strat.id}
                  onClick={() => {
                    sound.playKeyClick();
                    setStrategy(strat.id as StrategyType);
                  }}
                  className={`p-2 text-left border border-current cursor-pointer transition-colors ${
                    strategy === strat.id ? 'bg-current text-black font-bold' : 'hover:bg-current/15'
                  }`}
                >
                  <div className="font-bold">{strat.label}</div>
                  <div className={`text-[10px] ${strategy === strat.id ? 'text-black/80' : 'opacity-70'}`}>
                    {strat.desc}
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Configuration Sliders (Strike, DTE, Quantity) */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 border border-current bg-black/60">
            {/* Strike offset */}
            <div>
              <div className="flex justify-between mb-1 text-xs">
                <span>STRIKE PRICE:</span>
                <span className="font-bold text-yellow-300">
                  {selectedStrike} ƒ ({strikeOffset >= 0 ? `+${strikeOffset}` : strikeOffset})
                </span>
              </div>
              <input
                type="range"
                min="-15"
                max="15"
                step="1"
                value={strikeOffset}
                onChange={e => setStrikeOffset(Number(e.target.value))}
                className="w-full cursor-pointer accent-current"
              />
              <div className="flex justify-between text-[10px] opacity-60 mt-0.5">
                <span>ITM (-15)</span>
                <span>ATM (0)</span>
                <span>OTM (+15)</span>
              </div>
            </div>

            {/* DTE Expiration */}
            <div>
              <div className="flex justify-between mb-1 text-xs">
                <span>EXPIRATION DURATION:</span>
                <span className="font-bold text-cyan-300">{dte} Days to Expiry</span>
              </div>
              <input
                type="range"
                min="7"
                max="90"
                step="1"
                value={dte}
                onChange={e => setDte(Number(e.target.value))}
                className="w-full cursor-pointer accent-current"
              />
              <div className="flex justify-between text-[10px] opacity-60 mt-0.5">
                <span>7 DTE (Hyper Decay)</span>
                <span>45 DTE (Ideal)</span>
                <span>90 DTE (Slow)</span>
              </div>
            </div>

            {/* Quantity */}
            <div>
              <div className="flex justify-between mb-1 text-xs">
                <span>CONTRACTS (x100 shares):</span>
                <span className="font-bold text-green-300">{contractsCount} Contract(s)</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={contractsCount}
                onChange={e => setContractsCount(Number(e.target.value))}
                className="w-full cursor-pointer accent-current"
              />
              <div className="flex justify-between text-[10px] opacity-60 mt-0.5">
                <span>1 (100 shares)</span>
                <span>5</span>
                <span>10 (1000 shares)</span>
              </div>
            </div>
          </div>

          {/* Pricing & Greeks Breakdown */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">PREMIUM PER SHARE</div>
              <div className="font-bold text-yellow-300 text-sm">{tradeDetails.premium.toFixed(2)} ƒ</div>
              <div className="text-[10px] opacity-60">Contract: {(tradeDetails.premium * 100).toFixed(0)} ƒ</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">DELTA (Δ)</div>
              <div className="font-bold text-yellow-300 text-sm">{tradeDetails.delta.toFixed(2)}</div>
              <div className="text-[10px] opacity-60">Price sensitivity</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">DAILY THETA (Θ)</div>
              <div className={`font-bold text-sm ${tradeDetails.theta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {tradeDetails.theta >= 0 ? '+' : ''}{tradeDetails.theta.toFixed(1)} ƒ/day
              </div>
              <div className="text-[10px] opacity-60">Time decay</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">BREAK-EVEN SPOT</div>
              <div className="font-bold text-cyan-300 text-sm">{tradeDetails.breakEven.toFixed(2)} ƒ</div>
              <div className="text-[10px] opacity-60">Target at Expiry</div>
            </div>
          </div>

          {/* ASCII Payoff Chart View */}
          <div className="overflow-x-auto select-none p-1 bg-black border border-current text-[10px] sm:text-xs leading-none">
            <pre className="whitespace-pre font-mono">{asciiChart}</pre>
          </div>
        </div>

        {/* Footer with Execution & Cost */}
        <div className="border-t border-current pt-3 mt-3 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div>
            <div>
              <span className="opacity-75">NET OUTFLOW / CAPITAL REQ:</span>{' '}
              <span className="font-bold text-yellow-300 text-sm">
                {tradeDetails.netCost >= 0
                  ? `${tradeDetails.netCost.toLocaleString()} ƒ`
                  : `+${Math.abs(tradeDetails.netCost).toLocaleString()} ƒ (CREDIT COLLECTED)`}
              </span>
            </div>
            {tradeDetails.marginRequired > 0 && (
              <div className="text-[11px] text-amber-300">
                Collateral / Margin Held: {tradeDetails.marginRequired.toLocaleString()} ƒ
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-3 py-1.5 border border-current hover:bg-current/20 cursor-pointer"
            >
              CANCEL
            </button>
            <button
              onClick={handleExecute}
              disabled={!canAfford}
              className={`px-4 py-1.5 border border-current font-bold flex items-center gap-1.5 ${
                canAfford
                  ? 'bg-current text-black hover:opacity-90 cursor-pointer'
                  : 'opacity-40 cursor-not-allowed bg-red-950 text-red-300 border-red-500'
              }`}
            >
              <span>EXECUTE DERIVATIVE CONTRACT</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
