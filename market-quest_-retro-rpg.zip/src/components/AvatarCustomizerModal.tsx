import React, { useState } from 'react';
import { PlayerStats, TunicColor, HairColor, AvatarConfig } from '../types';
import { sound } from '../lib/audioEngine';
import { Shield, Sparkles, Check, User, Wand2 } from 'lucide-react';

interface AvatarCustomizerModalProps {
  player: PlayerStats;
  onSaveProfile: (name: string, title: string, avatar: AvatarConfig) => void;
  onClose: () => void;
}

const TUNIC_OPTIONS: { id: TunicColor; name: string; hex: string; desc: string }[] = [
  { id: 'green', name: "Kokiri Emerald", hex: '#2e7d32', desc: 'Classic Hero green tunic of the forest' },
  { id: 'blue', name: "Zora Blue Mail", hex: '#1e40af', desc: 'Regal sapphire tunic with cold volatility shield' },
  { id: 'red', name: "Goron Red Mail", hex: '#b91c1c', desc: 'Tempered crimson mail with dragon fortitude' },
  { id: 'purple', name: "Royal Amethyst", hex: '#7e22ce', desc: 'Mystic royal purple of the Value Oracles' },
  { id: 'black', name: "Shadow Knight", hex: '#1f2937', desc: 'Stealth obsidian mail for nocturnal trading' }
];

const HAIR_OPTIONS: { id: HairColor; name: string; hex: string }[] = [
  { id: 'blonde', name: 'Hylian Gold', hex: '#facc15' },
  { id: 'brown', name: 'Chestnut Brown', hex: '#78350f' },
  { id: 'black', name: 'Raven Black', hex: '#111827' },
  { id: 'white', name: 'Silver Wisdom', hex: '#e2e8f0' }
];

const TITLE_OPTIONS = [
  'Hero of Valuaria',
  'Knight of the Margin of Safety',
  'Oracle of Option Greeks',
  'Apprentice of the Black-Scholes',
  'Guardian of Fair Value'
];

export const AvatarCustomizerModal: React.FC<AvatarCustomizerModalProps> = ({
  player,
  onSaveProfile,
  onClose
}) => {
  const [heroName, setHeroName] = useState(player.name || 'Link Alex');
  const [selectedTitle, setSelectedTitle] = useState(player.title || 'Hero of Valuaria');
  const [tunicColor, setTunicColor] = useState<TunicColor>(player.avatar?.tunicColor || 'green');
  const [hairColor, setHairColor] = useState<HairColor>(player.avatar?.hairColor || 'blonde');
  const [shieldStyle, setShieldStyle] = useState<'wooden' | 'hylian' | 'mirror'>(player.avatar?.shieldStyle || 'hylian');

  const handleSave = () => {
    sound.playHeartContainer();
    onSaveProfile(heroName.trim() || 'Link', selectedTitle, {
      tunicColor,
      hairColor,
      shieldStyle,
      avatarTitle: selectedTitle
    });
    onClose();
  };

  const getTunicHex = (tunic: TunicColor) => {
    const found = TUNIC_OPTIONS.find(t => t.id === tunic);
    return found ? found.hex : '#2e7d32';
  };

  const getHairHex = (hair: HairColor) => {
    const found = HAIR_OPTIONS.find(h => h.id === hair);
    return found ? found.hex : '#facc15';
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 font-mono backdrop-blur-xs">
      <div className="zelda-panel max-w-2xl w-full p-5 text-slate-100 rounded-sm shadow-2xl relative border-2 border-amber-500 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-500/40 pb-3 mb-4">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-400 animate-pulse" />
            <div>
              <h2 className="font-pixel text-sm sm:text-base text-amber-300 tracking-wide">
                HERO OF VALUARIA: PROFILE
              </h2>
              <p className="text-xs text-amber-200/70">
                Choose your name, appearance, and royal guild heraldry.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-2.5 py-1 text-xs border border-amber-500/50 hover:bg-amber-500/20 text-amber-300 font-bold cursor-pointer"
          >
            ✕ ESC
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-5">
          {/* Avatar 16-Bit Live Visual Preview */}
          <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-slate-950/80 border border-amber-500/40 rounded-sm">
            <span className="text-[11px] font-bold text-amber-400 uppercase mb-2">Sprite Preview</span>

            {/* Custom 16-bit SVG Pixel Hero Render */}
            <div className="w-32 h-36 bg-emerald-950/40 border-2 border-amber-400/70 rounded-sm flex items-center justify-center relative shadow-inner">
              <svg width="84" height="96" viewBox="0 0 28 32" className="pixelated drop-shadow-md">
                {/* Shadow */}
                <ellipse cx="14" cy="30" rx="9" ry="2" fill="rgba(0,0,0,0.5)" />

                {/* Boots */}
                <rect x="9" y="26" width="4" height="4" fill="#5c3a21" />
                <rect x="15" y="26" width="4" height="4" fill="#5c3a21" />

                {/* Tunic Body */}
                <rect x="8" y="14" width="12" height="12" fill={getTunicHex(tunicColor)} />
                <polygon points="8,14 14,20 20,14" fill="#000" opacity="0.15" />

                {/* Belt & Buckle */}
                <rect x="8" y="21" width="12" height="2.5" fill="#78350f" />
                <rect x="12.5" y="21" width="3" height="2.5" fill="#facc15" />

                {/* Arms */}
                <rect x="5" y="14" width="3" height="7" fill={getTunicHex(tunicColor)} />
                <rect x="20" y="14" width="3" height="7" fill={getTunicHex(tunicColor)} />

                {/* Shield on Left Arm */}
                {shieldStyle === 'wooden' && (
                  <rect x="3" y="15" width="4" height="9" fill="#92400e" stroke="#451a03" strokeWidth="0.5" />
                )}
                {shieldStyle === 'hylian' && (
                  <g>
                    <path d="M 3 15 L 7 15 L 7 22 L 5 24 L 3 22 Z" fill="#2563eb" stroke="#d97706" strokeWidth="0.5" />
                    <polygon points="5,17 6,19 4,19" fill="#facc15" />
                  </g>
                )}
                {shieldStyle === 'mirror' && (
                  <rect x="3" y="15" width="4" height="9" fill="#e2e8f0" stroke="#38bdf8" strokeWidth="0.5" />
                )}

                {/* Sword on Hip */}
                <rect x="22" y="13" width="2" height="11" fill="#cbd5e1" />
                <rect x="21" y="12" width="4" height="2" fill="#facc15" />

                {/* Face */}
                <rect x="10" y="7" width="8" height="7" fill="#fed7aa" />
                {/* Eyes */}
                <rect x="11.5" y="9.5" width="1.5" height="1.5" fill="#0f172a" />
                <rect x="15" y="9.5" width="1.5" height="1.5" fill="#0f172a" />

                {/* Hair Under Cap */}
                <rect x="9" y="8" width="1.5" height="4" fill={getHairHex(hairColor)} />
                <rect x="17.5" y="8" width="1.5" height="4" fill={getHairHex(hairColor)} />

                {/* Pointy Cap */}
                <rect x="8.5" y="4" width="11" height="4" fill={getTunicHex(tunicColor)} />
                <polygon points="8.5,4 14,0 19.5,4" fill={getTunicHex(tunicColor)} />
                <polygon points="14,0 21,3 18,5" fill={getTunicHex(tunicColor)} />
              </svg>
            </div>

            <div className="mt-3 text-center">
              <span className="font-bold text-amber-300 text-sm">{heroName}</span>
              <p className="text-[11px] text-slate-300 opacity-80">{selectedTitle}</p>
            </div>
          </div>

          {/* Customization Inputs */}
          <div className="md:col-span-8 space-y-4">
            {/* Hero Name Input */}
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase mb-1 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5" />
                Hero's Name
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={heroName}
                  onChange={(e) => setHeroName(e.target.value.slice(0, 16))}
                  placeholder="Enter Hero Name..."
                  className="flex-1 bg-slate-900 border-2 border-amber-500/70 p-2 text-sm text-amber-200 font-bold focus:outline-none focus:border-amber-400 rounded-xs"
                  maxLength={16}
                />
                <button
                  type="button"
                  onClick={() => {
                    const names = ['Link', 'Robin', 'Arthur', 'Valeria', 'Solomon', 'Aurelius', 'Lyra'];
                    const pick = names[Math.floor(Math.random() * names.length)];
                    setHeroName(pick);
                    sound.playKeyClick();
                  }}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-amber-500/50 text-amber-300 text-xs font-bold cursor-pointer rounded-xs flex items-center gap-1"
                  title="Randomize Name"
                >
                  <Wand2 className="w-3.5 h-3.5" />
                  <span>Random</span>
                </button>
              </div>
            </div>

            {/* Hero Title Select */}
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase mb-1">
                Order & Title
              </label>
              <select
                value={selectedTitle}
                onChange={(e) => setSelectedTitle(e.target.value)}
                className="w-full bg-slate-900 border border-amber-500/70 p-2 text-xs text-amber-100 font-bold focus:outline-none focus:border-amber-400 rounded-xs"
              >
                {TITLE_OPTIONS.map(title => (
                  <option key={title} value={title}>{title}</option>
                ))}
              </select>
            </div>

            {/* Tunic Color Palette */}
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase mb-1.5">
                Tunic & Mail Armor
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {TUNIC_OPTIONS.map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setTunicColor(opt.id);
                      sound.playKeyClick();
                    }}
                    className={`p-2 border text-left flex items-center gap-2.5 rounded-xs transition-colors cursor-pointer ${
                      tunicColor === opt.id
                        ? 'border-amber-400 bg-amber-500/20 text-amber-200'
                        : 'border-slate-800 bg-slate-900/70 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <span
                      className="w-5 h-5 rounded-xs border border-white/40 shadow-xs flex-shrink-0"
                      style={{ backgroundColor: opt.hex }}
                    />
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">{opt.name}</div>
                      <div className="text-[10px] opacity-70 truncate">{opt.desc}</div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Hair Color */}
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase mb-1.5">
                Hair Color
              </label>
              <div className="flex flex-wrap gap-2">
                {HAIR_OPTIONS.map(opt => (
                  <button
                    key={opt.id}
                    type="button"
                    onClick={() => {
                      setHairColor(opt.id);
                      sound.playKeyClick();
                    }}
                    className={`px-3 py-1.5 border text-xs font-bold rounded-xs flex items-center gap-2 cursor-pointer ${
                      hairColor === opt.id
                        ? 'border-amber-400 bg-amber-500/20 text-amber-200'
                        : 'border-slate-800 bg-slate-900 hover:border-slate-700 text-slate-300'
                    }`}
                  >
                    <span className="w-3 h-3 rounded-full border border-black/50" style={{ backgroundColor: opt.hex }} />
                    <span>{opt.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Shield Style */}
            <div>
              <label className="block text-xs font-bold text-amber-300 uppercase mb-1.5 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5" />
                Defined-Risk Shield Emblem
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setShieldStyle('wooden')}
                  className={`p-2 border text-center text-xs font-bold cursor-pointer rounded-xs ${
                    shieldStyle === 'wooden' ? 'border-amber-400 bg-amber-500/20 text-amber-200' : 'border-slate-800 bg-slate-900 text-slate-400'
                  }`}
                >
                  🪵 Wooden Value
                </button>
                <button
                  type="button"
                  onClick={() => setShieldStyle('hylian')}
                  className={`p-2 border text-center text-xs font-bold cursor-pointer rounded-xs ${
                    shieldStyle === 'hylian' ? 'border-amber-400 bg-amber-500/20 text-amber-200' : 'border-slate-800 bg-slate-900 text-slate-400'
                  }`}
                >
                  🛡️ Hylian Crest
                </button>
                <button
                  type="button"
                  onClick={() => setShieldStyle('mirror')}
                  className={`p-2 border text-center text-xs font-bold cursor-pointer rounded-xs ${
                    shieldStyle === 'mirror' ? 'border-amber-400 bg-amber-500/20 text-amber-200' : 'border-slate-800 bg-slate-900 text-slate-400'
                  }`}
                >
                  🪞 Mirror Hedge
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-3 border-t border-amber-500/40 pt-4 mt-5">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-slate-700 hover:bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer rounded-xs"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs uppercase tracking-wide cursor-pointer rounded-xs flex items-center gap-1.5 shadow-md"
          >
            <Check className="w-4 h-4" />
            <span>Confirm Hero Profile</span>
          </button>
        </div>
      </div>
    </div>
  );
};
