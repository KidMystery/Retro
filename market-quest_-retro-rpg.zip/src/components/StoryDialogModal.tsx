import React, { useState } from 'react';
import { QuestNode, StoryChoice } from '../types';
import { sound } from '../lib/audioEngine';
import { MessageSquare, ArrowRight, X, AlertCircle } from 'lucide-react';

interface StoryDialogModalProps {
  quest: QuestNode;
  playerFlorins: number;
  onChoiceSelect: (choice: StoryChoice) => void;
  onClose: () => void;
}

export const StoryDialogModal: React.FC<StoryDialogModalProps> = ({
  quest,
  playerFlorins,
  onChoiceSelect,
  onClose
}) => {
  const [selectedChoice, setSelectedChoice] = useState<StoryChoice | null>(null);

  const handleChoose = (choice: StoryChoice) => {
    if (choice.costFlorins && playerFlorins < choice.costFlorins) {
      sound.playAlarmSound();
      return;
    }
    sound.playCommandBeep();
    setSelectedChoice(choice);
  };

  const handleConfirm = () => {
    if (!selectedChoice) return;
    sound.playCoinSound();
    onChoiceSelect(selectedChoice);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-2 sm:p-4 overflow-y-auto font-mono text-xs sm:text-sm">
      <div className="dos-box p-4 bg-[#070b07] text-current w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Title Header */}
        <div className="flex justify-between items-center border-b border-current pb-2 mb-3">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-purple-400" />
            <div>
              <h2 className="font-bold text-base uppercase tracking-wider text-yellow-300">
                {quest.title}
              </h2>
              <div className="text-[11px] opacity-75">LOCATION: {quest.locationName}</div>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 border border-current hover:bg-current hover:text-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Story Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          <div className="p-3 border border-dashed border-current/70 bg-black/60 leading-relaxed text-xs sm:text-sm">
            {quest.description}
          </div>

          {/* Options Philosophy Link */}
          <div className="p-2.5 border border-cyan-500/60 bg-cyan-950/30 text-cyan-200 text-xs">
            <div className="font-bold flex items-center gap-1 text-cyan-300 mb-0.5">
              <AlertCircle className="w-3.5 h-3.5" /> AETHELGARD DERIVATIVES LAW:
            </div>
            <p className="opacity-90">{quest.optionsLesson}</p>
          </div>

          {/* Choices List */}
          {!selectedChoice ? (
            <div className="space-y-2">
              <div className="font-bold text-xs opacity-80 uppercase tracking-wide">
                WHAT IS YOUR DECISION, ORACLE?
              </div>
              {quest.choices.map((choice, cIdx) => {
                const canAfford = !choice.costFlorins || playerFlorins >= choice.costFlorins;

                return (
                  <button
                    key={cIdx}
                    onClick={() => handleChoose(choice)}
                    disabled={!canAfford}
                    className={`w-full text-left p-2.5 border border-current cursor-pointer transition-colors ${
                      canAfford
                        ? 'hover:bg-current hover:text-black font-semibold'
                        : 'opacity-40 cursor-not-allowed bg-red-950/30 border-red-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>[{cIdx + 1}] {choice.text}</span>
                      {choice.costFlorins && (
                        <span className="ml-2 font-bold text-yellow-300 shrink-0">
                          {choice.costFlorins} ƒ
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          ) : (
            /* Outcome display */
            <div className="p-3 border-2 border-yellow-300 bg-black/90 space-y-3">
              <div className="font-bold text-yellow-300 text-xs uppercase tracking-wider">
                [DECISION OUTCOME & MARKET CONSEQUENCE]
              </div>
              <p className="leading-relaxed text-xs sm:text-sm">{selectedChoice.outcomeText}</p>

              {selectedChoice.marketImpact && (
                <div className="text-xs text-cyan-300">
                  {selectedChoice.marketImpact.spotChangePercent && (
                    <div>Market Spot shift: {(selectedChoice.marketImpact.spotChangePercent * 100).toFixed(1)}%</div>
                  )}
                  {selectedChoice.marketImpact.ivChangePercent && (
                    <div>Implied Volatility shift: {(selectedChoice.marketImpact.ivChangePercent * 100).toFixed(1)}%</div>
                  )}
                </div>
              )}

              <div className="flex justify-end pt-2">
                <button
                  onClick={handleConfirm}
                  className="px-4 py-1.5 border border-current bg-current text-black font-bold flex items-center gap-1 cursor-pointer"
                >
                  <span>PROCEED</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
