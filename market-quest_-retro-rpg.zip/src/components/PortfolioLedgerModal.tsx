import React from 'react';
import { PlayerStats, OptionContract, AssetQuote } from '../types';
import { calculateBlackScholes } from '../lib/blackScholes';
import { sound } from '../lib/audioEngine';
import { ShieldAlert, DollarSign, X, CheckCircle, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';

interface PortfolioLedgerModalProps {
  player: PlayerStats;
  positions: OptionContract[];
  asset: AssetQuote;
  onClosePosition: (positionId: string, currentMarketValue: number) => void;
  onExercisePosition: (positionId: string) => void;
  onClose: () => void;
  riskCategory: 'SAFE' | 'MODERATE' | 'HIGH' | 'CRITICAL';
  riskScore: number;
}

export const PortfolioLedgerModal: React.FC<PortfolioLedgerModalProps> = ({
  player,
  positions,
  asset,
  onClosePosition,
  onExercisePosition,
  onClose,
  riskCategory,
  riskScore
}) => {
  const spot = asset.spotPrice;
  const iv = asset.iv;

  // Compute live mark-to-market prices for each contract
  const positionRows = positions.map(pos => {
    const isCall = pos.type === 'CALL';
    const liveBs = calculateBlackScholes(spot, pos.strike, pos.dte, iv, 0.05, isCall);
    const currentPrice = liveBs.price;
    const initialCost = pos.entryPrice * 100 * pos.quantity;
    const currentValue = currentPrice * 100 * pos.quantity;
    const pnl = currentValue - initialCost;
    const isItm = isCall ? spot > pos.strike : spot < pos.strike;

    return {
      ...pos,
      currentPrice,
      currentValue,
      pnl,
      isItm,
      liveDelta: liveBs.delta * pos.quantity,
      liveTheta: liveBs.theta * pos.quantity
    };
  });

  const totalUnrealizedPnl = positionRows.reduce((acc, row) => acc + row.pnl, 0);
  const totalOptionsValue = positionRows.reduce((acc, row) => acc + row.currentValue, 0);
  const marginUsagePct = player.marginLimit > 0 ? (player.marginUsed / player.marginLimit) * 100 : 0;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-2 sm:p-4 overflow-y-auto font-mono text-xs sm:text-sm">
      <div className="dos-box p-4 bg-[#070b07] text-current w-full max-w-4xl max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-center border-b border-current pb-2 mb-3">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-5 h-5 text-yellow-300" />
            <h2 className="font-bold text-base uppercase tracking-wider">
              PORTFOLIO AUDIT & MARGIN RISK LEDGER
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 border border-current hover:bg-current hover:text-black cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Portfolio Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">LIQUID FLORINS</div>
              <div className="font-bold text-yellow-300 text-sm">{player.florins.toLocaleString()} ƒ</div>
              <div className="text-[10px] opacity-60">Instant Buying Power</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">TOTAL PORTFOLIO EQUITY</div>
              <div className="font-bold text-cyan-300 text-sm">
                {Math.round(player.portfolioValue).toLocaleString()} ƒ
              </div>
              <div className="text-[10px] opacity-60">Cash + Derivative Marks</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">UNREALIZED DERIVATIVE P&L</div>
              <div className={`font-bold text-sm ${totalUnrealizedPnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {totalUnrealizedPnl >= 0 ? '+' : ''}{Math.round(totalUnrealizedPnl).toLocaleString()} ƒ
              </div>
              <div className="text-[10px] opacity-60">Open Contract Marks</div>
            </div>

            <div className="border border-current/40 p-2 bg-black/50">
              <div className="opacity-70 text-[10px]">DAILY THETA CASHFLOW</div>
              <div className={`font-bold text-sm ${player.netTheta >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                {player.netTheta >= 0 ? '+' : ''}{player.netTheta.toFixed(1)} ƒ / day
              </div>
              <div className="text-[10px] opacity-60">River of Time Decay</div>
            </div>
          </div>

          {/* Margin & Risk Health Gauge */}
          <div className={`p-3 border ${riskCategory === 'CRITICAL' ? 'border-red-500 bg-red-950/40 text-red-300' : 'border-current bg-black/50'}`}>
            <div className="flex justify-between items-center mb-1 text-xs">
              <span className="font-bold flex items-center gap-1">
                {riskCategory === 'CRITICAL' && <AlertTriangle className="w-4 h-4 text-red-400 animate-dos-blink" />}
                MARGIN UTILIZATION & SOLVENCY LEVEL:
              </span>
              <span className="font-bold">
                {player.marginUsed.toLocaleString()} ƒ / {player.marginLimit.toLocaleString()} ƒ ({marginUsagePct.toFixed(1)}%)
              </span>
            </div>

            <div className="w-full h-3 border border-current bg-black p-0.5 mb-2">
              <div
                className={`h-full transition-all duration-300 ${
                  marginUsagePct > 80 ? 'bg-red-500' : marginUsagePct > 50 ? 'bg-yellow-400' : 'bg-green-500'
                }`}
                style={{ width: `${Math.min(100, marginUsagePct)}%` }}
              />
            </div>

            <div className="flex justify-between text-[11px] opacity-80">
              <span>Risk Score: <strong className="text-current">{riskScore} / 100 ({riskCategory})</strong></span>
              <span>{marginUsagePct > 80 ? '⚠️ WARNING: Close positions to avoid margin liquidation!' : 'Collateral reserves healthy.'}</span>
            </div>
          </div>

          {/* Active Positions Table */}
          <div>
            <div className="font-bold border-b border-current pb-1 mb-2 flex justify-between items-center text-xs">
              <span>ACTIVE DERIVATIVE CONTRACTS ({positions.length})</span>
              <span className="opacity-70 text-[11px]">SPOT: {spot.toFixed(2)} ƒ | IV: {(iv * 100).toFixed(1)}%</span>
            </div>

            {positions.length === 0 ? (
              <div className="p-6 text-center border border-dashed border-current opacity-70">
                [ NO OPEN DERIVATIVE CONTRACTS IN PORTFOLIO ]
                <div className="text-xs mt-1">Visit the Terminal Exchange to deploy option strategies.</div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-current/60 text-[11px] opacity-75">
                      <th className="p-1.5">CONTRACT / STRATEGY</th>
                      <th className="p-1.5">STRIKE</th>
                      <th className="p-1.5">DTE</th>
                      <th className="p-1.5">ENTRY</th>
                      <th className="p-1.5">MARK</th>
                      <th className="p-1.5">DELTA</th>
                      <th className="p-1.5">P&L</th>
                      <th className="p-1.5 text-right">ACTION</th>
                    </tr>
                  </thead>
                  <tbody>
                    {positionRows.map(row => (
                      <tr key={row.id} className="border-b border-current/30 hover:bg-current/10">
                        <td className="p-1.5 font-bold">
                          <span className={row.type === 'CALL' ? 'text-green-400' : 'text-red-400'}>
                            {row.quantity}x {row.strategy}
                          </span>
                          {row.isItm && (
                            <span className="ml-1.5 px-1 bg-yellow-300 text-black font-bold text-[9px]">ITM</span>
                          )}
                        </td>
                        <td className="p-1.5">{row.strike} ƒ</td>
                        <td className="p-1.5">{row.dte}d</td>
                        <td className="p-1.5">{row.entryPrice.toFixed(2)} ƒ</td>
                        <td className="p-1.5 font-bold text-cyan-300">{row.currentPrice.toFixed(2)} ƒ</td>
                        <td className="p-1.5">{row.liveDelta.toFixed(2)}</td>
                        <td className={`p-1.5 font-bold ${row.pnl >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                          {row.pnl >= 0 ? '+' : ''}{Math.round(row.pnl)} ƒ
                        </td>
                        <td className="p-1.5 text-right space-x-1.5">
                          {row.isItm && (
                            <button
                              onClick={() => {
                                sound.playCoinSound();
                                onExercisePosition(row.id);
                              }}
                              className="px-2 py-0.5 border border-yellow-400 text-yellow-300 hover:bg-yellow-400 hover:text-black cursor-pointer font-bold text-[10px]"
                              title="Exercise Option for underlying shares"
                            >
                              EXERCISE
                            </button>
                          )}
                          <button
                            onClick={() => {
                              sound.playCoinSound();
                              onClosePosition(row.id, row.currentValue);
                            }}
                            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black cursor-pointer font-bold text-[10px]"
                          >
                            CLOSE
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="border-t border-current pt-3 mt-3 flex justify-between items-center text-xs">
          <span className="opacity-75">Press [ESC] or click close to return to the realm.</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 border border-current hover:bg-current hover:text-black cursor-pointer font-bold"
          >
            RETURN TO REALM
          </button>
        </div>
      </div>
    </div>
  );
};
