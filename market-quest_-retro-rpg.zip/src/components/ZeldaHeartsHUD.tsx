import React from 'react';
import { PlayerStats, AssetQuote } from '../types';
import { Heart, Coins, TrendingUp, ShieldAlert, Sparkles, Award } from 'lucide-react';

interface ZeldaHeartsHUDProps {
  player: PlayerStats;
  asset: AssetQuote;
  onOpenTrade: () => void;
  onOpenPortfolio: () => void;
  onOpenGrimoire: () => void;
  onAdvanceDay: () => void;
}

export const ZeldaHeartsHUD: React.FC<ZeldaHeartsHUDProps> = ({
  player,
  asset,
  onOpenTrade,
  onOpenPortfolio,
  onOpenGrimoire,
  onAdvanceDay
}) => {
  // Render Zelda hearts
  const totalContainers = player.maxHearts || 4;
  const currentHearts = Math.max(0, player.hearts);

  const renderHearts = () => {
    const hearts = [];
    for (let i = 0; i < totalContainers; i++) {
      const remaining = currentHearts - i;
      if (remaining >= 1) {
        // Full Heart
        hearts.push(
          <span key={i} className="inline-block text-red-500 drop-shadow-[0_0_4px_rgba(239,68,68,0.8)] animate-pulse scale-105" title="Full Life Force Heart">
            ❤️
          </span>
        );
      } else if (remaining >= 0.4) {
        // Half Heart
        hearts.push(
          <span key={i} className="inline-block text-red-400 opacity-90" title="Half Life Force Heart">
            💔
          </span>
        );
      } else {
        // Empty Heart
        hearts.push(
          <span key={i} className="inline-block opacity-35 grayscale" title="Empty Heart Container">
            🖤
          </span>
        );
      }
    }
    return hearts;
  };

  const tierNames: { [key: number]: string } = {
    1: 'Novice Apprentice',
    2: 'Enterprising Investor',
    3: 'Master Oracle of Value'
  };

  const progressToNextHeart = player.successfulTradesCount % 3;

  return (
    <div className="dos-box bg-[#060a06] border-2 border-current p-2.5 sm:p-3 font-mono text-xs select-none">
      {/* Top Row: Hearts & Florins & Market Spot */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-current/40 pb-2 mb-2">
        {/* Zelda Hearts Bar */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-sm sm:text-base">
            {renderHearts()}
          </div>
          <div className="text-[11px] font-bold">
            <span className="text-red-400">{player.hearts.toFixed(1)}</span>
            <span className="opacity-60">/{player.maxHearts} HEARTS</span>
          </div>
        </div>

        {/* Florins (Rupees) */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 border border-yellow-400/60 bg-yellow-950/30 text-yellow-300 font-bold">
          <Coins className="w-4 h-4 text-yellow-300 animate-spin-slow" />
          <span>{player.florins.toLocaleString()} ƒ</span>
          <span className="text-[10px] opacity-75 font-normal">FLORINS</span>
        </div>

        {/* Spot Asset Ticker */}
        <div className="flex items-center gap-2 px-2 py-0.5 border border-current/50 bg-black/50">
          <span className="font-bold text-yellow-300">{asset.symbol}</span>
          <span className="font-bold text-sm text-cyan-300">{asset.spotPrice.toFixed(2)} ƒ</span>
          <span className={`text-[10px] font-bold ${asset.trend === 'BULLISH' ? 'text-green-400' : 'text-red-400'}`}>
            ({(asset.iv * 100).toFixed(0)}% IV)
          </span>
        </div>

        {/* Day Clock & Advance */}
        <div className="flex items-center gap-1.5">
          <span className="text-yellow-300 font-bold">DAY #{player.day}</span>
          <button
            onClick={onAdvanceDay}
            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black font-bold cursor-pointer text-[11px] transition-colors"
            title="Advance 1 day (triggers time decay and contract expiration)"
          >
            REST / NEXT DAY ⏩
          </button>
        </div>
      </div>

      {/* Bottom Row: Investor Tier & Heart Progress & Greeks & Quick Menu */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px]">
        {/* Tier & Heart Container Progress */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1 text-yellow-300">
            <Award className="w-3.5 h-3.5" />
            <span className="font-bold">TIER {player.investorTier}: {tierNames[player.investorTier] || 'Oracle'}</span>
          </div>

          <div className="hidden sm:flex items-center gap-1 opacity-80" title="Every 3 sound trades earns 1 Heart Container">
            <span>Next Container:</span>
            <div className="flex gap-0.5">
              {[0, 1, 2].map(idx => (
                <span
                  key={idx}
                  className={`w-2.5 h-2.5 border border-red-500 rounded-xs ${
                    idx < progressToNextHeart ? 'bg-red-500' : 'bg-transparent'
                  }`}
                />
              ))}
            </div>
            <span className="text-[10px]">({progressToNextHeart}/3 Trades)</span>
          </div>
        </div>

        {/* Greeks Aura */}
        <div className="flex items-center gap-2.5 opacity-90">
          <span title="Net Delta (directional leverage)">
            Δ <strong className={player.netDelta >= 0 ? 'text-green-400' : 'text-red-400'}>{player.netDelta > 0 ? '+' : ''}{player.netDelta.toFixed(2)}</strong>
          </span>
          <span title="Net Theta (time decay florins/day)">
            Θ <strong className={player.netTheta >= 0 ? 'text-green-400' : 'text-red-400'}>{player.netTheta > 0 ? '+' : ''}{player.netTheta.toFixed(1)}ƒ/d</strong>
          </span>
          <span title="Risk Score">
            Risk: <strong className={player.riskScore > 60 ? 'text-red-400' : 'text-cyan-300'}>{player.riskScore}/100</strong>
          </span>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={onOpenTrade}
            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black font-bold cursor-pointer"
          >
            [T] TRADE
          </button>
          <button
            onClick={onOpenPortfolio}
            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black font-bold cursor-pointer"
          >
            [P] LEDGER
          </button>
          <button
            onClick={onOpenGrimoire}
            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black font-bold cursor-pointer"
          >
            [G] GRIMOIRE
          </button>
        </div>
      </div>
    </div>
  );
};
