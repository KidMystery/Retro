import React, { useState } from 'react';
import { UndervaluedAsset, PlayerStats } from '../types';
import { sound } from '../lib/audioEngine';
import { ShieldCheck, TrendingUp, DollarSign, Award, AlertTriangle, CheckCircle2 } from 'lucide-react';

interface UndervaluedAssetModalProps {
  asset: UndervaluedAsset;
  player: PlayerStats;
  onSelectChoice: (choiceIndex: number) => void;
  onClose: () => void;
}

export const UndervaluedAssetModal: React.FC<UndervaluedAssetModalProps> = ({
  asset,
  player,
  onSelectChoice,
  onClose
}) => {
  const [selectedIdx, setSelectedIdx] = useState<number | null>(null);
  const [outcomeRevealed, setOutcomeRevealed] = useState(false);

  const handleChoose = (idx: number) => {
    setSelectedIdx(idx);
    setOutcomeRevealed(true);
    const choice = asset.choices[idx];
    if (choice.awardsHeartContainer) {
      sound.playHeartContainer();
    } else if (choice.heartsEffect > 0) {
      sound.playSecretChime();
    } else if (choice.heartsEffect < 0) {
      sound.playAlarmSound();
    }
  };

  const activeChoice = selectedIdx !== null ? asset.choices[selectedIdx] : null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 font-mono">
      <div className="dos-box w-full max-w-3xl bg-[#061006] border-2 border-yellow-400 p-4 text-xs select-none max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b-2 border-yellow-400 pb-2 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="bg-yellow-400 text-black font-extrabold px-1.5 py-0.5 text-[10px]">
                SECRET DISCOVERY
              </span>
              <h2 className="text-base sm:text-lg font-bold text-yellow-300">
                {asset.name} ({asset.symbol})
              </h2>
            </div>
            <p className="text-xs opacity-75">{asset.locationName} • {asset.category}</p>
          </div>
          <button
            onClick={onClose}
            className="px-2 py-1 border border-current hover:bg-current hover:text-black font-bold cursor-pointer"
          >
            [ESC] EXIT
          </button>
        </div>

        {/* Fundamental Balance Sheet & Valuation Card */}
        <div className="bg-black/70 border border-yellow-400/60 p-3 mb-3">
          <div className="text-yellow-300 font-bold mb-1">
            ANALYST AUDIT & FUNDAMENTAL VALUATION:
          </div>
          <p className="mb-2 leading-relaxed opacity-90">{asset.description}</p>

          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-yellow-400/30 text-center">
            <div className="p-1.5 bg-black/60 border border-current/40">
              <div className="opacity-70 text-[10px]">MARKET SPOT</div>
              <div className="text-sm font-bold text-cyan-300">${asset.marketSpot} ƒ</div>
            </div>
            <div className="p-1.5 bg-black/60 border border-current/40">
              <div className="opacity-70 text-[10px]">INTRINSIC VALUE</div>
              <div className="text-sm font-bold text-green-400">${asset.intrinsicValue} ƒ</div>
            </div>
            <div className="p-1.5 bg-black/60 border border-current/40">
              <div className="opacity-70 text-[10px]">MARGIN OF SAFETY</div>
              <div className="text-sm font-bold text-yellow-300">+{asset.marginOfSafetyPercent.toFixed(1)}%</div>
            </div>
            <div className="p-1.5 bg-black/60 border border-current/40">
              <div className="opacity-70 text-[10px]">P/E RATIO & IV</div>
              <div className="text-sm font-bold text-purple-300">{asset.peRatio}x / {(asset.currentIv * 100).toFixed(0)}%</div>
            </div>
          </div>
        </div>

        {/* Strategic Decision Choices */}
        {!outcomeRevealed ? (
          <div>
            <div className="text-yellow-300 font-bold mb-2">
              DECISION: HOW WILL YOU DEPLOY CAPITAL ON THIS ASSET?
            </div>
            <div className="space-y-2">
              {asset.choices.map((c, idx) => {
                const canAfford = player.florins >= c.costFlorins;
                return (
                  <button
                    key={idx}
                    disabled={!canAfford}
                    onClick={() => handleChoose(idx)}
                    className={`w-full text-left p-3 border border-current transition-all cursor-pointer ${
                      canAfford
                        ? 'hover:bg-yellow-400 hover:text-black bg-black/50'
                        : 'opacity-40 cursor-not-allowed border-gray-600'
                    }`}
                  >
                    <div className="flex items-center justify-between font-bold mb-1">
                      <span>[{idx + 1}] {c.title}</span>
                      {c.costFlorins > 0 ? (
                        <span className="text-yellow-300 group-hover:text-black">Cost: {c.costFlorins} ƒ</span>
                      ) : (
                        <span className="text-green-400">Net Credit Upfront</span>
                      )}
                    </div>
                    <p className="text-[11px] opacity-80">{c.description}</p>
                  </button>
                );
              })}
            </div>
          </div>
        ) : (
          /* Consequence Outcome Display */
          <div className="bg-black/90 border-2 border-yellow-400 p-4 space-y-3">
            <div className="flex items-center gap-2 text-yellow-300 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 text-green-400" />
              <span>CONSEQUENCE OF YOUR DECISION</span>
            </div>

            <p className="text-xs leading-relaxed opacity-95">
              {activeChoice?.consequenceText}
            </p>

            {/* Reward Badges */}
            <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-yellow-400/40">
              {activeChoice?.awardsHeartContainer && (
                <div className="flex items-center gap-1.5 px-2.5 py-1 bg-red-950/80 border border-red-500 text-red-300 font-bold">
                  <Award className="w-4 h-4 text-red-400" />
                  <span>+1 HEART CONTAINER UNLOCKED!</span>
                </div>
              )}

              {activeChoice?.heartsEffect && activeChoice.heartsEffect > 0 ? (
                <div className="flex items-center gap-1 px-2 py-0.5 border border-green-500 text-green-400 font-bold">
                  <span>+{activeChoice.heartsEffect} Life Force Restored ❤️</span>
                </div>
              ) : null}

              {activeChoice?.heartsEffect && activeChoice.heartsEffect < 0 ? (
                <div className="flex items-center gap-1 px-2 py-0.5 border border-red-500 text-red-400 font-bold">
                  <span>{activeChoice.heartsEffect} Hearts Lost from Panic 💔</span>
                </div>
              ) : null}

              <div className="flex items-center gap-1 px-2 py-0.5 border border-yellow-400 text-yellow-300 font-bold">
                <span>
                  {activeChoice?.florinsGain && activeChoice.florinsGain >= 0 ? '+' : ''}
                  {activeChoice?.florinsGain} Florins Net Result
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                if (selectedIdx !== null) {
                  onSelectChoice(selectedIdx);
                }
              }}
              className="w-full mt-3 py-2 bg-yellow-400 text-black font-extrabold cursor-pointer hover:bg-yellow-300 text-center uppercase"
            >
              ACCEPT CONSEQUENCE & CONTINUE JOURNEY
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
