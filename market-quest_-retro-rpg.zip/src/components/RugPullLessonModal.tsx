import React, { useState } from 'react';
import { ScamEncounter, PlayerStats } from '../types';
import { sound } from '../lib/audioEngine';
import { AlertTriangle, ShieldCheck, Skull, BookOpen, Coins } from 'lucide-react';

interface RugPullLessonModalProps {
  scam: ScamEncounter;
  player: PlayerStats;
  onFallForScam: () => void;
  onRejectScam: () => void;
  onClose: () => void;
}

export const RugPullLessonModal: React.FC<RugPullLessonModalProps> = ({
  scam,
  player,
  onFallForScam,
  onRejectScam,
  onClose
}) => {
  const [phase, setPhase] = useState<'PITCH' | 'RUG_PULLED' | 'REJECTED'>('PITCH');

  const handleTakeBait = () => {
    sound.playRugPullExplosion();
    setPhase('RUG_PULLED');
    onFallForScam();
  };

  const handleReject = () => {
    sound.playSecretChime();
    setPhase('REJECTED');
    onRejectScam();
  };

  const canAfford = player.florins >= scam.costFlorins;

  return (
    <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-3 font-mono">
      <div className={`dos-box w-full max-w-2xl p-4 text-xs select-none max-h-[90vh] overflow-y-auto shadow-2xl transition-colors ${
        phase === 'RUG_PULLED'
          ? 'bg-[#180505] border-2 border-red-500 text-red-100'
          : phase === 'REJECTED'
          ? 'bg-[#051505] border-2 border-green-500 text-green-100'
          : 'bg-[#100818] border-2 border-purple-500 text-purple-100'
      }`}>
        {/* Header */}
        <div className="flex items-center justify-between border-b border-current pb-2 mb-3">
          <div className="flex items-center gap-2">
            {phase === 'RUG_PULLED' ? (
              <Skull className="w-5 h-5 text-red-500 animate-pulse" />
            ) : phase === 'REJECTED' ? (
              <ShieldCheck className="w-5 h-5 text-green-400" />
            ) : (
              <AlertTriangle className="w-5 h-5 text-yellow-400 animate-bounce" />
            )}
            <div>
              <h2 className="text-base sm:text-lg font-bold">
                {phase === 'RUG_PULLED' ? 'CATASTROPHIC RUG PULL!' : scam.title}
              </h2>
              <p className="text-[11px] opacity-75">
                {scam.shillerName} • {scam.shillerTitle}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="px-2 py-0.5 border border-current hover:bg-current hover:text-black font-bold cursor-pointer"
          >
            [ESC]
          </button>
        </div>

        {/* Phase 1: The Pitch */}
        {phase === 'PITCH' && (
          <div className="space-y-3">
            <div className="bg-black/60 border border-purple-400/40 p-3">
              <p className="italic text-yellow-300 mb-2 leading-relaxed">{scam.pitch}</p>
              <div className="p-2 border border-purple-400/60 bg-purple-950/40 text-purple-200">
                <span className="font-bold">PROMISE:</span> {scam.promiseText}
              </div>
            </div>

            <div className="text-center font-bold text-sm text-yellow-300">
              ENTRY REQUIREMENT: {scam.costFlorins} FLORINS
            </div>

            {/* Decisions */}
            <div className="space-y-2 pt-2">
              <button
                disabled={!canAfford}
                onClick={handleTakeBait}
                className={`w-full p-3 border-2 border-red-500 bg-red-950/40 hover:bg-red-600 hover:text-white font-bold text-left cursor-pointer transition-colors ${
                  !canAfford ? 'opacity-40 cursor-not-allowed' : ''
                }`}
              >
                <div className="flex items-center justify-between">
                  <span>[1] Hand over {scam.costFlorins} Florins & Chase the Overnight Gains!</span>
                  <span className="text-red-300 font-extrabold text-[11px]">DANGEROUS SPECULATION</span>
                </div>
                <p className="text-[10px] opacity-80 mt-1">
                  "No risk, bro! You gotta be in it to win it! 🚀🚀🚀"
                </p>
              </button>

              <button
                onClick={handleReject}
                className="w-full p-3 border-2 border-green-500 bg-green-950/40 hover:bg-green-600 hover:text-black font-bold text-left cursor-pointer transition-colors"
              >
                <div className="flex items-center justify-between">
                  <span>[2] Demand Audited Financial Statements & Reject the Scheme</span>
                  <span className="text-green-300 font-extrabold text-[11px]">DISCIPLINED INVESTOR</span>
                </div>
                <p className="text-[10px] opacity-80 mt-1">
                  "Where do the tangible cash flows originate? I refuse unbacked speculation."
                </p>
              </button>
            </div>
          </div>
        )}

        {/* Phase 2: Rug Pulled (Lesson from Intelligent Investor) */}
        {phase === 'RUG_PULLED' && (
          <div className="space-y-3">
            <div className="bg-black/80 border-2 border-red-500 p-3 text-red-200">
              <div className="font-extrabold text-sm mb-1 text-red-400">
                {scam.temptationOutcome.rugPullHeadline}
              </div>
              <p className="leading-relaxed mb-2">
                {scam.temptationOutcome.storyExplanation}
              </p>
              <div className="flex items-center gap-2 text-sm font-extrabold text-red-400 border-t border-red-500/50 pt-2">
                <span>💔 PENALTY: YOU LOST {scam.temptationOutcome.heartsLost} HEARTS & {scam.costFlorins} FLORINS!</span>
              </div>
            </div>

            {/* The Intelligent Investor Lesson Box */}
            <div className="bg-yellow-950/30 border-2 border-yellow-400 p-3 text-yellow-200 space-y-2">
              <div className="flex items-center gap-2 font-bold text-yellow-300">
                <BookOpen className="w-4 h-4 text-yellow-400" />
                <span>LESSON FROM THE INTELLIGENT INVESTOR:</span>
              </div>
              <div className="text-[11px] opacity-80 font-semibold">
                {scam.temptationOutcome.chapterReference}
              </div>
              <p className="italic text-xs leading-relaxed border-l-2 border-yellow-400 pl-2">
                {scam.temptationOutcome.intelligentInvestorLesson}
              </p>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2 bg-red-600 text-white font-extrabold cursor-pointer hover:bg-red-500 text-center uppercase"
            >
              INTERNALIZE THE LESSON & LIMP FORWARD
            </button>
          </div>
        )}

        {/* Phase 3: Rejected Scam (Reward) */}
        {phase === 'REJECTED' && (
          <div className="space-y-3">
            <div className="bg-black/80 border-2 border-green-500 p-3 text-green-200">
              <div className="font-extrabold text-sm mb-1 text-green-400">
                FRAUD DETECTED & THWARTED!
              </div>
              <p className="leading-relaxed mb-2">
                {scam.rejectionOutcome.response}
              </p>
              <p className="font-bold text-yellow-300">
                {scam.rejectionOutcome.rewardWisdom}
              </p>
              <div className="flex items-center gap-2 text-sm font-bold text-yellow-300 border-t border-green-500/50 pt-2">
                <Coins className="w-4 h-4 text-yellow-300" />
                <span>+{scam.rejectionOutcome.rewardFlorins} Florins Bounty Awarded!</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full py-2 bg-green-500 text-black font-extrabold cursor-pointer hover:bg-green-400 text-center uppercase"
            >
              CONTINUE WITH DISCIPLINE
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
