import React, { useState, useEffect } from 'react';
import { PlayerStats, OptionContract, AssetQuote, SaveSlotData, TunicColor } from '../types';
import { SaveSystem } from '../lib/saveSystem';
import { sound } from '../lib/audioEngine';
import { Save, Download, Trash2, Sparkles, Check, Clock, MapPin, Heart } from 'lucide-react';

interface SaveGameModalProps {
  mode: 'SAVE' | 'LOAD';
  locationName: string;
  player: PlayerStats;
  positions: OptionContract[];
  assetQuote: AssetQuote;
  terminalLog: string[];
  isAtSaveShrine?: boolean;
  onLoadGame: (data: SaveSlotData) => void;
  onClose: () => void;
}

const TUNIC_COLORS: Record<TunicColor, string> = {
  green: '#2e7d32',
  blue: '#1e40af',
  red: '#b91c1c',
  purple: '#7e22ce',
  black: '#1f2937'
};

export const SaveGameModal: React.FC<SaveGameModalProps> = ({
  mode: initialMode,
  locationName,
  player,
  positions,
  assetQuote,
  terminalLog,
  isAtSaveShrine = false,
  onLoadGame,
  onClose
}) => {
  const [mode, setMode] = useState<'SAVE' | 'LOAD'>(initialMode);
  const [slots, setSlots] = useState<(SaveSlotData | null)[]>([]);
  const [autoSave, setAutoSave] = useState<SaveSlotData | null>(null);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);

  const refreshSlots = () => {
    setSlots(SaveSystem.getAllSlots());
    setAutoSave(SaveSystem.getAutoSave());
  };

  useEffect(() => {
    refreshSlots();
  }, []);

  const handleSaveToSlot = (slotNumber: number) => {
    sound.playSaveGame();
    SaveSystem.saveToSlot(slotNumber, locationName, player, positions, assetQuote, terminalLog);
    refreshSlots();
    setSaveSuccessNotice(`Adventure permanently preserved in Slot ${slotNumber}!`);
    setTimeout(() => {
      setSaveSuccessNotice(null);
    }, 2800);
  };

  const handleLoadSlot = (data: SaveSlotData) => {
    sound.playHeartContainer();
    onLoadGame(data);
    onClose();
  };

  const handleDeleteSlot = (slotNumber: number, e: React.MouseEvent) => {
    e.stopPropagation();
    sound.playKeyClick();
    SaveSystem.deleteSlot(slotNumber);
    refreshSlots();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 flex items-center justify-center p-3 font-mono backdrop-blur-xs">
      <div className="zelda-panel max-w-3xl w-full p-5 text-slate-100 rounded-sm shadow-2xl relative border-2 border-amber-500 max-h-[92vh] overflow-y-auto">
        {/* Banner if at Sacred Save Shrine */}
        {isAtSaveShrine && (
          <div className="mb-3 p-2.5 bg-gradient-to-r from-amber-950/60 via-amber-900/40 to-amber-950/60 border border-amber-400 text-amber-200 text-xs flex items-center justify-between rounded-xs animate-save-sparkle">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
              <span className="font-bold uppercase tracking-wider">
                SACRED SAVE SHRINE OF VALUARIA
              </span>
            </div>
            <span className="text-[11px] opacity-90 hidden sm:inline">
              Your deeds and options balance are blessed by the Goddess of Margin.
            </span>
          </div>
        )}

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-amber-500/40 pb-3 mb-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/20 border border-amber-400 rounded-xs">
              {mode === 'SAVE' ? (
                <Save className="w-5 h-5 text-amber-400" />
              ) : (
                <Download className="w-5 h-5 text-amber-400" />
              )}
            </div>
            <div>
              <h2 className="font-pixel text-sm sm:text-base text-amber-300">
                {mode === 'SAVE' ? 'PRESERVE ADVENTURE [SAVE]' : 'RESTORE ADVENTURE [LOAD]'}
              </h2>
              <p className="text-xs text-amber-200/70">
                Select a sacred chronicle parchment below.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode Switcher */}
            <div className="flex border border-amber-500/40 rounded-xs overflow-hidden text-xs">
              <button
                type="button"
                onClick={() => {
                  setMode('SAVE');
                  sound.playKeyClick();
                }}
                className={`px-3 py-1 font-bold cursor-pointer transition-colors ${
                  mode === 'SAVE' ? 'bg-amber-500 text-black' : 'bg-slate-900 text-amber-200 hover:bg-slate-800'
                }`}
              >
                SAVE
              </button>
              <button
                type="button"
                onClick={() => {
                  setMode('LOAD');
                  sound.playKeyClick();
                }}
                className={`px-3 py-1 font-bold cursor-pointer transition-colors ${
                  mode === 'LOAD' ? 'bg-amber-500 text-black' : 'bg-slate-900 text-amber-200 hover:bg-slate-800'
                }`}
              >
                LOAD
              </button>
            </div>

            <button
              onClick={onClose}
              className="px-2.5 py-1 text-xs border border-amber-500/50 hover:bg-amber-500/20 text-amber-300 font-bold cursor-pointer rounded-xs"
            >
              ✕ ESC
            </button>
          </div>
        </div>

        {/* Save Success Notice Banner */}
        {saveSuccessNotice && (
          <div className="mb-4 p-3 bg-emerald-950/80 border-2 border-emerald-400 text-emerald-200 text-xs font-bold flex items-center gap-2 rounded-xs animate-bounce shadow-lg">
            <Check className="w-4 h-4 text-emerald-400" />
            <span>{saveSuccessNotice}</span>
          </div>
        )}

        {/* Save Slots List */}
        <div className="space-y-3">
          {[1, 2, 3].map(slotNum => {
            const slotData = slots[slotNum - 1];

            return (
              <div
                key={slotNum}
                className={`p-3.5 border-2 rounded-xs transition-all relative ${
                  slotData
                    ? 'border-amber-500/70 bg-slate-900/90 hover:border-amber-400 hover:bg-slate-900'
                    : 'border-slate-800 bg-slate-950/50 hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  {/* Slot Title & Hero Data */}
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 border border-amber-400/50 bg-slate-950 flex items-center justify-center font-pixel text-amber-300 text-xs flex-shrink-0 rounded-xs">
                      #{slotNum}
                    </div>

                    <div className="min-w-0">
                      {slotData ? (
                        <>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-amber-300 text-sm">
                              {slotData.player.name}
                            </span>
                            <span className="text-[10px] px-1.5 py-0.2 bg-amber-500/20 border border-amber-400/40 text-amber-200 rounded-xs">
                              {slotData.player.avatar?.avatarTitle || slotData.player.title}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300 mt-1">
                            {/* Hearts preview */}
                            <div className="flex items-center gap-0.5 text-red-500">
                              {Array.from({ length: slotData.player.maxHearts || 4 }).map((_, idx) => (
                                <Heart
                                  key={idx}
                                  className={`w-3.5 h-3.5 ${
                                    idx < slotData.player.hearts ? 'fill-red-500 text-red-500' : 'opacity-30 text-slate-500'
                                  }`}
                                />
                              ))}
                            </div>

                            <span className="text-yellow-300 font-bold">
                              {slotData.player.florins.toLocaleString()} ƒ
                            </span>

                            <div className="flex items-center gap-1 text-slate-400 text-[11px]">
                              <MapPin className="w-3 h-3 text-amber-400" />
                              <span className="truncate max-w-[180px]">{slotData.locationName}</span>
                            </div>

                            <div className="flex items-center gap-1 text-slate-500 text-[10px]">
                              <Clock className="w-3 h-3" />
                              <span>{slotData.savedAt}</span>
                            </div>
                          </div>
                        </>
                      ) : (
                        <div>
                          <span className="font-bold text-slate-500 text-sm">
                            [EMPTY CHRONICLE SLOT #{slotNum}]
                          </span>
                          <p className="text-xs text-slate-600 mt-0.5">
                            No quest data recorded in this slot yet.
                          </p>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions for this Slot */}
                  <div className="flex items-center gap-2 sm:self-center">
                    {mode === 'SAVE' ? (
                      <button
                        onClick={() => handleSaveToSlot(slotNum)}
                        className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black font-extrabold text-xs uppercase cursor-pointer rounded-xs flex items-center gap-1.5 shadow-sm"
                      >
                        <Save className="w-3.5 h-3.5" />
                        <span>{slotData ? 'Overwrite Slot' : 'Save Here'}</span>
                      </button>
                    ) : (
                      <button
                        disabled={!slotData}
                        onClick={() => slotData && handleLoadSlot(slotData)}
                        className={`px-4 py-2 font-extrabold text-xs uppercase rounded-xs flex items-center gap-1.5 ${
                          slotData
                            ? 'bg-amber-500 hover:bg-amber-400 text-black cursor-pointer shadow-sm'
                            : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                        }`}
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Load Quest</span>
                      </button>
                    )}

                    {slotData && (
                      <button
                        onClick={(e) => handleDeleteSlot(slotNum, e)}
                        className="p-2 border border-red-900/50 hover:bg-red-950 hover:border-red-600 text-red-400 rounded-xs cursor-pointer"
                        title="Delete this save slot"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Auto-Save Slot Option */}
        {autoSave && (
          <div className="mt-4 pt-3 border-t border-slate-800">
            <div className="text-[11px] font-bold text-slate-400 uppercase mb-2 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-400" />
              <span>Goddess Auto-Save Backup</span>
            </div>
            <div className="p-2.5 bg-slate-950 border border-slate-800 flex items-center justify-between rounded-xs text-xs">
              <div className="flex items-center gap-2 text-slate-300">
                <span className="font-bold text-amber-300">{autoSave.player.name}</span>
                <span className="opacity-70">Day #{autoSave.player.day}</span>
                <span className="opacity-50">• {autoSave.locationName}</span>
                <span className="text-[10px] text-slate-500">({autoSave.savedAt})</span>
              </div>
              <button
                onClick={() => handleLoadSlot(autoSave)}
                className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold rounded-xs cursor-pointer border border-amber-500/40"
              >
                Restore Auto-Save
              </button>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="flex items-center justify-between border-t border-amber-500/40 pt-3 mt-4 text-xs text-slate-400">
          <span>Current Location: <strong className="text-amber-300">{locationName}</strong></span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold cursor-pointer rounded-xs"
          >
            Close [ESC]
          </button>
        </div>
      </div>
    </div>
  );
};
