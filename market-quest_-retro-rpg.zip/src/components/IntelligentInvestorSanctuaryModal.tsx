import React, { useState } from 'react';
import { INTELLIGENT_INVESTOR_LESSONS } from '../lib/intelligentInvestorData';
import { IntelligentInvestorLesson, PlayerStats } from '../types';
import { sound } from '../lib/audioEngine';
import { BookOpen, Sparkles, Heart, Award, ShieldCheck } from 'lucide-react';

interface IntelligentInvestorSanctuaryModalProps {
  player: PlayerStats;
  onRevive: () => void;
}

export const IntelligentInvestorSanctuaryModal: React.FC<IntelligentInvestorSanctuaryModalProps> = ({
  player,
  onRevive
}) => {
  // Pick a lesson based on revivals count or random
  const lessonIdx = player.intelligentInvestorRevivals % INTELLIGENT_INVESTOR_LESSONS.length;
  const lesson: IntelligentInvestorLesson = INTELLIGENT_INVESTOR_LESSONS[lessonIdx];

  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [answered, setAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const handleSelectAnswer = (idx: number) => {
    setSelectedAnswer(idx);
    setAnswered(true);
    const correct = idx === lesson.reflectionQuestion.correctIndex;
    setIsCorrect(correct);
    if (correct) {
      sound.playHeartContainer();
    } else {
      sound.playAlarmSound();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-3 font-mono">
      <div className="dos-box w-full max-w-3xl bg-[#081020] border-2 border-cyan-400 p-4 sm:p-6 text-xs select-none max-h-[95vh] overflow-y-auto shadow-2xl text-cyan-100">
        {/* Sanctuary Header */}
        <div className="flex items-center gap-3 border-b-2 border-cyan-400 pb-3 mb-4">
          <div className="w-12 h-12 rounded-full border-2 border-cyan-300 bg-cyan-950 flex items-center justify-center shrink-0">
            <Sparkles className="w-6 h-6 text-cyan-300 animate-spin-slow" />
          </div>
          <div>
            <div className="text-[10px] text-yellow-300 font-bold uppercase tracking-widest">
              THE CELESTIAL SANCTUARY OF BENJAMIN GRAHAM
            </div>
            <h2 className="text-base sm:text-xl font-extrabold text-cyan-200">
              LIFE FORCE EXPIRED: LESSONS FROM THE INTELLIGENT INVESTOR
            </h2>
          </div>
        </div>

        {/* Sage Graham Dialogue */}
        <div className="bg-black/70 border border-cyan-500/40 p-3.5 mb-4 space-y-2">
          <p className="italic text-yellow-300 text-sm leading-relaxed">
            "Halt, weary traveler. Your hearts have vanished. You allowed yourself to be seduced by unchecked speculation, ruinous leverage, or fraudulent promises. In the markets as in life, capital without discipline evaporates like morning mist."
          </p>
          <div className="p-2 border-l-2 border-yellow-400 bg-yellow-950/20 text-yellow-100 text-xs">
            <span className="font-bold text-yellow-300">BENJAMIN GRAHAM MAXIM:</span> {lesson.quote}
          </div>
        </div>

        {/* Core Lesson Breakdown */}
        <div className="bg-[#0c1830] border border-cyan-400/60 p-4 mb-4 space-y-3">
          <div className="flex items-center gap-2 font-bold text-cyan-300 text-sm">
            <BookOpen className="w-4 h-4 text-cyan-400" />
            <span>{lesson.title} ({lesson.chapter})</span>
          </div>

          <p className="leading-relaxed text-xs opacity-90">
            {lesson.corePhilosophy}
          </p>

          <div className="p-2 border border-red-500/50 bg-red-950/20 text-red-300 text-[11px]">
            <span className="font-bold">CAUSE OF DOWNFALL:</span> {lesson.whyYouFailed}
          </div>
        </div>

        {/* The Trial of Wisdom Question */}
        <div className="bg-black/80 border-2 border-yellow-400 p-4 mb-4">
          <div className="text-yellow-300 font-bold text-sm mb-2">
            TRIAL OF WISDOM: DEMONSTRATE DISCIPLINE TO RESTORE YOUR HEARTS
          </div>
          <p className="mb-3 text-xs font-semibold text-white">
            {lesson.reflectionQuestion.prompt}
          </p>

          <div className="space-y-2">
            {lesson.reflectionQuestion.choices.map((choice, idx) => {
              const isSelected = selectedAnswer === idx;
              let btnStyle = 'border-cyan-500/60 bg-black/60 hover:bg-cyan-900/40 text-cyan-100';

              if (answered) {
                if (idx === lesson.reflectionQuestion.correctIndex) {
                  btnStyle = 'border-green-400 bg-green-950/80 text-green-200 font-bold';
                } else if (isSelected) {
                  btnStyle = 'border-red-500 bg-red-950/80 text-red-200';
                } else {
                  btnStyle = 'opacity-30 border-gray-700 text-gray-500';
                }
              }

              return (
                <button
                  key={idx}
                  disabled={answered}
                  onClick={() => handleSelectAnswer(idx)}
                  className={`w-full text-left p-2.5 border transition-all text-xs cursor-pointer ${btnStyle}`}
                >
                  <span className="font-bold mr-2">[{String.fromCharCode(65 + idx)}]</span>
                  {choice}
                </button>
              );
            })}
          </div>

          {/* Explanation after selection */}
          {answered && (
            <div className={`mt-3 p-2.5 border text-xs leading-relaxed ${
              isCorrect ? 'border-green-400 bg-green-950/40 text-green-200' : 'border-red-400 bg-red-950/40 text-red-200'
            }`}>
              <div className="font-bold mb-1">
                {isCorrect ? '✅ WISDOM ACKNOWLEDGED!' : '❌ INCORRECT PRINCIPLE'}
              </div>
              {lesson.reflectionQuestion.explanation}
            </div>
          )}
        </div>

        {/* Revival Button */}
        {answered && isCorrect && (
          <button
            onClick={onRevive}
            className="w-full py-3 bg-gradient-to-r from-cyan-400 to-green-400 text-black font-extrabold text-sm uppercase cursor-pointer hover:brightness-110 shadow-lg flex items-center justify-center gap-2"
          >
            <Heart className="w-5 h-5 text-red-600 fill-red-600" />
            <span>RESTORE ALL {player.maxHearts} HEARTS & RETURN TO REALM WITH VALUE BLESSING</span>
          </button>
        )}

        {answered && !isCorrect && (
          <button
            onClick={() => {
              setAnswered(false);
              setSelectedAnswer(null);
            }}
            className="w-full py-2 bg-yellow-500 text-black font-bold uppercase cursor-pointer hover:bg-yellow-400 text-center"
          >
            RE-READ THE LESSON & RETRY THE TRIAL
          </button>
        )}
      </div>
    </div>
  );
};
